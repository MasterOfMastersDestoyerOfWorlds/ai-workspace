package unit.mesh;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.quadlayout.embedding.RingNetworkCarve;

/**
 * Fitting rings as curves on the capped cylinder of {@link RingRegionsTest}: a ring drawn beside
 * a groove slides into it, and a ring on smooth surface stays where it was drawn.
 */
class RingCurveFitTest {

    private static final int AROUND = RingRegionsTest.SEGMENTS_AROUND;

    private static final int DRAWN_ROW = 3;

    private static final int GROOVE_ROW = 4;

    private static final String RING = "ring";

    private static final double HALFWAY_UP_AN_EDGE = 0.4;

    @Test
    void aRingBesideAGrooveSlidesIntoIt() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        float[] signal = new float[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            signal[GROOVE_ROW * AROUND + segment] = 1f;
        }
        SurfaceCreases creases = new SurfaceCreases(cylinder, signal, null, 0.0);
        RingRegions drawn = new RingRegions(cylinder, new String[] { RING },
                new boolean[][] { RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW, false) }).build();
        RingCurveFit fit = new RingCurveFit(drawn, creases, RingCurveFit.DEFAULT_BAND_EDGES);
        fit.assemble(RingCurveFit.DEFAULT_PULL, RingCurveFit.DEFAULT_SMOOTHNESS, List.of());
        fit.system.relax();
        boolean[][] masks = fit.marks();

        assertEquals(1, fit.curveCount, fit.report());
        assertEquals(AROUND, fit.movedPoints, fit.report());
        assertTrue(fit.energies[1] < fit.energies[0], fit.report());
        assertArrayEquals(RingRegionsUpdateTest.rowMask(cylinder, GROOVE_ROW, false), masks[0], fit.report());
        assertEquals(2, new RingRegions(cylinder, new String[] { RING }, masks).build().regionCount);
    }

    @Test
    void aRingBetweenTwoGroovesIsCarvedAcrossTheFaces() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        float[] signal = new float[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            // Uneven grooves either side leave the curve between the rows, off every vertex.
            signal[(DRAWN_ROW - 1) * AROUND + segment] = 0.3f;
            signal[GROOVE_ROW * AROUND + segment] = 1f;
        }
        SurfaceCreases creases = new SurfaceCreases(cylinder, signal, null, 0.0);
        RingRegions drawn = new RingRegions(cylinder, new String[] { RING },
                new boolean[][] { RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW, false) }).build();
        RingCurveFit fit = new RingCurveFit(drawn, creases, RingCurveFit.DEFAULT_BAND_EDGES);
        fit.assemble(RingCurveFit.DEFAULT_PULL, RingCurveFit.DEFAULT_SMOOTHNESS, List.of());
        Arrays.fill(fit.system.solution, HALFWAY_UP_AN_EDGE);
        RingNetworkCarve carve = new RingNetworkCarve(fit);
        carve.build();
        boolean[][] masks = carve.marks();

        assertEquals(2, carve.network.nodes.size(), carve.report());
        assertEquals(2, carve.network.arcs.size(), carve.report());
        assertEquals(0, carve.skippedPoints + carve.unlaidPieces + carve.droppedLoops, carve.report());
        assertTrue(carve.topology.copy.vertexCount() > cylinder.vertexCount(), carve.report());
        assertEquals(2, new RingRegions(carve.topology.copy, new String[] { RING }, masks).build().regionCount,
                carve.report());
    }

    @Test
    void aRingOnSmoothSurfaceStaysWhereItWasDrawn() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        SurfaceCreases creases = new SurfaceCreases(cylinder, new float[cylinder.vertexIdBound()], null, 0.0);
        boolean[] row = RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW, false);
        RingCurveFit fit = new RingCurveFit(
                new RingRegions(cylinder, new String[] { RING }, new boolean[][] { row }).build(), creases,
                RingCurveFit.DEFAULT_BAND_EDGES);
        fit.assemble(RingCurveFit.DEFAULT_PULL, RingCurveFit.DEFAULT_SMOOTHNESS, List.of());
        fit.system.relax();

        assertArrayEquals(row, fit.marks()[0], fit.report());
        assertEquals(0, fit.movedPoints);
    }
}
