package unit.mesh;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.joml.Vector3f;
import org.junit.jupiter.api.Test;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.quadlayout.embedding.ArcNetwork;
import ixdar.geometry.mesh.quadlayout.embedding.NetworkContraction;
import ixdar.geometry.mesh.quadlayout.embedding.RingNetworkCarve;
import ixdar.geometry.mesh.quadlayout.embedding.RingPatchNetwork;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedArc;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedMeshTopology;
import ixdar.geometry.mesh.quadlayout.gridmap.FlattenedFaceUv;
import ixdar.geometry.mesh.quadlayout.gridmap.GlobalGridMap;
import ixdar.geometry.mesh.quadlayout.gridmap.GridMapAssembly;
import ixdar.geometry.mesh.quadlayout.gridmap.GridWallPull;

/**
 * Three rings on the capped cylinder of {@link RingRegionsTest} joined by four seams, as an arc
 * network of ten patches, through the quad layout's grid map assembly and Newton relaxation.
 */
class RingNetworkSolveTest {

    private static final int AROUND = RingRegionsTest.SEGMENTS_AROUND;

    private static final int[] RING_ROWS = { 2, 4, 6 };

    private static final int CORNERS = 4;

    private static final double QUAD_EDGE = 0.5;

    // Ring arcs come first, four to a ring, then the seams.
    private static final int RING_ARCS = CORNERS * (2 * RING_ROWS.length - 1);

    // The patch between the middle and top rings beside the first seam: after the two caps and
    // the four patches below the middle ring.
    private static final int UPPER_PATCH = 2 + CORNERS;

    // Height of the middle ring's row on the cylinder, which is 4 tall over 8 rows.
    private static final float MIDDLE_RING_HEIGHT = 2f;

    private static final int GROOVE_ROW = 5;

    private static final double PULL = 10;

    private static final double PULL_WIDTH = 1;

    // The groove starts one grid unit off the ring's line; the pull must at least halve that.
    private static final double CLOSE_TO_LINE = 0.5;

    @Test
    void ringsJoinedBySeamsArePatchesTheSolverRelaxes() {
        HalfEdgeMesh cylinder = (HalfEdgeMesh) RingRegionsTest.cappedCylinder();
        GlobalGridMap map = new GridMapAssembly().assemble(ringsAndSeams(cylinder, new boolean[RING_ARCS]),
                new FlattenedFaceUv(cylinder), QUAD_EDGE);
        map.gridDofs.system.relax();

        assertEquals(2 + CORNERS * (RING_ROWS.length - 1), map.patchMaps.mappedPatchCount);
        assertEquals(0, map.patchMaps.foldedPatchCount);
        assertEquals(CORNERS, map.gridDofs.freedNodeCount);
        assertTrue(map.gridOptimizer.energyAfter <= map.gridOptimizer.energyBefore);
    }

    @Test
    void aGrooveBesideARingPullsItsGridLineOntoTheGroove() {
        HalfEdgeMesh cylinder = (HalfEdgeMesh) RingRegionsTest.cappedCylinder();
        boolean[] rings = new boolean[RING_ARCS];
        GlobalGridMap map = new GridMapAssembly().assemble(ringsAndSeams(cylinder, rings),
                new FlattenedFaceUv(cylinder), QUAD_EDGE);
        double[] groove = new double[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            groove[GROOVE_ROW * AROUND + segment] = 1;
        }
        map.wallPull = new GridWallPull(map, rings, groove, PULL, PULL_WIDTH);
        double before = offLine(map);
        map.gridDofs.system.relax();
        double after = offLine(map);

        assertEquals(1.0, before, 1e-6);
        assertTrue(after < CLOSE_TO_LINE, "groove vertices stand " + after + " grid units off the ring's line");
        assertEquals(0, map.gridOptimizer.flippedTriangleCount);
    }

    @Test
    void aBisectorEndingOnARingIsConformedAndItsJunctionMoves() {
        HalfEdgeMesh cylinder = (HalfEdgeMesh) RingRegionsTest.cappedCylinder();
        boolean[] rings = new boolean[RING_ARCS * 2];
        ArcNetwork network = ringsAndSeams(cylinder, rings);
        // A bisector from the middle ring to the top ring, one column past a seam: its two ends
        // are T-junctions on the rings' arcs.
        int[] ends = new int[2];
        List<Integer> path = new ArrayList<>();
        for (int row = RING_ROWS[1]; row <= RING_ROWS[2]; row++) {
            path.add(network.topology.copyVertexForSourceVertexId(row * AROUND + 1));
        }
        for (int end = 0; end < 2; end++) {
            // The far side is walked the other way, so the same column is two quads along it.
            ends[end] = network.nodeAtOffsetOrSplit(UPPER_PATCH, end == 0 ? 0 : 2, end == 0 ? 1 : 2);
        }
        int bisector = network.addArc(ArcNetwork.NONE, ends[0], ends[1], RING_ROWS[2] - RING_ROWS[1], false, path);
        network.splitPatchByArc(UPPER_PATCH, bisector);
        int junction = network.nodes.get(ends[0]).copyVertex;
        new NetworkContraction(network).conform();

        GlobalGridMap map = new GridMapAssembly().assemble(network, new FlattenedFaceUv(cylinder), QUAD_EDGE);
        double[] groove = new double[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            groove[GROOVE_ROW * AROUND + segment] = 1;
        }
        // The conforming split the arcs, so the middle ring's are found again by where they lie.
        boolean[] pulling = new boolean[network.arcs.size()];
        Vector3f position = new Vector3f();
        for (EmbeddedArc arc : network.arcs) {
            pulling[arc.arcId] = arc.alive;
            for (int copyVertex : arc.path.copyVertexPath) {
                pulling[arc.arcId] &= Math.abs(network.topology.copy.vertexPosition(copyVertex, position).z
                        - MIDDLE_RING_HEIGHT) < 1e-4;
            }
        }
        map.wallPull = new GridWallPull(map, pulling, groove, PULL, PULL_WIDTH);
        map.gridDofs.system.relax();

        assertEquals(RING_ROWS[1] * AROUND + 1, junction);
        assertTrue(offLine(map) < CLOSE_TO_LINE, "groove vertices stand " + offLine(map) + " off the line");
        assertEquals(0, map.gridOptimizer.flippedTriangleCount);
    }

    @Test
    void drawnRingsArePatchedConformedAndPulledOntoAGroove() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        float[] signal = new float[cylinder.vertexIdBound()];
        double[] groove = new double[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            signal[GROOVE_ROW * AROUND + segment] = 1f;
            groove[GROOVE_ROW * AROUND + segment] = 1;
        }
        RingRegions drawn = new RingRegions(cylinder, new String[] { "low", "middle" }, new boolean[][] {
                RingRegionsUpdateTest.rowMask(cylinder, RING_ROWS[0], false),
                RingRegionsUpdateTest.rowMask(cylinder, RING_ROWS[1], false) }).build();
        RingCurveFit curves = new RingCurveFit(drawn, new SurfaceCreases(cylinder, signal, null, 0.0),
                RingCurveFit.DEFAULT_BAND_EDGES);
        // Assembled and not relaxed: the curves stay where the rings were drawn.
        curves.assemble(RingCurveFit.DEFAULT_PULL, RingCurveFit.DEFAULT_SMOOTHNESS, List.of());
        RingNetworkCarve carve = new RingNetworkCarve(curves);
        carve.build();
        RingPatchNetwork rings = new RingPatchNetwork(carve);
        do {
            rings.seam();
        } while (rings.handle() | rings.pad() | rings.chord() | rings.star());
        rings.corner().lay().size().conform();
        GlobalGridMap map = new GridMapAssembly().assemble(rings.network, new FlattenedFaceUv(cylinder), QUAD_EDGE);
        // Only the ring beside the groove pulls, so the measure reads that ring's line alone.
        boolean[] pulling = rings.ringArcs();
        for (EmbeddedArc arc : rings.network.arcs) {
            pulling[arc.arcId] &= arc.sourceArcId != ArcNetwork.NONE && rings.ringsByWall.get(arc.sourceArcId)[0] == 1;
        }
        map.wallPull = new GridWallPull(map, pulling, groove, PULL, PULL_WIDTH);
        double before = offLine(map);
        map.gridDofs.system.relax();

        assertEquals(0, map.patchMaps.foldedPatchCount, rings.report());
        assertTrue(offLine(map) < before / 2, rings.report() + ": groove vertices stand " + offLine(map)
                + " off the line, from " + before);
        assertEquals(0, map.gridOptimizer.flippedTriangleCount);
    }

    /** Mean distance of the pulled groove vertices from the grid line pulling them. */
    private static double offLine(GlobalGridMap map) {
        double total = 0;
        double weight = 0;
        for (int pull = 0; pull < map.wallPull.variables.length; pull++) {
            total += map.wallPull.weights[pull] * Math.abs(
                    map.gridDofs.system.solution[map.wallPull.variables[pull]] - map.wallPull.lines[pull]);
            weight += map.wallPull.weights[pull];
        }
        return total / weight;
    }

    /**
     * The rings and the seams between them carved along the cylinder's own edges.
     *
     * @param cylinder the capped cylinder
     * @param rings    receives which arcs are ring arcs, by arc id
     */
    private static ArcNetwork ringsAndSeams(HalfEdgeMesh cylinder, boolean[] rings) {
        EmbeddedMeshTopology topology = new EmbeddedMeshTopology(cylinder);
        ArcNetwork network = new ArcNetwork(topology);
        int[][] nodes = new int[RING_ROWS.length][CORNERS];
        int[][] ringArcs = new int[RING_ROWS.length][CORNERS];
        int[][] seamArcs = new int[RING_ROWS.length - 1][CORNERS];
        for (int ring = 0; ring < RING_ROWS.length; ring++) {
            for (int corner = 0; corner < CORNERS; corner++) {
                nodes[ring][corner] = network.addNode(ArcNetwork.NONE, topology.copyVertexForSourceVertexId(
                        RING_ROWS[ring] * AROUND + corner * AROUND / CORNERS), false, false);
            }
        }
        for (int ring = 0; ring < RING_ROWS.length; ring++) {
            for (int corner = 0; corner < CORNERS; corner++) {
                List<Integer> path = new ArrayList<>();
                for (int step = 0; step <= AROUND / CORNERS; step++) {
                    path.add(topology.copyVertexForSourceVertexId(
                            RING_ROWS[ring] * AROUND + (corner * AROUND / CORNERS + step) % AROUND));
                }
                ringArcs[ring][corner] = network.addArc(ArcNetwork.NONE, nodes[ring][corner],
                        nodes[ring][(corner + 1) % CORNERS], AROUND / CORNERS, false, path);
                rings[ringArcs[ring][corner]] = ring == 1;
            }
            for (int corner = 0; ring + 1 < RING_ROWS.length && corner < CORNERS; corner++) {
                List<Integer> path = new ArrayList<>();
                for (int row = RING_ROWS[ring]; row <= RING_ROWS[ring + 1]; row++) {
                    path.add(topology.copyVertexForSourceVertexId(row * AROUND + corner * AROUND / CORNERS));
                }
                seamArcs[ring][corner] = network.addArc(ArcNetwork.NONE, nodes[ring][corner],
                        nodes[ring + 1][corner], RING_ROWS[ring + 1] - RING_ROWS[ring], false, path);
            }
        }
        for (int cap = 0; cap < 2; cap++) {
            int ring = cap * (RING_ROWS.length - 1);
            List<List<Integer>> sides = new ArrayList<>();
            for (int corner = 0; corner < CORNERS; corner++) {
                // The side patches walk the bottom ring forwards and the top ring backwards, so
                // the caps walk them the other way: an arc has one patch on each flank.
                sides.add(cap == 0 ? 0 : sides.size(), List.of(ringArcs[ring][corner]));
            }
            network.addPatch(ArcNetwork.NONE, sides, nodes[ring][0]);
        }
        for (int ring = 0; ring + 1 < RING_ROWS.length; ring++) {
            for (int corner = 0; corner < CORNERS; corner++) {
                int next = (corner + 1) % CORNERS;
                network.addPatch(ArcNetwork.NONE, List.of(List.of(ringArcs[ring][corner]),
                        List.of(seamArcs[ring][next]), List.of(ringArcs[ring + 1][corner]),
                        List.of(seamArcs[ring][corner])), nodes[ring][corner]);
            }
        }
        return network;
    }
}
