package unit.mesh;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;

import org.joml.Vector3f;
import org.junit.jupiter.api.Test;

import ixdar.geometry.mesh.data.paths.geodesic.SurfaceMetric;
import ixdar.geometry.mesh.data.paths.query.HeadedCreasePath;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * {@link HeadedCreasePath} on the {@link RingRegionsTest#torus}: a path follows its arrow round
 * the surface and never closes by turning a circle beside its own start.
 */
final class HeadedCreasePathTest {

    /** A loop from one point, its arrow round the tube, runs once round the tube. */
    @Test
    void aLoopFromOnePointRunsRoundTheWayItsArrowPoints() {
        MeshTopology torus = RingRegionsTest.torus();
        HeadedCreasePath search = searchOver(torus);
        int start = torus.vertexIdAt(0);
        float[] roundTube = toward(torus, start, torus.vertexIdAt(1));

        int[] loop = search.trace(start, start, roundTube, roundTube);

        assertNotNull(loop, "no loop round the tube");
        assertEquals(start, loop[0]);
        assertEquals(start, loop[loop.length - 1]);
        assertTrue(loop.length > RingRegionsTest.TORUS_TUBE,
                "the loop closed beside its start: " + Arrays.toString(loop));
        for (int vertexId : loop) {
            assertTrue(vertexId < 2 * RingRegionsTest.TORUS_TUBE
                    || vertexId >= (RingRegionsTest.TORUS_AROUND - 1) * RingRegionsTest.TORUS_TUBE,
                    "the loop left the tube's cross-section: " + Arrays.toString(loop));
        }
    }

    /** The same point with its arrow along the tube runs the long way, round the hole. */
    @Test
    void theArrowPicksWhichWayRoundTheLoopRuns() {
        MeshTopology torus = RingRegionsTest.torus();
        HeadedCreasePath search = searchOver(torus);
        int start = torus.vertexIdAt(0);
        float[] alongTube = toward(torus, start, torus.vertexIdAt(RingRegionsTest.TORUS_TUBE));

        int[] loop = search.trace(start, start, alongTube, alongTube);

        assertNotNull(loop, "no loop round the hole");
        assertTrue(loop.length > RingRegionsTest.TORUS_AROUND,
                "the loop did not run round the hole: " + Arrays.toString(loop));
    }

    /** Between two points the path leaves along its arrow even when the other way is shorter. */
    @Test
    void aSpanLeavesAlongItsArrow() {
        MeshTopology torus = RingRegionsTest.torus();
        HeadedCreasePath search = searchOver(torus);
        int start = torus.vertexIdAt(0);
        int near = torus.vertexIdAt(2);
        float[] awayFromIt = toward(torus, start, torus.vertexIdAt(RingRegionsTest.TORUS_TUBE - 1));

        int[] unsteered = search.trace(start, near, null, null);
        int[] steered = search.trace(start, near, awayFromIt, awayFromIt);

        assertEquals(RingRegionsTest.TORUS_TUBE / 2 - 1, unsteered.length, Arrays.toString(unsteered));
        assertNotNull(steered, "no path the long way round");
        assertEquals(torus.vertexIdAt(RingRegionsTest.TORUS_TUBE - 1), steered[1],
                Arrays.toString(steered));
    }

    /** With no arrow there is no way to tell a loop from standing still. */
    @Test
    void anUnsteeredLoopHasNoPath() {
        MeshTopology torus = RingRegionsTest.torus();
        int start = torus.vertexIdAt(0);

        assertNull(searchOver(torus).trace(start, start, null, null));
    }

    private static HeadedCreasePath searchOver(MeshTopology mesh) {
        HeadedCreasePath search = new HeadedCreasePath(SurfaceMetric.of(mesh));
        search.creases = SurfaceCreases.of(mesh);
        return search;
    }

    private static float[] toward(MeshTopology mesh, int fromVertexId, int toVertexId) {
        Vector3f from = new Vector3f();
        Vector3f to = new Vector3f();
        mesh.vertexPosition(fromVertexId, from);
        mesh.vertexPosition(toVertexId, to);
        to.sub(from).normalize();
        return new float[] { to.x, to.y, to.z };
    }
}
