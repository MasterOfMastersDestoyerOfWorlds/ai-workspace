package unit.mesh;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;
import java.util.Map;

import org.joml.Vector3f;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.paths.spline.SurfaceSpline;
import ixdar.geometry.mesh.data.rings.AnchoredRings;
import ixdar.nodegraph.runtime.NodeGraphRuntime;

/**
 * The {@code ring_fit_*} fixtures: a torus with grooves pinched into its tube, or a sphere with
 * a horn, rings and a bisector drawn off the grooves in the ring scene, and
 * {@code fit_ring_anchors} last. Each test reads where the fitted anchors stand.
 */
@Tag("heavy")
class RingAnchorFitTest {

    private static final String FIXTURES = "dsl/fixtures/ring_fit_";

    private static final String FIRST_RING = "ring_00";

    private static final String SECOND_RING = "ring_01";

    private static final String BISECTOR = "ring_02";

    // Radius of the circle the tube's centre runs on.
    private static final double MAJOR_RADIUS = 2.0;

    private static final double HALF_TURN = 180.0;

    // Where round the torus the fixtures' grooves across the tube are, in degrees from +x.
    private static final double FIRST_GROOVE = 0.0;

    private static final double QUARTER_GROOVE = 90.0;

    // One cross-section of the torus's 160, and one side of the tube's 40, in degrees.
    private static final double SECTION = 2.25;

    private static final double SIDE = 9.0;

    // A ring with no groove to take stands within this many cross-sections of where it is
    // furthest from the other rings: the energy is nearly flat there.
    private static final double OPPOSITE = 4 * SECTION;

    // The circle the horn fixtures' cone meets their unit sphere in, about the y axis, and how
    // near it a fitted anchor stands: about one edge of the sphere.
    private static final double HORN_FOOT_HEIGHT = 0.96;

    private static final double HORN_FOOT_RADIUS = 0.285;

    private static final double HORN_FOOT_WITHIN = 0.08;

    @Test
    void aGeodesicRingAQuarterOfTheTorusAwayMovesIntoTheGroove() {
        GeometryBundle fitted = fitted("one_groove");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
    }

    @Test
    void aCreaseRingAQuarterOfTheTorusAwayMovesIntoTheGroove() {
        GeometryBundle fitted = fitted("one_groove_crease");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
    }

    @Test
    void aRingNearlyOppositeTheGrooveStillMovesIntoIt() {
        GeometryBundle fitted = fitted("one_groove_far");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
    }

    @Test
    void betweenTwoGroovesARingMovesIntoTheNearerOne() {
        assertStands(fitted("two_grooves_nearer_second"), FIRST_RING, false, HALF_TURN, SECTION);
        assertStands(fitted("two_grooves_nearer_first"), FIRST_RING, false, FIRST_GROOVE, SECTION);
        assertStands(fitted("two_grooves_crease"), FIRST_RING, false, FIRST_GROOVE, SECTION);
    }

    @Test
    void twoRingsDrawnNearOneOfTwoGroovesTakeAGrooveEach() {
        GeometryBundle fitted = fitted("two_grooves_two_rings_near_one");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
        assertStands(fitted, SECOND_RING, false, HALF_TURN, SECTION);
    }

    @Test
    void twoRingsEachNearestItsOwnGrooveGoIntoIt() {
        GeometryBundle fitted = fitted("two_grooves_two_rings_each_own");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
        assertStands(fitted, SECOND_RING, false, HALF_TURN, SECTION);
    }

    @Test
    void ofTwoRingsOnATorusWithOneGrooveOneTakesItAndTheOtherStandsOpposite() {
        GeometryBundle fitted = fitted("one_groove_two_rings");
        assertStands(fitted, FIRST_RING, false, FIRST_GROOVE, SECTION);
        assertStands(fitted, SECOND_RING, false, HALF_TURN, OPPOSITE);
    }

    @Test
    void aBisectorBesideAGrooveJoiningItsTwoGroovedRingsMovesIntoIt() {
        // The groove runs along the outside of the torus from one ring to the other; every
        // anchor of the bisector ends in it, its two ends where the groove meets their rings.
        GeometryBundle fitted = fitted("bisector_grooved_rings");
        assertStands(fitted, BISECTOR, true, 0.0, SIDE);
        assertStands(fitted, FIRST_RING, false, QUARTER_GROOVE, SECTION);
        assertStands(fitted, SECOND_RING, false, HALF_TURN, SECTION);
    }

    @Test
    void aBisectorBesideAGrooveJoiningItsTwoSmoothRingsMovesIntoIt() {
        // The rings have no groove to keep them and move apart, taking the bisector's ends along.
        GeometryBundle fitted = fitted("bisector_smooth_rings");
        assertStands(fitted, BISECTOR, true, 0.0, SIDE);
    }

    @Test
    void aRingRoundAHornMovesDownToWhereTheHornMeetsTheSphere() {
        assertRoundTheHornsFoot(fitted("horn_ring_on_horn"));
    }

    @Test
    void aRingDrawnWideRoundAHornMovesInToWhereTheHornMeetsTheSphere() {
        assertRoundTheHornsFoot(fitted("horn_ring_wide"));
    }

    /**
     * Checks every anchor of the fitted ring stands on the circle the horn fixtures' cone meets
     * their sphere in.
     */
    private static void assertRoundTheHornsFoot(GeometryBundle fitted) {
        SurfaceSpline ring = SurfaceSpline.inBundle(fitted, FIRST_RING);
        Vector3f at = new Vector3f();
        for (int vertexId : AnchoredRings.authored(ring)) {
            fitted.mesh().vertexPosition(vertexId, at);
            double off = Math.hypot(at.y - HORN_FOOT_HEIGHT, Math.hypot(at.x, at.z) - HORN_FOOT_RADIUS);
            assertTrue(off <= HORN_FOOT_WITHIN, String.format(Locale.ROOT, "an anchor at %.3f, %.3f, %.3f is %.3f "
                    + "from the horn's foot", at.x, at.y, at.z, off));
        }
    }

    private static GeometryBundle fitted(String fixture) {
        NodeGraphRuntime graph = NodeGraphRuntime.executeResource(FIXTURES + fixture + ".dsl", Map.of());
        System.out.println("[ring-anchor-fit] " + fixture + ": " + graph.lastOutput("report"));
        return (GeometryBundle) graph.lastOutput(NodeGraphRuntime.GEOMETRY);
    }

    /**
     * Checks every anchor the user placed on a fitted ring stands at an angle: round the torus
     * from +x, or for a bisector round the tube from its outside.
     */
    private static void assertStands(GeometryBundle fitted, String label, boolean roundTube, double degrees,
            double within) {
        SurfaceSpline ring = SurfaceSpline.inBundle(fitted, label);
        assertTrue(ring != null, "the fixture carries " + label);
        Vector3f at = new Vector3f();
        for (int vertexId : AnchoredRings.authored(ring)) {
            fitted.mesh().vertexPosition(vertexId, at);
            double stands =Math.toDegrees(roundTube ? Math.atan2(at.y, Math.hypot(at.x, at.z) - MAJOR_RADIUS)
                    : Math.atan2(at.z, at.x));
            double off = Math.abs(((stands - degrees) % (2 * HALF_TURN) + 3 * HALF_TURN) % (2 * HALF_TURN) - HALF_TURN);
            assertTrue(off <= within + 1e-3, String.format(Locale.ROOT, "%s has an anchor at %.2f degrees, "
                    + "%.2f from %.2f", label, stands, off, degrees));
        }
    }
}
