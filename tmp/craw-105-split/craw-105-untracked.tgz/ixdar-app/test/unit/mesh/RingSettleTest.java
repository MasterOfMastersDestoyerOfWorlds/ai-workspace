package unit.mesh;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.data.rings.RingSettle;

/**
 * Settling rings on the capped cylinder of {@link RingRegionsTest}: a ring drawn beside a groove
 * moves into it, and a sliver between two rings goes to its neighbours.
 */
class RingSettleTest {

    private static final int AROUND = RingRegionsTest.SEGMENTS_AROUND;

    private static final int DRAWN_ROW = 3;

    private static final int GROOVE_ROW = 5;

    private static final double WHOLE_SURFACE_BAND = 100.0;

    private static final float[] CAP_CENTRES = { 0f, 0f, 0f, 0f, 0f, 4f };

    private static final String RING = "ring";

    @Test
    void aRingBesideAGrooveSettlesIntoIt() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        float[] signal = new float[cylinder.vertexIdBound()];
        for (int segment = 0; segment < AROUND; segment++) {
            signal[GROOVE_ROW * AROUND + segment] = 1f;
        }
        SurfaceCreases creases = new SurfaceCreases(cylinder, signal, null, 0.0);
        RingRegions drawn = new RingRegions(cylinder, new String[] { RING },
                new boolean[][] { RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW, false) }).build();
        RingSettle settle = new RingSettle(drawn);
        settle.assemble(creases, WHOLE_SURFACE_BAND, RingSettle.DEFAULT_INSULATION, 0.0, List.of(CAP_CENTRES));
        settle.system.relax();
        settle.tidy();
        boolean[][] masks = settle.marks();

        assertTrue(settle.movedFaces > 0, settle.report());
        assertArrayEquals(RingRegionsUpdateTest.rowMask(cylinder, GROOVE_ROW, false), masks[0],
                settle.report());
        assertEquals(2, new RingRegions(cylinder, new String[] { RING }, masks).build().regionCount);
    }

    @Test
    void aSliverBetweenTwoRingsGoesToItsNeighbours() {
        MeshTopology cylinder = RingRegionsTest.cappedCylinder();
        SurfaceCreases creases = new SurfaceCreases(cylinder, new float[cylinder.vertexIdBound()], null, 0.0);
        String[] labels = { RING, RING + "_again" };
        RingRegions drawn = new RingRegions(cylinder, labels,
                new boolean[][] { RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW, false),
                        RingRegionsUpdateTest.rowMask(cylinder, DRAWN_ROW + 1, false) }).build();
        assertEquals(3, drawn.regionCount);
        RingSettle settle = new RingSettle(drawn);
        settle.assemble(creases, WHOLE_SURFACE_BAND, RingSettle.DEFAULT_INSULATION, 0.0, List.of(CAP_CENTRES));
        settle.system.relax();
        settle.tidy();

        assertEquals(1, settle.unpinnedRegions);
        assertEquals(2, new RingRegions(cylinder, labels, settle.marks()).build().regionCount,
                settle.report());
    }
}
