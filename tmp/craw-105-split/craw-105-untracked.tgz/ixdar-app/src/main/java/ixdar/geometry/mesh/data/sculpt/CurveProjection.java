package ixdar.geometry.mesh.data.sculpt;

import java.util.Arrays;
import java.util.Map;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import ixdar.geometry.mesh.data.bundle.CurveGeometry;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.paths.query.TriangleBvh;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.graphics.cameras.Camera3D;

/**
 * Curves drawn in a multiview template's cells cast onto a surface, one ray a pixel, each kept to
 * its longest run over one piece of the surface.
 */
public final class CurveProjection {

    public static final String SLOT = "_projected_curves";

    // 1 on the points drawn in the SVG, 0 on those cast between them.
    public static final String DRAWN_ATTRIBUTE = "drawn";

    // Drawn points that missed the surface or fell outside the kept run.
    public static final String DROPPED_ATTRIBUTE = "dropped";

    // The plane holding the rays through the kept run's first and last drawn points; 0 when it has
    // fewer than two.
    public static final String[] NORMAL_ATTRIBUTES = { "normal_x", "normal_y", "normal_z" };

    private static final int XYZ = CurveGeometry.XYZ;

    private final MeshTopology mesh;

    private final int[] faceOfTriangle;

    private final TriangleBvh bvh;

    private final int[] stack;

    private final Matrix4f model = new Matrix4f();

    private final float[] origin = new float[XYZ];

    private final float[] direction = new float[XYZ];

    private final Vector3f hit = new Vector3f();

    private StrokeSketch sketch;

    private Camera3D camera;

    /**
     * A projector onto one surface, its ray hierarchy built once for every curve cast at it.
     *
     * @param mesh the surface
     */
    public CurveProjection(MeshTopology mesh) {
        this.mesh = mesh;
        faceOfTriangle = new int[mesh.triangleCount()];
        bvh = TriangleBvh.over(mesh, faceOfTriangle);
        stack = new int[Math.max(1, bvh.nodeCount)];
    }

    /**
     * Whether this projector casts at a surface.
     *
     * @param surface the surface
     * @return true when it was built over that very mesh
     */
    public boolean over(MeshTopology surface) {
        return mesh == surface;
    }

    /**
     * Project every curve onto the surface through the cell its {@code view} attribute names.
     *
     * @param template the template whose cells the curves were drawn in
     * @param curves   world curves as {@link StrokeSketch#curves} places them, each tagged with its cell
     * @return one curve per input curve, in order, its longest one-piece run of surface points (empty
     *         when every ray missed), with the {@link #DRAWN_ATTRIBUTE}, {@link #DROPPED_ATTRIBUTE}
     *         and {@link #NORMAL_ATTRIBUTES} attributes and the input's {@code view}
     */
    public CurveGeometry project(StrokeSketch template, CurveGeometry curves) {
        sketch = template;
        float[] views = curves.curveAttributes.get(StrokeSketch.VIEW_ATTRIBUTE);
        int count = curves.curveCount();
        float[] positions = new float[0];
        float[] drawn = new float[0];
        int[] offsets = new int[count + 1];
        boolean[] closed = new boolean[count];
        float[] dropped = new float[count];
        float[][] normals = new float[XYZ][count];
        for (int curve = 0; curve < count; curve++) {
            int cell = views == null ? -1 : (int) views[curve];
            Piece piece = cell < 0 ? new Piece() : piece(cell, sketch.cellPixels(cell, curves, curve),
                    curves.closed[curve]);
            int start = offsets[curve];
            offsets[curve + 1] = start + piece.drawn.length;
            positions = Arrays.copyOf(positions, offsets[curve + 1] * XYZ);
            System.arraycopy(piece.positions, 0, positions, start * XYZ, piece.positions.length);
            drawn = Arrays.copyOf(drawn, offsets[curve + 1]);
            System.arraycopy(piece.drawn, 0, drawn, start, piece.drawn.length);
            closed[curve] = piece.closed;
            dropped[curve] = piece.dropped;
            for (int axis = 0; axis < XYZ; axis++) {
                normals[axis][curve] = piece.normal[axis];
            }
        }
        return new CurveGeometry(positions, offsets, closed, Map.of(DRAWN_ATTRIBUTE, drawn),
                Map.of(StrokeSketch.VIEW_ATTRIBUTE, views == null ? new float[count] : views, DROPPED_ATTRIBUTE,
                        dropped, NORMAL_ATTRIBUTES[0], normals[0], NORMAL_ATTRIBUTES[1], normals[1],
                        NORMAL_ATTRIBUTES[2], normals[2]));
    }

    /**
     * One curve the project_curves node left on a bundle.
     *
     * @param bundle the bundle
     * @param curve  which curve
     * @param reader the reading statement, for the refusal
     * @return the projected curves, holding {@code curve}
     * @throws IllegalArgumentException when the bundle carries no projected curves or not that one
     */
    public static CurveGeometry carried(GeometryBundle bundle, int curve, String reader) {
        if (!(bundle.slots().get(SLOT) instanceof CurveGeometry projected)) {
            throw new IllegalArgumentException(reader + " reads curve " + curve + " but its geometry carries no "
                    + "projected curves; take it from lifted = project_curves(geometry=..., curves=...)");
        }
        if (curve >= projected.curveCount()) {
            throw new IllegalArgumentException(reader + " reads curve " + curve + " but the SVG has "
                    + projected.curveCount());
        }
        if (projected.pointCount(curve) == 0) {
            throw new IllegalArgumentException(reader + ": curve " + curve + " missed the surface");
        }
        return projected;
    }

    /**
     * The drawn points of one projected curve, as spline_ring and add_label take their points.
     *
     * @param projected curves from {@link #project}
     * @param curve     which curve
     * @return packed xyz of its drawn points in order
     */
    public static float[] drawnPoints(CurveGeometry projected, int curve) {
        float[] drawn = projected.pointAttributes.get(DRAWN_ATTRIBUTE);
        float[] points = new float[projected.pointCount(curve) * XYZ];
        int kept = 0;
        for (int point = projected.firstPoint(curve); point < projected.firstPoint(curve + 1); point++) {
            if (drawn != null && drawn[point] > 0f) {
                System.arraycopy(projected.positions, point * XYZ, points, kept, XYZ);
                kept += XYZ;
            }
        }
        return Arrays.copyOf(points, kept);
    }

    /**
     * The plane normal of one projected curve.
     *
     * @param projected curves from {@link #project}
     * @param curve     which curve
     * @return xyz, or an empty array when the curve has none
     */
    public static float[] normal(CurveGeometry projected, int curve) {
        float[] normal = new float[XYZ];
        boolean any = false;
        for (int axis = 0; axis < XYZ; axis++) {
            float[] values = projected.curveAttributes.get(NORMAL_ATTRIBUTES[axis]);
            normal[axis] = values == null ? 0f : values[curve];
            any |= normal[axis] != 0f;
        }
        return any ? normal : new float[0];
    }

    /** One curve's kept run. */
    private static final class Piece {

        float[] positions = new float[0];

        float[] drawn = new float[0];

        boolean closed;

        int dropped;

        float[] normal = new float[XYZ];
    }

    /**
     * Cast one ray a pixel along a curve's pixels and keep its longest one-piece run.
     *
     * @param cell   the cell it was drawn in
     * @param pixels packed xy in the cell
     * @param loop   whether the curve closes
     * @return the kept run
     */
    private Piece piece(int cell, float[] pixels, boolean loop) {
        camera = sketch.cellCamera(cell);
        int points = pixels.length / 2;
        int segments = loop ? points : points - 1;
        float[] samples = new float[0];
        int[] faces = new int[0];
        float[] hits = new float[0];
        boolean[] drawn = new boolean[0];
        int count = 0;
        for (int segment = 0; segment <= segments && points > 0; segment++) {
            int from = segment % points;
            int to = (segment + 1) % points;
            // The last drawn point of an open curve is cast once, on its own.
            int steps = segment == segments ? (loop ? 0 : 1)
                    : Math.max(1, (int) Math.ceil(Math.hypot(pixels[to * 2] - pixels[from * 2],
                            pixels[to * 2 + 1] - pixels[from * 2 + 1])));
            for (int step = 0; step < steps; step++) {
                if (count == faces.length) {
                    int grown = Math.max(1, 2 * count);
                    samples = Arrays.copyOf(samples, grown * 2);
                    faces = Arrays.copyOf(faces, grown);
                    hits = Arrays.copyOf(hits, grown * XYZ);
                    drawn = Arrays.copyOf(drawn, grown);
                }
                float along = step / (float) steps;
                float x = pixels[from * 2] + along * (pixels[to * 2] - pixels[from * 2]);
                float y = pixels[from * 2 + 1] + along * (pixels[to * 2 + 1] - pixels[from * 2 + 1]);
                samples[count * 2] = x;
                samples[count * 2 + 1] = y;
                faces[count] = faceAt(x, y);
                hits[count * XYZ] = hit.x;
                hits[count * XYZ + 1] = hit.y;
                hits[count * XYZ + 2] = hit.z;
                drawn[count] = step == 0;
                count++;
            }
        }
        // Runs of consecutive hits on one piece of the surface; the longest is kept.
        int bestStart = 0;
        int bestEnd = 0;
        for (int start = 0, sample = 0; sample <= count; sample++) {
            boolean breaks = sample == count || faces[sample] < 0 || sample > start
                    && !joined(samples[sample * 2 - 2], samples[sample * 2 - 1], faces[sample - 1],
                            samples[sample * 2], samples[sample * 2 + 1], faces[sample]);
            if (!breaks) {
                continue;
            }
            if (sample - start > bestEnd - bestStart) {
                bestStart = start;
                bestEnd = sample;
            }
            start = sample < count && faces[sample] >= 0 ? sample : sample + 1;
        }
        Piece piece = new Piece();
        piece.positions = Arrays.copyOfRange(hits, bestStart * XYZ, bestEnd * XYZ);
        piece.drawn = new float[bestEnd - bestStart];
        int first = -1;
        int last = -1;
        int drawnTotal = 0;
        for (int sample = 0; sample < count; sample++) {
            drawnTotal += drawn[sample] ? 1 : 0;
            if (sample >= bestStart && sample < bestEnd && drawn[sample]) {
                piece.drawn[sample - bestStart] = 1f;
                first = first < 0 ? sample : first;
                last = sample;
            }
        }
        int kept = 0;
        for (float flag : piece.drawn) {
            kept += (int) flag;
        }
        piece.dropped = drawnTotal - kept;
        piece.closed = loop && bestStart == 0 && bestEnd == count && count > 0
                && joined(samples[count * 2 - 2], samples[count * 2 - 1], faces[count - 1], samples[0], samples[1],
                        faces[0]);
        // A ring drawn across the visible side lies in the plane holding the rays through its first
        // and last drawn points, and runs on round the back.
        float[] origin0 = new float[XYZ];
        float[] direction0 = new float[XYZ];
        if (first >= 0 && last > first
                && camera.rayThroughPixel(model, samples[first * 2], samples[first * 2 + 1], sketch.cellWidth,
                        sketch.cellHeight, origin0, direction0)
                && camera.rayThroughPixel(model, samples[last * 2], samples[last * 2 + 1], sketch.cellWidth,
                        sketch.cellHeight, origin, direction)) {
            // The first ray's near point to the second's far point lies in that plane, for an
            // orthographic camera as for a perspective one.
            Vector3f across = new Vector3f(origin[0] + direction[0] - origin0[0],
                    origin[1] + direction[1] - origin0[1], origin[2] + direction[2] - origin0[2]);
            across.cross(direction0[0], direction0[1], direction0[2]).normalize();
            piece.normal = across.isFinite() ? new float[] { across.x, across.y, across.z } : piece.normal;
        }
        return piece;
    }

    /**
     * The face a pixel's ray meets first, its hit point left in {@link #hit}.
     *
     * @param x pixel x in the cell
     * @param y pixel y in the cell
     * @return the face, -1 when the ray misses
     */
    private int faceAt(float x, float y) {
        hit.set(Float.NaN);
        if (!camera.rayThroughPixel(model, x, y, sketch.cellWidth, sketch.cellHeight, origin, direction)) {
            return -1;
        }
        int triangle = bvh.nearestHit(origin, direction, Double.POSITIVE_INFINITY, stack);
        if (triangle < 0) {
            return -1;
        }
        float along = (float) bvh.hitParameter;
        hit.set(origin[0] + along * direction[0], origin[1] + along * direction[1], origin[2] + along * direction[2]);
        return faceOfTriangle[triangle];
    }

    /**
     * Whether two neighbouring rays land on one piece of the surface: their faces touch, or the ray
     * halfway between them lands on a face joined to both. Bisection stops when the halfway pixel
     * is no longer between them, so a gap that never closes is a break.
     *
     * @return true when the hits are joined
     */
    private boolean joined(float x0, float y0, int face0, float x1, float y1, int face1) {
        if (face0 == face1) {
            return true;
        }
        for (int at0 = 0; at0 < mesh.faceVertexCount(face0); at0++) {
            for (int at1 = 0; at1 < mesh.faceVertexCount(face1); at1++) {
                if (mesh.faceVertexAt(face0, at0) == mesh.faceVertexAt(face1, at1)) {
                    return true;
                }
            }
        }
        float x = (x0 + x1) / 2f;
        float y = (y0 + y1) / 2f;
        if (x == x0 && y == y0 || x == x1 && y == y1) {
            return false;
        }
        int face = faceAt(x, y);
        return face >= 0 && joined(x0, y0, face0, x, y, face) && joined(x, y, face, x1, y1, face1);
    }

}
