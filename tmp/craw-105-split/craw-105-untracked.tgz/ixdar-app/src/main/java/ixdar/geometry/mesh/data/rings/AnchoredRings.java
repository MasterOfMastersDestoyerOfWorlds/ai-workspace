package ixdar.geometry.mesh.data.rings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.bundle.EdgeMarks;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.paths.geodesic.SurfaceGeodesics;
import ixdar.geometry.mesh.data.paths.geodesic.TracedSurfacePath;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.paths.spline.SurfaceSpline;
import ixdar.geometry.mesh.data.paths.spline.SurfaceSplineTracer;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * The rings and bisectors a bundle carries as traced splines, held while {@link RingAnchorFit}
 * moves their anchors: each is traced again through moved anchors, and a bisector follows the
 * ring it ends on.
 */
public final class AnchoredRings implements RingAnchorFit.Tracer {

    /** Label of each ring, in the order the bundle carries them. */
    public final String[] labels;

    /** Each ring as it now stands, by the order of {@link #labels}. */
    public final SurfaceSpline[] splines;

    /** The fit moving the rings, holding each by the same order. */
    public final RingAnchorFit fit;

    private final GeometryBundle bundle;
    private final SurfaceGeodesics geodesics;
    private final SurfaceCreases creases;
    private SurfaceSpline tried;
    // The rings as they stood before the last try.
    private SurfaceSpline[] stoodSplines;
    private List<TracedSurfacePath> stoodPaths;
    private List<int[]> stoodAnchors;

    /**
     * Reads every spline a bundle carries and adds each to a fit of its own: one that cannot be
     * traced again counts as a ring but stays as it is.
     *
     * @param bundle    bundle carrying the splines and their edge marks
     * @param geodesics engine over the bundle's surface
     * @param creases   groove strength of that surface
     */
    public AnchoredRings(GeometryBundle bundle, SurfaceGeodesics geodesics, SurfaceCreases creases) {
        this.bundle = bundle;
        this.geodesics = geodesics;
        this.creases = creases;
        Map<?, ?> carried = bundle.slots().get(SurfaceSpline.SLOT) instanceof Map<?, ?> map ? map : Map.of();
        labels = new String[carried.size()];
        splines = new SurfaceSpline[carried.size()];
        fit = new RingAnchorFit(geodesics.mesh, creases.valleyStrength, creases.valleyCurvature);
        int ring = 0;
        for (Map.Entry<?, ?> entry : carried.entrySet()) {
            labels[ring] = String.valueOf(entry.getKey());
            splines[ring] = (SurfaceSpline) entry.getValue();
            fit.add(splines[ring].path, authored(splines[ring]), splines[ring].anchorsMove
                    ? RingAnchorFit.FIRST_STRIDE : 0);
            ring++;
        }
    }

    @Override
    public TracedSurfacePath trace(int ring, int[] anchorVertexId) {
        // The ring is tried with every bisector that ends on it following, so what the fit
        // weighs is the rings as they would all stand; a try that is dropped puts them back.
        stoodSplines = splines.clone();
        stoodPaths = new ArrayList<>(fit.paths);
        stoodAnchors = new ArrayList<>(fit.anchors);
        TracedSurfacePath path = retrace(ring, anchorVertexId);
        if (path != null) {
            follow(ring);
        }
        return path;
    }

    @Override
    public void settle(int ring, boolean kept) {
        for (int other = 0; !kept && other < splines.length; other++) {
            splines[other] = stoodSplines[other];
            fit.paths.set(other, stoodPaths.get(other));
            fit.anchors.set(other, stoodAnchors.get(other));
        }
    }

    /**
     * Has every bisector that ends on a ring trace again from where the ring now stands, and so
     * on down those that end on them.
     *
     * @param ring the ring that moved, by the order of {@link #labels}
     */
    private void follow(int ring) {
        splines[ring] = tried;
        for (int other = 0; other < splines.length; other++) {
            if (other != ring && splines[other].anchorsMove
                    && Arrays.asList(splines[other].endWalls).contains(labels[ring])) {
                int[] anchors = authored(splines[other]);
                TracedSurfacePath followed = retrace(other, anchors);
                if (followed != null) {
                    fit.paths.set(other, followed);
                    fit.anchors.set(other, anchors);
                    follow(other);
                }
            }
        }
    }

    /**
     * Traces one ring or bisector through anchors into {@link #tried}, a bisector's two ends put
     * back on the rings they end on.
     *
     * @param ring           the ring, by the order of {@link #labels}
     * @param anchorVertexId the anchors to trace through, its ends replaced in place
     * @return the traced path, or {@code null} when none runs through them
     */
    private TracedSurfacePath retrace(int ring, int[] anchorVertexId) {
        SurfaceSpline stands = splines[ring];
        tried = null;
        if (stands.endWalls.length == 0) {
            AuthoredSplineRing round = new AuthoredSplineRing(geodesics);
            round.mode = stands.crease ? RingSegmentMode.CREASE : RingSegmentMode.GEODESIC;
            round.creases = creases;
            if (round.trace(anchorVertexId, anchorVertexId.length, stands.baseNormal.length
                    == RingAnchorFit.COORDINATES_PER_POINT ? stands.baseNormal : null,
                    SurfaceSplineTracer.DEFAULT_MAXIMUM_DEPTH)) {
                tried = SurfaceSpline.of(round.tracer);
            }
        } else {
            // Each end goes back on the ring it ends on, as that ring now stands.
            boolean[][] walls = new boolean[2][];
            Vector3f end = new Vector3f();
            MeshTopology mesh = geodesics.mesh;
            for (int side = 0; side < 2; side++) {
                int wall = Arrays.asList(labels).indexOf(stands.endWalls[side]);
                walls[side] = wall >= 0 ? splines[wall].marks.markedByEdgeId
                        : EdgeMarks.bools(bundle, stands.endWalls[side]);
                int last = side * (anchorVertexId.length - 1);
                mesh.vertexPosition(anchorVertexId[last], end);
                anchorVertexId[last] = walls[side] == null ? -1
                        : RingAttachment.attach(mesh, walls[side], end.x, end.y, end.z);
            }
            if (anchorVertexId[0] >= 0 && anchorVertexId[anchorVertexId.length - 1] >= 0) {
                tried = SurfaceSpline.bisector(geodesics, stands.crease ? creases : null, anchorVertexId.clone(),
                        walls[0], walls[1]);
            }
        }
        if (tried == null || tried.marks.markedEdgeCount == 0) {
            tried = null;
            return null;
        }
        tried.anchorsMove = stands.anchorsMove;
        tried.crease = stands.crease;
        tried.baseNormal = stands.baseNormal;
        tried.endWalls = stands.endWalls;
        return tried.path;
    }

    /**
     * A field look of the fit over the rings a bundle carries, see {@link RingAnchorFit#field}.
     *
     * @param bundle    bundle carrying the splines
     * @param geodesics engine over the bundle's surface
     * @param creases   groove strength of that surface
     * @param paid      true for what each vertex pays, false for the groove bottoms
     * @return one value per active vertex, in active order
     */
    public static float[] look(GeometryBundle bundle, SurfaceGeodesics geodesics, SurfaceCreases creases,
            boolean paid) {
        return new AnchoredRings(bundle, geodesics, creases).fit.field(paid);
    }

    /**
     * The anchors the user placed on a spline, in ring order.
     *
     * @param spline the spline
     * @return its authored anchors' vertex ids
     */
    public static int[] authored(SurfaceSpline spline) {
        int[] authored = new int[spline.authoredCount()];
        int count = 0;
        for (int anchor = 0; anchor < spline.anchorCount; anchor++) {
            if (spline.anchorAuthored[anchor]) {
                authored[count++] = spline.anchorVertexId[anchor];
            }
        }
        return authored;
    }
}
