package ixdar.tools.ring;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import ixdar.geometry.mesh.data.bundle.CurveGeometry;
import ixdar.geometry.mesh.data.paths.spline.SurfaceWaypoints;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.GeodesicRefit;
import ixdar.geometry.mesh.data.rings.RingSegmentMode;
import ixdar.geometry.mesh.data.sculpt.CurveProjection;
import ixdar.geometry.mesh.data.sculpt.StrokeSketch;
import ixdar.platform.Platforms;
import ixdar.platform.input.KeyNames;
import ixdar.platform.input.Keys;
import ixdar.scenes.ring.RingScene;
import ixdar.tools.ControlHint;

/**
 * Rings drawn as lines: a drag along a groove is cast onto the surface as project_curves casts an
 * SVG line, and drafted as a crease ring through its ends. A confirmed stroke ring is saved as its
 * line in the model's strokes SVG and a {@code spline_ring(curve=k)} reading it.
 */
public final class StrokeRingTool extends RingSubTool {

    public static final String TOOL_NAME = "stroke";

    public static final String STROKE_KIND = "ring";


    // Drag samples closer than this to the last one add nothing a ray a pixel would not.
    private static final float MINIMUM_POINT_GAP_PIXELS = 2f;

    /** Whether a drawn line drafts a cut between two walls rather than a closed ring. */
    public boolean cuts;

    private boolean drawing;

    private float[] strokePixels = new float[64];

    private int strokePointsDrawn;

    private CurveProjection projection;

    private String lookBeforeDrawing = RingScene.DEFAULT_LOOK;

    /**
     * The stroke interaction of a ring tool.
     *
     * @param ringTool the ring tool owning it
     */
    public StrokeRingTool(RingTool ringTool) {
        super(ringTool);
    }

    @Override
    public String toolName() {
        return TOOL_NAME;
    }

    @Override
    public String desc() {
        return "Draw a line along a groove to draft a crease ring round the part there";
    }

    @Override
    public void activate() {
        ringTool.lastRow = "drag a line along a groove on the visible side; the ring runs on round the back "
                + "(Esc: back to rings)";
        // Drawing opens in the strokes look by picking it, so M and the shading command still
        // change it: the grooves a line follows show in the curvature look, not in this one.
        RingScene scene = ringTool.scene;
        lookBeforeDrawing = scene.looks.picked.id;
        scene.setLook(RingScene.STROKES_LOOK, scene.headlight);
        scene.refreshControls();
    }

    @Override
    public void deactivate() {
        drawing = false;
        strokePointsDrawn = 0;
        ringTool.liveTrail = new float[0];
        // A look picked while drawing stays; only the strokes look this tool picked goes back.
        RingScene scene = ringTool.scene;
        if (scene.looks.isPicked(RingScene.STROKES_LOOK)) {
            scene.setLook(lookBeforeDrawing, scene.headlight);
        }
    }

    @Override
    public void addControls(List<ControlHint> controls) {
        controls.add(new ControlHint(ControlHint.NO_KEY, "drag", cuts
                ? "draw a cut from one ring or bisector to another, keeping the draft before"
                : "draw a ring's line, keeping the one before"));
        // C switches what a line becomes, as T switches a ring's mode: a closed ring round the
        // part, or an open cut whose two ends sit on the walls nearest them.
        controls.add(new ControlHint("toggle-stroke-cut", Keys.C, "C", cuts ? "lines: cuts between walls, switch "
                + "to rings" : "lines: rings, switch to cuts between walls", () -> {
                    cuts = !cuts;
                    ringTool.lastRow = cuts ? "a line now drafts a cut: start and end it on or beside a ring or "
                            + "bisector" : "a line now drafts a ring round the part";
                    ringTool.scene.refreshControls();
                }));
        controls.add(new ControlHint("discard-draft", Keys.X, "X", "discard draft",
                ringTool.refusalShown(() -> discardDraft())));
        // Esc is the scene's key, which asks the tool; the row only says what it does here.
        controls.add(new ControlHint(ControlHint.NO_KEY, "esc", "back to clicking rings"));
    }

    /**
     * Start a line at the press. With a draft open, a press on one of its anchors drags that
     * anchor instead, and a press anywhere else keeps the draft as a ring and starts the next
     * line; Shift or Ctrl leave the drag to the camera.
     *
     * @param x    framebuffer x of the press
     * @param y    framebuffer y of the press, y up
     * @param mods modifier-key bitmask of the press
     * @return true when the press draws
     */
    @Override
    public boolean onPress(float x, float y, int mods) {
        // A press off the model draws nothing: it is the camera's, to orbit.
        if (ringTool.draft != null && ringTool.hoveredAnchor >= 0 || ringTool.scene.cursorVertexId < 0
                || (mods & (KeyNames.MOD_SHIFT | KeyNames.MOD_CONTROL)) != 0
                || ringTool.draft != null && !ringTool.confirmDraft()) {
            return false;
        }
        drawing = true;
        strokePointsDrawn = 0;
        onDrag(x, y);
        return true;
    }

    /**
     * Add the cursor to the line once it has moved a couple of pixels.
     *
     * @param x framebuffer x of the cursor
     * @param y framebuffer y of the cursor, y up
     */
    @Override
    public void onDrag(float x, float y) {
        float fromTop = Platforms.get().getFrameBufferHeight() - y;
        if (!drawing || strokePointsDrawn > 0 && Math.hypot(x - strokePixels[2 * strokePointsDrawn - 2],
                fromTop - strokePixels[2 * strokePointsDrawn - 1]) < MINIMUM_POINT_GAP_PIXELS) {
            return;
        }
        if (2 * strokePointsDrawn + 2 > strokePixels.length) {
            strokePixels = Arrays.copyOf(strokePixels, 2 * strokePixels.length);
        }
        strokePixels[2 * strokePointsDrawn] = x;
        strokePixels[2 * strokePointsDrawn + 1] = fromTop;
        strokePointsDrawn++;
    }

    /**
     * One frame after the ring tool's pick: while a line is being drawn, the surface point under
     * the cursor joins the line shown, so it appears as it is drawn.
     */
    @Override
    public void perFrame() {
        RingScene scene = ringTool.scene;
        float[] shown = ringTool.liveTrail;
        int last = shown.length - RingTool.COORDINATES_PER_POINT;
        if (!drawing || scene.cursorVertexId < 0 || last >= 0 && shown[last] == scene.cursorPoint[0]
                && shown[last + 1] == scene.cursorPoint[1] && shown[last + 2] == scene.cursorPoint[2]) {
            return;
        }
        // A new array each time: the scene draws the line again when the array is another one.
        ringTool.liveTrail = Arrays.copyOf(shown, shown.length + RingTool.COORDINATES_PER_POINT);
        System.arraycopy(scene.cursorPoint, 0, ringTool.liveTrail, shown.length, RingTool.COORDINATES_PER_POINT);
    }

    /**
     * End the line: cast it onto the surface through the view it was drawn on, keep its longest
     * one-piece run, and draft a crease ring through its drawn points in the plane of its end rays.
     *
     * @param x     framebuffer x of the release
     * @param y     framebuffer y of the release, y up
     * @param click true when the cursor stayed within the click threshold of the press
     * @return true when the press was the tool's
     */
    @Override
    public boolean onRelease(float x, float y, boolean click) {
        if (!drawing) {
            return false;
        }
        onDrag(x, y);
        drawing = false;
        ringTool.liveTrail = new float[0];
        ringTool.lastError = "";
        float[] pixels = Arrays.copyOf(strokePixels, 2 * strokePointsDrawn);
        strokePointsDrawn = 0;
        RingScene scene = ringTool.scene;
        MeshTopology surface = scene.halfEdgeSurface();
        if (click || pixels.length < 2 * 2) {
            ringTool.lastError = "a click draws nothing - drag a line along a groove";
            return true;
        }
        if (surface == null || ringTool.geodesics == null || ringTool.geodesics.mesh != surface
                || !ringTool.readyCreases(surface)) {
            ringTool.lastError = "the ring tool is still readying this surface; draw again in a moment";
            return true;
        }
        StrokeSketch live = new StrokeSketch();
        // Drawn as wide as the strokes look's dots, so the SVG shows the line where it was drawn.
        live.addStroke(STROKE_KIND, 0f, RingScene.STROKE_TRAIL_PIXELS, pixels, scene.camera, scene.isOrthographic(),
                Platforms.get().getFrameBufferWidth(), Platforms.get().getFrameBufferHeight());
        if (projection == null || !projection.over(surface)) {
            projection = new CurveProjection(surface);
        }
        CurveGeometry lifted = projection.project(live, live.curves());
        float[] normal = CurveProjection.normal(lifted, 0);
        if (normal.length == 0) {
            ringTool.lastError = "fewer than two of the line's drawn points landed on one piece of the surface - "
                    + "draw it across the part where it is in view";
            return true;
        }
        // A cut whose ends reach no wall is still a line worth keeping: it drafts as a ring.
        String asRing = "";
        if (cuts) {
            float[] line = lifted.curvePositions(0);
            int points = line.length / RingTool.COORDINATES_PER_POINT;
            if (ringTool.bisector.draftAlong(SurfaceWaypoints.snap(ringTool.geodesics.metric.nearestVertex, line,
                    points), RingSegmentMode.CREASE, Math.min(BisectorTool.DRAWN_STEERING_ANCHORS,
                            points / BisectorTool.DRAWN_POINTS_PER_ANCHOR))) {
                ringTool.lastRow += "; Enter confirms, X discards";
                return true;
            }
            asRing = "; not a cut: " + ringTool.lastError + ", so it is drafted as a ring";
            ringTool.lastError = "";
        }
        if (!ringTool.closedRing.draftThrough(new int[0], RingTool.written(normal), RingSegmentMode.CREASE,
                lifted.curvePositions(0), live)) {
            return true;
        }
        ringTool.lastRow += String.format(Locale.ROOT, " from a drawn line (%.0f of its drawn points off the "
                + "kept piece); Enter confirms, X discards%s",
                lifted.curveAttributes.get(CurveProjection.DROPPED_ATTRIBUTE)[0], asRing);
        return true;
    }

    /**
     * Esc with no draft open goes back to drawing rings by clicks.
     *
     * @return true
     */
    @Override
    public boolean escapePressed() {
        ringTool.switchSubTool(ringTool.closedRing);
        ringTool.lastRow = escapeDescription();
        return true;
    }

    @Override
    public String escapeDescription() {
        return "back to rings";
    }

    @Override
    public boolean addAnchor(int vertexId) {
        return ringTool.closedRing.addAnchor(vertexId);
    }

    @Override
    public boolean retrace(int[] authored, boolean keepSimple) {
        return ringTool.closedRing.retrace(authored, keepSimple);
    }

    @Override
    public GeodesicRefit refitGeodesic() {
        return ringTool.closedRing.refitGeodesic();
    }

    @Override
    public boolean moveAnchor(int selected, int vertexId) {
        return ringTool.closedRing.moveAnchor(selected, vertexId);
    }

    @Override
    public boolean deletePoint() {
        return ringTool.closedRing.deletePoint();
    }

    @Override
    public boolean confirmable() {
        return true;
    }

    @Override
    public String draftDescription() {
        return ringTool.closedRing.draftDescription();
    }

    @Override
    public String draftDetail() {
        return "";
    }

    @Override
    public String draftLabel() {
        return ClosedRingTool.DRAFT_LABEL;
    }

    @Override
    public float[] draftCrossing() {
        return ringTool.closedRing.draftCrossing();
    }

    @Override
    public boolean drawsInvalid() {
        return false;
    }

    @Override
    public int[] markedVertices() {
        return new int[0];
    }

    @Override
    public void draftClosed() {
    }

    /**
     * Stroke rings re-open as rings, under the ring sub-tool.
     *
     * @return false
     */
    @Override
    public boolean reopens(ConfirmedRing ring) {
        return false;
    }

    @Override
    public boolean wallsWhileDrafted() {
        return false;
    }

    /**
     * Drawn rings show the regions they cut the surface into in the strokes look drawing opens
     * in, which colours them itself; another look picked while drawing shows as picked.
     *
     * @return false
     */
    @Override
    public boolean showsRegions() {
        return false;
    }

    @Override
    public String nothingToConfirm() {
        return "no draft to confirm - drag a line along a groove first";
    }

    @Override
    public boolean escapeEditedDraft() {
        return ringTool.closedRing.escapeEditedDraft();
    }

    @Override
    public String escapeAfterUneditedDraft() {
        return "";
    }
}
