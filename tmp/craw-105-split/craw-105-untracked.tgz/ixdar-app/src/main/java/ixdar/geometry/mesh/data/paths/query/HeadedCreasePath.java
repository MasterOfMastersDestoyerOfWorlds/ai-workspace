package ixdar.geometry.mesh.data.paths.query;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.geodesic.SurfaceMetric;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.numeric.graph.Dijkstra;

/**
 * The cheapest crease path between two surface vertices that follows an arrow: the arrow is one
 * angle in each vertex's signpost frame, carried exactly along the path, and an edge costs more
 * the further it points from it.
 */
public final class HeadedCreasePath {

    public static final int XYZ = 3;

    public static final double EXTRA_COST_AGAINST_ARROW = 1.0;

    public static final int SHEETS = 3;

    public static final double TURN_TOLERANCE = 1e-6;

    public static final double ANGLE_POINTING_BACK_ALONG_ARROW = 0.75 * Math.PI;

    /** Metric whose dense vertices, half-edges and signposts the search walks. */
    public final SurfaceMetric metric;

    /** Crease cost per mesh edge the path is cheapest by. */
    public SurfaceCreases creases;

    /** Stamp per dense vertex; a vertex stamped {@link #closedStamp} is closed to the path. */
    public final int[] closedStampByVertex;

    /** The stamp that closes a vertex to the next {@link #trace}; raise it to open them all. */
    public int closedStamp = 1;

    /**
     * Whether a steered path may not turn a full circle against its arrow. Off, it only has to
     * arrive along the arrow, which lets a loop round a cone's tip close.
     */
    public boolean countsTurns = true;

    /**
     * Axis a steered path runs round, xyz, or {@code null} to carry its leaving arrow. Round an
     * axis the arrow at every vertex is the way round it there, which no curvature turns.
     */
    public float[] axis;

    /**
     * Whether a steered path may never point back along its arrow. A drawn line's closure may
     * not: back along the groove the line was drawn in is its cheapest way home.
     */
    public boolean neverBack;

    /** Weighted crease cost of the path the last {@link #trace} found. */
    public double cost;

    private final double[] arrowAngle;
    private final double[] turned;
    private final double[] firstEdgeAngle;
    private final int[] leftFirstSheetAt;
    private final double[] roundAxisAngle;
    private final int[] roundAxisRun;
    private int run;
    private final float[] roundAxis = new float[XYZ];
    private final Dijkstra search = new Dijkstra();
    private final Vector3f position = new Vector3f();
    private final Vector3f normal = new Vector3f();
    private final Vector3f step = new Vector3f();
    private final Vector3f across = new Vector3f();

    /**
     * A search over one surface's metric.
     *
     * @param surfaceMetric metric of the surface the paths run on
     */
    public HeadedCreasePath(SurfaceMetric surfaceMetric) {
        this.metric = surfaceMetric;
        closedStampByVertex = new int[surfaceMetric.sourceVertexId.length];
        arrowAngle = new double[SHEETS * surfaceMetric.sourceVertexId.length + 1];
        turned = new double[SHEETS * surfaceMetric.sourceVertexId.length + 1];
        firstEdgeAngle = new double[SHEETS * surfaceMetric.sourceVertexId.length + 1];
        leftFirstSheetAt = new int[SHEETS * surfaceMetric.sourceVertexId.length + 1];
        roundAxisAngle = new double[surfaceMetric.sourceVertexId.length];
        roundAxisRun = new int[surfaceMetric.sourceVertexId.length];
    }

    /**
     * Find the path from one vertex to another, or round to the same one. Steered, the path never
     * turns a full circle against the leaving arrow it carries, counting its last turn onto the
     * arriving arrow; a loop back to its own vertex is always steered.
     *
     * @param fromVertexId vertex the path leaves
     * @param toVertexId   vertex it arrives at, never closed to it
     * @param leaving      direction the path leaves along, xyz, or {@code null} to run unsteered
     * @param arriving     direction it arrives along, xyz; read only when steered
     * @return the path's mesh vertices, first to last, with {@link #cost} set; {@code null} when
     *         there is none
     */
    public int[] trace(int fromVertexId, int toVertexId, float[] leaving, float[] arriving) {
        int source = metric.vertexIndexByVertexId[fromVertexId];
        int target = metric.vertexIndexByVertexId[toVertexId];
        // A vertex is one state per sheet: the first holds paths that have never pointed against
        // the arrow, the others those that once did, to its left or its right. So a path that
        // went back and turned round never takes a vertex from one that ran on round the
        // surface. The path ends on a state of its own.
        int goal = SHEETS * metric.sourceVertexId.length;
        if (source == target && leaving == null) {
            return null;
        }
        double arrivingAngle = 0.0;
        double arrowAtTarget = 0.0;
        run++;
        search.start(goal + 1);
        search.relax(SHEETS * source, 0.0, -1);
        if (leaving != null) {
            arrowAngle[SHEETS * source] = angleOf(source, leaving);
            arrivingAngle = angleOf(target, arriving);
            arrowAtTarget = axis == null ? 0.0 : roundAxisAt(target);
        }
        int settled = search.settle();
        while (settled >= 0 && settled != goal) {
            double here = search.distance(settled);
            int vertex = settled / SHEETS;
            int cameBy = search.via(settled) < 0 ? -1 : search.via(settled) / SHEETS;
            if (leaving != null && axis != null) {
                // Round an axis the arrow is not carried: it is the way round the axis here, so
                // no curvature the path crosses turns it.
                arrowAngle[settled] = roundAxisAt(vertex);
            }
            // Counter-clockwise round the fan from the reference half-edge, which a boundary
            // vertex's fan starts at, so its last spoke is the exterior one.
            int reference = metric.vertexReferenceHalfEdge[vertex];
            int halfEdge = reference;
            while (halfEdge >= 0) {
                int spoke = halfEdge;
                halfEdge = metric.halfEdgeNext[spoke] < 0 ? -1
                        : metric.halfEdgeNext[metric.halfEdgeNext[spoke]] ^ 1;
                halfEdge = halfEdge == reference ? -1 : halfEdge;
                int edgeId = metric.sourceEdgeId[spoke >> 1];
                int otherActive = metric.halfEdgeTail[spoke ^ 1];
                // Straight back along the edge it came by is a half turn either way round, which
                // no count of turns can place.
                if (edgeId == MeshTopology.NONE || otherActive == cameBy
                        || closedStampByVertex[otherActive] == closedStamp && otherActive != target) {
                    continue;
                }
                if (leaving == null) {
                    search.relax(otherActive == target ? goal : SHEETS * otherActive,
                            here + creases.edgeCost[edgeId], settled);
                    continue;
                }
                // The edge's angle from the arrow, unwound: the path's turns so far add up in it.
                double leavingSpoke = signpost(spoke);
                double fromArrow = wrapped(leavingSpoke - arrowAngle[settled]);
                if (cameBy >= 0) {
                    fromArrow = turned[settled] + wrapped(fromArrow - turned[settled]);
                }
                // The arrow crosses the edge keeping its angle to it: exact transport.
                double carried = arrowAngle[settled] - leavingSpoke + signpost(spoke ^ 1) + Math.PI;
                boolean winds = countsTurns && Math.abs(fromArrow) >= 2.0 * Math.PI
                        || neverBack && Math.abs(fromArrow) > ANGLE_POINTING_BACK_ALONG_ARROW;
                int sheet = settled % SHEETS != 0 ? settled % SHEETS
                        : Math.abs(fromArrow) <= Math.PI / 2.0 ? 0 : fromArrow > 0.0 ? 1 : 2;
                int next = SHEETS * otherActive + sheet;
                if (otherActive == target) {
                    // A loop closes onto its own first edge, so its turns add to a whole number
                    // of circles and that number has to be none.
                    double closesOnto = source != target ? arrivingAngle
                            : cameBy < 0 ? leavingSpoke : firstEdgeAngle[settled];
                    double onto = wrapped(closesOnto - (axis == null ? carried : arrowAtTarget));
                    double total = fromArrow + wrapped(onto - fromArrow);
                    // Uncounted, a loop's last edge only has to come home along its arrow.
                    winds |= countsTurns ? Math.abs(total - onto) > TURN_TOLERANCE
                            : source == target && Math.cos(
                                    signpost(spoke ^ 1) + Math.PI - arrowAngle[SHEETS * source]) < 0.0;
                    next = goal;
                }
                // A path through a vertex twice would cross itself. Only a path that has left the
                // first sheet can: the vertex is then one it passed while still on it.
                int left = sheet == 0 ? -1 : settled % SHEETS == 0 ? settled : leftFirstSheetAt[settled];
                // Costs only fall back along a path, so the walk back stops where they fall below
                // the cost that vertex was passed at.
                boolean passed = left >= 0 && next != goal && search.isReached(SHEETS * otherActive);
                double passedAt = passed ? search.distance(SHEETS * otherActive) : 0.0;
                for (int state = left; passed && !winds && state >= 0 && search.distance(state) >= passedAt;
                        state = search.via(state)) {
                    winds = state / SHEETS == otherActive;
                }
                // Only an edge pointing back along the arrow costs more: a path zigzags along a
                // groove's edges, and one square to the arrow is as good as one along it.
                double weight = 1.0 + EXTRA_COST_AGAINST_ARROW * Math.max(0.0, -Math.cos(fromArrow));
                if (!winds && search.relax(next, here + weight * creases.edgeCost[edgeId], settled)) {
                    arrowAngle[next] = carried;
                    turned[next] = fromArrow;
                    leftFirstSheetAt[next] = left;
                    firstEdgeAngle[next] = cameBy < 0 ? leavingSpoke : firstEdgeAngle[settled];
                }
            }
            settled = search.settle();
        }
        if (settled != goal) {
            return null;
        }
        cost = search.distance(goal);
        int length = 0;
        for (int state = goal; state >= 0; state = search.via(state)) {
            length++;
        }
        int[] path = new int[length];
        for (int state = goal; state >= 0; state = search.via(state)) {
            path[--length] = state == goal ? toVertexId : metric.sourceVertexId[state / SHEETS];
        }
        return path;
    }

    /** Angle at a vertex of the way round {@link #axis} there: the axis crossed with its normal. */
    private double roundAxisAt(int vertex) {
        // One search settles a vertex once per sheet, and the way round the axis is the same on
        // each.
        if (roundAxisRun[vertex] == run) {
            return roundAxisAngle[vertex];
        }
        roundAxisRun[vertex] = run;
        metric.sourceMesh.vertexNormal(metric.sourceVertexId[vertex], normal);
        across.set(axis[0], axis[1], axis[2]).cross(normal);
        roundAxis[0] = across.x;
        roundAxis[1] = across.y;
        roundAxis[2] = across.z;
        roundAxisAngle[vertex] = angleOf(vertex, roundAxis);
        return roundAxisAngle[vertex];
    }

    /** An angle brought within half a turn of zero, as {@link Math#IEEEremainder} brings it. */
    private static double wrapped(double angle) {
        return angle - 2.0 * Math.PI * Math.rint(angle / (2.0 * Math.PI));
    }

    /**
     * Angle of a half-edge at its tail, its signpost scaled so the angles round a vertex fill one
     * full turn whatever the curvature there.
     */
    private double signpost(int halfEdge) {
        double sum = metric.vertexAngleSum[metric.halfEdgeTail[halfEdge]];
        return sum <= 0.0 ? 0.0 : metric.signpostAngle[halfEdge] * 2.0 * Math.PI / sum;
    }

    /**
     * Angle of a direction at a vertex: the signpost of the spoke nearest it, less the turn from
     * the direction to that spoke about the vertex normal.
     */
    private double angleOf(int vertex, float[] direction) {
        MeshTopology mesh = metric.sourceMesh;
        mesh.vertexPosition(metric.sourceVertexId[vertex], position);
        mesh.vertexNormal(metric.sourceVertexId[vertex], normal);
        // The nearest spoke is the one whose turn has the largest cosine, which needs no arc
        // tangent to compare.
        double nearest = Double.NEGATIVE_INFINITY;
        double sine = 0.0;
        double cosine = 1.0;
        int nearestSpoke = -1;
        int reference = metric.vertexReferenceHalfEdge[vertex];
        int halfEdge = reference;
        while (halfEdge >= 0) {
            int spoke = halfEdge;
            halfEdge = metric.halfEdgeNext[spoke] < 0 ? -1
                    : metric.halfEdgeNext[metric.halfEdgeNext[spoke]] ^ 1;
            halfEdge = halfEdge == reference ? -1 : halfEdge;
            mesh.vertexPosition(metric.sourceVertexId[metric.halfEdgeTail[spoke ^ 1]], step);
            step.sub(position);
            across.set(direction[0], direction[1], direction[2]).cross(step);
            double sin = across.dot(normal);
            double cos = step.x * direction[0] + step.y * direction[1] + step.z * direction[2];
            double length = Math.sqrt(sin * sin + cos * cos);
            if (length > 0.0 && cos / length > nearest) {
                nearest = cos / length;
                sine = sin;
                cosine = cos;
                nearestSpoke = spoke;
            }
        }
        return nearestSpoke < 0 ? 0.0 : signpost(nearestSpoke) - Math.atan2(sine, cosine);
    }
}
