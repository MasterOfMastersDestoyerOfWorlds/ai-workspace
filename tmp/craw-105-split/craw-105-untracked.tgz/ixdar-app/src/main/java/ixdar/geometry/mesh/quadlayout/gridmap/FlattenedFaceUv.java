package ixdar.geometry.mesh.quadlayout.gridmap;

import org.joml.Vector3d;
import org.joml.Vector3f;

import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.nodegraph.field.UvField;

/**
 * Every triangle of a surface laid flat as it is, its first corner at the origin and its first
 * edge along u: the reference a grid map is measured against where no parametrization exists.
 */
public final class FlattenedFaceUv implements UvField {

    /** Surface whose triangles are laid flat. */
    public final MeshTopology mesh;

    private final Vector3f corner = new Vector3f();

    /**
     * Stores the surface to read triangles from.
     *
     * @param mesh triangle surface
     */
    public FlattenedFaceUv(MeshTopology mesh) {
        this.mesh = mesh;
    }

    @Override
    public double u(int faceId, int corner) {
        return flat(faceId, corner, false);
    }

    @Override
    public double v(int faceId, int corner) {
        return flat(faceId, corner, true);
    }

    /**
     * One coordinate of a corner of a triangle laid flat.
     *
     * @param faceId mesh face id
     * @param index  corner index in {@code [0, 3)}
     * @param across whether to read v, the coordinate across the first edge, rather than u
     * @return the coordinate, in surface length
     */
    private double flat(int faceId, int index, boolean across) {
        if (index == 0) {
            return 0;
        }
        Vector3d origin = new Vector3d(mesh.vertexPosition(mesh.faceVertexAt(faceId, 0), corner));
        Vector3d along = new Vector3d(mesh.vertexPosition(mesh.faceVertexAt(faceId, 1), corner)).sub(origin);
        double length = along.length();
        if (index == 1) {
            return across ? 0 : length;
        }
        Vector3d reach = new Vector3d(mesh.vertexPosition(mesh.faceVertexAt(faceId, 2), corner)).sub(origin);
        double onEdge = reach.dot(along) / Math.max(length, Double.MIN_NORMAL);
        return across ? Math.sqrt(Math.max(0, reach.lengthSquared() - onEdge * onEdge)) : onEdge;
    }
}
