package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;
import ixdar.nodegraph.runtime.GraphNodeContext;
import ixdar.nodegraph.runtime.GroupBuilder;
import ixdar.nodegraph.runtime.NodeGroup;

/**
 * Fits every ring and bisector on a surface to its grooves as curves, a compiled group of stage
 * nodes the way quad_layout is: assemble the curves' DOF system, relax it, extract the marks.
 */
@MeshNodeAnnotation(id = FitRingsNode.NODE_ID, desktopOnly = true, category = NodeCategory.SELECTION)
public class FitRingsNode extends NodeGroup {

    public static final String NODE_ID = "fit_rings";

    public static final String DOFS_PORT = RingCurvesNode.DOFS.name;

    public static final InputPort GEOMETRY = RingCurvesNode.GEOMETRY;
    public static final InputPort CREASES = RingCurvesNode.CREASES;
    public static final InputPort LABELS = RingCurvesNode.LABELS;
    public static final InputPort BAND = RingCurvesNode.BAND;
    public static final InputPort PULL = RingCurvesNode.PULL;
    public static final InputPort SMOOTHNESS = RingCurvesNode.SMOOTHNESS;
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort REPORT = FittedRingMarksNode.REPORT;
    public static final OutputPort DOFS = new OutputPort(DOFS_PORT, PortType.DOF_SYSTEM);
    public static final OutputPort TMESH = FittedRingMarksNode.TMESH;

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CREASES, LABELS, BAND, PULL, SMOOTHNESS);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, REPORT, DOFS, TMESH);
    }

    @Override
    public String description() {
        return "Fits every ring and bisector to the grooves together, as a group of its stage "
                + "nodes: ring_curves cuts the walls into curves where they meet and builds the "
                + "DOF system of the curve points' offsets across their curves, newton_solver "
                + "relaxes it (damped Newton on a sparse Cholesky factor), and fitted_ring_marks "
                + "carves the curves into a copy of the surface as an arc network, the way "
                + "quad_layout embeds its arcs. A curve beside a groove slides "
                + "into it and stays smooth across the groove's gaps; the points where walls "
                + "meet stay put, and every ring keeps its label.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying ring edge marks, after the last spline_ring and "
                        + "spline_cut statement. Output: a refined copy of the surface with a "
                        + "vertex wherever a fitted wall crosses an edge, carrying every ring's "
                        + "marks along its fitted wall and the part labels.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "when not wired.",
                LABELS.name,
                "Comma-separated edge-mark labels to fit. Empty takes every boolean edge-mark "
                        + "label on the bundle, which after the ring nodes is every ring.",
                BAND.name,
                "How far a curve point may slide either side of where it was drawn, in mean edge "
                        + "lengths.",
                PULL.name,
                "Weight of the groove depth under a curve point; 0 only smooths the curves.",
                SMOOTHNESS.name,
                "Weight of the curves' stretch and bend.",
                REPORT.name,
                "How many curves and points were fitted and moved, the Newton iterations and "
                        + "energies, the walls as drawn and fitted, and the region and sliver "
                        + "counts before and after.",
                DOFS_PORT,
                "The relaxed DOF system of the offsets.",
                TMESH.name,
                "The walls as an arc network carved into the output surface.");
    }

    @Override
    public void build(GroupBuilder group) {
        GraphNodeContext parameters = group.scope;
        GraphNodeContext curves = group.node("curves", RingCurvesNode::new)
                .input(RingCurvesNode.GEOMETRY.name, parameters, GEOMETRY.name)
                .input(RingCurvesNode.CREASES.name, parameters, CREASES.name)
                .input(RingCurvesNode.LABELS.name, parameters, LABELS.name)
                .input(RingCurvesNode.BAND.name, parameters, BAND.name)
                .input(RingCurvesNode.PULL.name, parameters, PULL.name)
                .input(RingCurvesNode.SMOOTHNESS.name, parameters, SMOOTHNESS.name);
        GraphNodeContext relax = group.node("relax", SettleRingsNode.RELAX_TYPE)
                .input(DOFS_PORT, curves, DOFS_PORT);
        GraphNodeContext marks = group.node("marks", FittedRingMarksNode::new)
                .input(FittedRingMarksNode.GEOMETRY.name, curves, RingCurvesNode.GEOMETRY_OUT.name)
                .input(FittedRingMarksNode.DOFS.name, relax, DOFS_PORT);

        group.output(GEOMETRY_OUT.name, marks, FittedRingMarksNode.GEOMETRY_OUT.name);
        group.output(REPORT.name, marks, FittedRingMarksNode.REPORT.name);
        group.output(DOFS_PORT, relax, DOFS_PORT);
        group.output(TMESH.name, marks, FittedRingMarksNode.TMESH.name);
    }
}
