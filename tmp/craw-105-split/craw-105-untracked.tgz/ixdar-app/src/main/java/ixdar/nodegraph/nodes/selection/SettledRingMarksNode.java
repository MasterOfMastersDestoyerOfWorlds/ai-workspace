package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.EdgeMarks;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.data.rings.RingSettle;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The extraction stage of settle_rings: turns the relaxed ring memberships into ring edge marks,
 * the borders between the settled regions.
 */
@MeshNodeAnnotation(id = SettledRingMarksNode.NODE_ID, category = NodeCategory.SELECTION)
public class SettledRingMarksNode implements MeshNode {

    public static final String NODE_ID = "settled_ring_marks";

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort DOFS = new InputPort("dofs", PortType.DOF_SYSTEM, null);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort REPORT = new OutputPort("report", PortType.STRING);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, DOFS);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, REPORT);
    }

    @Override
    public String description() {
        return "Turns relaxed ring memberships into ring marks. The settled regions are tidied "
                + "(one-face teeth taken off the walls, islands with no pinned face given to "
                + "their neighbour), and the borders between them replace the ring marks, each "
                + "stretch under the label of the ring that separated its two regions as drawn. "
                + "A stretch whose ring would wall nothing goes to a ring that walls.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: the bundle a ring_membership node put the regions to settle on. Output: "
                        + "the same bundle with every ring's marks replaced by its settled ones.",
                DOFS.name,
                "The relaxed DOF system, from the newton_solver node that relaxed the "
                        + "ring_membership node's: wiring it runs the relaxation first.",
                REPORT.name,
                "How many faces were free and how many moved, the walls' length and mean groove "
                        + "depth as drawn and settled, and the region and sliver counts before "
                        + "and after.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (bundle == null || !(bundle.slots().get(RingSettle.SLOT) instanceof RingSettle settle)) {
            ctx.setOutput(GEOMETRY.name, bundle == null ? GeometryBundle.empty() : bundle);
            ctx.setOutput(REPORT.name, "");
            return;
        }
        int tidied = settle.tidy();
        boolean[][] masks = settle.marks();
        RingRegions drawn = settle.regions;
        GeometryBundle out = bundle;
        for (int ring = 0; ring < masks.length; ring++) {
            out = EdgeMarks.with(out, drawn.ringLabels[ring], masks[ring]);
        }
        RingRegions settled = new RingRegions(settle.mesh, drawn.ringLabels, masks).build();
        int[] slivers = new int[2];
        for (int region = 0; region < Math.max(drawn.regionCount, settled.regionCount); region++) {
            slivers[0] += region < drawn.regionCount && drawn.isSliver(region) ? 1 : 0;
            slivers[1] += region < settled.regionCount && settled.isSliver(region) ? 1 : 0;
        }
        ctx.setOutput(GEOMETRY.name, out);
        ctx.setOutput(REPORT.name, String.format(Locale.ROOT, "%s; %d tooth and island faces tidied; regions "
                + "%d -> %d, slivers %d -> %d", settle.report(), tidied, drawn.regionCount, settled.regionCount,
                slivers[0], slivers[1]));
    }
}
