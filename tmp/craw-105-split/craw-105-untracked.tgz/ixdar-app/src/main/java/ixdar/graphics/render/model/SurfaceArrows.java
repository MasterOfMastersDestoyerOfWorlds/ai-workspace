package ixdar.graphics.render.model;

import java.util.List;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.representation.HalfEdgeMeshOps;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.AuthoredSplineRing;

/**
 * Solid arrows at the two ends of lines on a surface, each a shaft and a cone head pointing away
 * from the line along the way it runs there: where the line goes on from each end.
 */
public final class SurfaceArrows {

    public static final int XYZ = 3;

    public static final int SIDES = 12;

    public static final float LENGTH_OF_LINE = 0.25f;

    public static final float SHAFT_RADIUS_OF_LENGTH = 0.04f;

    public static final float HEAD_RADIUS_OF_LENGTH = 0.12f;

    public static final float HEAD_OF_LENGTH = 0.4f;

    public static final int VERTICES_PER_ARROW = 3 * SIDES + 2;

    public static final int CORNERS_PER_ARROW = XYZ * 4 * SIDES;

    private SurfaceArrows() {
    }

    /**
     * Build one mesh of two arrows per line. A line heads at each end along the chord over its
     * first or last {@link AuthoredSplineRing#LINE_SHARES_PER_HEADING}th.
     *
     * @param lines each line's points in order, packed xyz
     * @return the arrows, or {@code null} when no line has two points
     */
    public static MeshTopology atLineEnds(List<float[]> lines) {
        int arrows = 0;
        for (float[] line : lines) {
            arrows += line.length >= 2 * XYZ ? 2 : 0;
        }
        if (arrows == 0) {
            return null;
        }
        float[] positions = new float[XYZ * VERTICES_PER_ARROW * arrows];
        int[] faces = new int[CORNERS_PER_ARROW * arrows];
        Vector3f base = new Vector3f();
        Vector3f heading = new Vector3f();
        Vector3f side = new Vector3f();
        Vector3f other = new Vector3f();
        int arrow = 0;
        for (float[] line : lines) {
            int points = line.length / XYZ;
            if (points < 2) {
                continue;
            }
            int last = XYZ * (points - 1);
            int reach = XYZ * Math.max(1, (points - 1) / AuthoredSplineRing.LINE_SHARES_PER_HEADING);
            float length = LENGTH_OF_LINE * Vector3f.distance(line[0], line[1], line[2], line[last],
                    line[last + 1], line[last + 2]);
            for (int end = 0; end < 2; end++) {
                int from = end == 0 ? 0 : last - reach;
                heading.set(line[from + reach] - line[from], line[from + reach + 1] - line[from + 1],
                        line[from + reach + 2] - line[from + 2]).normalize(end == 0 ? -1f : 1f);
                // Each arrow begins on its end of the line and points away from the line.
                int at = end == 0 ? 0 : last;
                base.set(line[at], line[at + 1], line[at + 2]);
                side.set(Math.abs(heading.x) < Math.abs(heading.y) ? 1f : 0f,
                        Math.abs(heading.x) < Math.abs(heading.y) ? 0f : 1f, 0f);
                side.cross(heading).normalize();
                heading.cross(side, other);
                int first = VERTICES_PER_ARROW * arrow;
                int corner = CORNERS_PER_ARROW * arrow;
                for (int step = 0; step < SIDES; step++) {
                    double angle = 2.0 * Math.PI * step / SIDES;
                    float cos = (float) Math.cos(angle);
                    float sin = (float) Math.sin(angle);
                    // Three rings: the shaft's foot, the shaft's top and the head's rim.
                    for (int ring = 0; ring < XYZ; ring++) {
                        float radius = length * (ring == 2 ? HEAD_RADIUS_OF_LENGTH : SHAFT_RADIUS_OF_LENGTH);
                        float along = ring == 0 ? 0f : length * (1f - HEAD_OF_LENGTH);
                        int vertex = XYZ * (first + SIDES * ring + step);
                        positions[vertex] = base.x + along * heading.x + radius * (cos * side.x + sin * other.x);
                        positions[vertex + 1] = base.y + along * heading.y + radius * (cos * side.y + sin * other.y);
                        positions[vertex + 2] = base.z + along * heading.z + radius * (cos * side.z + sin * other.z);
                    }
                    int next = (step + 1) % SIDES;
                    int tip = first + 3 * SIDES;
                    int[] triangles = { first + step, first + next, first + SIDES + next, first + step,
                        first + SIDES + next, first + SIDES + step, first + 2 * SIDES + step,
                        first + 2 * SIDES + next, tip, tip + 1, first + 2 * SIDES + next, first + 2 * SIDES + step };
                    System.arraycopy(triangles, 0, faces, corner, triangles.length);
                    corner += triangles.length;
                }
                for (int centre = 0; centre < 2; centre++) {
                    float along = length * (centre == 0 ? 1f : 1f - HEAD_OF_LENGTH);
                    int vertex = XYZ * (first + 3 * SIDES + centre);
                    positions[vertex] = base.x + along * heading.x;
                    positions[vertex + 1] = base.y + along * heading.y;
                    positions[vertex + 2] = base.z + along * heading.z;
                }
                arrow++;
            }
        }
        return HalfEdgeMeshOps.buildFromIndexedMesh(positions, faces);
    }
}
