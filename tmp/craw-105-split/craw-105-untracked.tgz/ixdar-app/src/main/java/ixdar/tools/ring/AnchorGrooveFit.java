package ixdar.tools.ring;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import ixdar.geometry.mesh.data.paths.geodesic.TracedSurfacePath;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingAnchorFit;
import ixdar.platform.Platforms;
import ixdar.tools.Tool;

/**
 * Moves the anchors of every ring and bisector the {@link RingTool} holds into the grooves beside
 * them, by {@link RingAnchorFit}: each kept move is the tool's own edit of that ring.
 */
public final class AnchorGrooveFit {

    /** The tool whose rings are fitted. */
    public final RingTool tool;

    /**
     * A fit of one ring tool's rings.
     *
     * @param tool the tool holding the rings
     */
    public AnchorGrooveFit(RingTool tool) {
        this.tool = tool;
    }

    /**
     * Fit every live ring and bisector that is traced through anchors of its own, an open draft
     * confirmed first; the tool's row says how many anchors moved and how deep the rings run.
     */
    public void run() {
        MeshTopology surface = tool.scene.halfEdgeSurface();
        if (tool.draft != null && !tool.confirmDraft() || !tool.readyCreases(surface)) {
            return;
        }
        long started = System.nanoTime();
        RingAnchorFit fit = new RingAnchorFit(surface, tool.creases.valleyStrength,
                tool.creases.valleyCurvature);
        // A stretch of a ring keeps to the ring it was cut from, and a ring read from a drawn
        // line has no anchors of its own to move.
        List<Integer> held = new ArrayList<>();
        for (int ring = 0; ring < tool.confirmedRings.size(); ring++) {
            ConfirmedRing confirmed = tool.confirmedRings.get(ring);
            if (!confirmed.deleted && confirmed.bisectorStretch == null && confirmed.curve < 0
                    && confirmed.stroke == null && confirmed.spline != null) {
                fit.add(confirmed.spline.path, confirmed.authoredVertexId, RingAnchorFit.FIRST_STRIDE);
                held.add(ring);
            }
        }
        double[] drawn = new double[3];
        for (TracedSurfacePath path : fit.paths) {
            drawn[0] += path.length * fit.depth(path);
            drawn[2] += path.length;
        }
        drawn[1] = fit.energy();
        Tool askedIn = tool.activeSubTool;
        fit.relax(new RingAnchorFit.Tracer() {
            @Override
            public TracedSurfacePath trace(int ring, int[] anchorVertexId) {
                return tool.reopenRing(held.get(ring)) && tool.draftOwner.retrace(anchorVertexId, true)
                        ? tool.draft.path : null;
            }

            @Override
            public void settle(int ring, boolean kept) {
                if (tool.draft != null && !(kept && tool.confirmDraft())) {
                    tool.discardDraft();
                }
                // A kept ring takes the bisectors that end on it along, so every ring is read again.
                for (int other = 0; kept && other < held.size(); other++) {
                    ConfirmedRing confirmed = tool.confirmedRings.get(held.get(other));
                    fit.paths.set(other, confirmed.spline.path);
                    fit.anchors.set(other, confirmed.authoredVertexId);
                }
            }
        });
        double[] fitted = new double[3];
        for (TracedSurfacePath path : fit.paths) {
            fitted[0] += path.length * fit.depth(path);
            fitted[2] += path.length;
        }
        fitted[1] = fit.energy();
        tool.switchSubTool(askedIn);
        tool.lastError = "";
        tool.lastRow = String.format(Locale.ROOT, "anchors fitted to grooves: %d rings, %d anchor moves in %d rounds; "
                + "walls %.2f long at mean groove depth %.3f and energy %.2f as drawn, %.2f long at %.3f and %.2f "
                + "fitted; %.1f s", held.size(), fit.movedAnchors, fit.rounds, drawn[2], drawn[0] / Math.max(drawn[2],
                        Double.MIN_NORMAL), drawn[1], fitted[2], fitted[0] / Math.max(fitted[2], Double.MIN_NORMAL), fitted[1],
                (System.nanoTime() - started) / 1e9);
        Platforms.get().log(RingTool.LOG_PREFIX + tool.lastRow);
        tool.scene.refreshControls();
    }
}
