package ixdar.geometry.mesh.data.rings;

import java.util.Arrays;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.geodesic.SurfaceMetric;
import ixdar.geometry.mesh.data.paths.query.HeadedCreasePath;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * The closed crease path through a ring's anchors in their order: each span a
 * {@link HeadedCreasePath} that runs on round the ring's plane, or, after a drawn line, the way
 * the line was heading when it stopped.
 */
public final class CreaseRingLoop {

    public static final int XYZ = 3;

    public static final int PASSES = 2;

    public static final int ATTEMPTS = 5;

    public static final int STEERED = 3;

    /** The search each span is found by. */
    public final HeadedCreasePath span;

    /**
     * Mesh vertices of each span of the last loop laid, from its anchor to the next anchor
     * inclusive; a span with no path is {@code null}.
     */
    public int[][] spanPath = new int[0][];

    /** Spans of the last loop that found no path heading their way and run unsteered. */
    public int unsteeredSpans;

    private final int[] spanByVertex;
    private final Vector3f normal = new Vector3f();
    private final Vector3f round = new Vector3f();

    /**
     * A loop search over one surface's metric.
     *
     * @param metric metric of the surface the rings run on
     */
    public CreaseRingLoop(SurfaceMetric metric) {
        span = new HeadedCreasePath(metric);
        spanByVertex = new int[metric.sourceVertexId.length];
    }

    /**
     * Lay the loop into {@link #spanPath}. A plane's ring may run either way round its normal:
     * both are searched, and the way with fewer unsteered spans, then the cheaper, is kept. A
     * drawn line is the first span as drawn, closed from its end back to its start.
     *
     * @param creases       crease cost of the surface
     * @param anchors       the ring's distinct anchors in ring order, mesh vertices
     * @param count         anchors to read from the front of {@code anchors}
     * @param planeNormal   unit normal of the ring's plane, xyz
     * @param drawnVertexId a drawn line's vertices from the first anchor to the last, or empty
     * @param drawnHeadings the way the line heads at its start then at its end, two xyz
     * @param besideLine    vertices beside a drawn line that its closure keeps off
     * @return true when every span has a path
     */
    public boolean lay(SurfaceCreases creases, int[] anchors, int count, float[] planeNormal,
            int[] drawnVertexId, float[] drawnHeadings, int[] besideLine) {
        SurfaceMetric metric = span.metric;
        MeshTopology mesh = metric.sourceMesh;
        span.creases = creases;
        boolean drawn = drawnVertexId.length > 1;
        spanPath = new int[count][];
        unsteeredSpans = Integer.MAX_VALUE;
        double cheapest = Double.POSITIVE_INFINITY;
        float[] leaving = new float[XYZ];
        float[] arriving = new float[XYZ];
        for (int way = 1; way >= (drawn || count == 1 ? 1 : -1); way -= 2) {
            int[][] path = new int[count][];
            float[] axis = { way * planeNormal[0], way * planeNormal[1], way * planeNormal[2] };
            double[] cost = new double[count];
            boolean[] unsteered = new boolean[count];
            boolean[] searching = new boolean[count];
            Arrays.fill(searching, true);
            // A simple ring passes each vertex once, but each span is searched on its own, so two
            // spans can share vertices: at an anchor off the groove the span in and the span out run
            // along one stem. A span sharing a vertex with another is searched again with every
            // vertex the other spans hold closed to it, and keeps its first path when none is left.
            for (int pass = 0; pass < PASSES; pass++) {
                for (int anchor = 0; anchor < count; anchor++) {
                    if (!searching[anchor]) {
                        continue;
                    }
                    if (drawn && anchor == 0) {
                        path[0] = drawnVertexId;
                        continue;
                    }
                    int from = anchors[anchor];
                    int to = anchors[(anchor + 1) % count];
                    span.closedStamp++;
                    for (int other = 0; other < count; other++) {
                        for (int vertexId : other == anchor || path[other] == null || pass == 0 && !drawn
                                ? new int[0] : path[other]) {
                            span.closedStampByVertex[metric.vertexIndexByVertexId[vertexId]] = span.closedStamp;
                        }
                    }
                    for (int vertexId : drawn ? besideLine : new int[0]) {
                        span.closedStampByVertex[metric.vertexIndexByVertexId[vertexId]] = span.closedStamp;
                    }
                    // A drawn line's closure leaves along the line's end heading and arrives along
                    // its start heading; a plane's span runs round the plane's normal at both ends.
                    boolean headed = true;
                    for (int end = 0; end < 2; end++) {
                        float[] heading = end == 0 ? leaving : arriving;
                        if (drawn) {
                            System.arraycopy(drawnHeadings, end == 0 ? XYZ : 0, heading, 0, XYZ);
                        } else {
                            mesh.vertexNormal(end == 0 ? from : to, normal);
                            round.set(planeNormal[0], planeNormal[1], planeNormal[2]).cross(normal).mul(way);
                            heading[0] = round.x;
                            heading[1] = round.y;
                            heading[2] = round.z;
                        }
                        headed &= heading[0] != 0f || heading[1] != 0f || heading[2] != 0f;
                    }
                    // A drawn line's closure runs round the plane's normal the way the line ends.
                    mesh.vertexNormal(from, normal);
                    round.set(planeNormal[0], planeNormal[1], planeNormal[2]).cross(normal);
                    if (drawn && round.dot(leaving[0], leaving[1], leaving[2]) < 0f) {
                        axis = new float[] { -planeNormal[0], -planeNormal[1], -planeNormal[2] };
                    }
                    // A loop back to its own anchor, and a drawn line's closure, count their turns
                    // against the way round the plane's normal, which no curvature turns. A loop
                    // then carries its arrow and counts its turns, then only comes home along it.
                    // A span between two anchors has both ends to go by and its arrow only weights
                    // it; then it runs unsteered, on the first pass through the vertices a drawn
                    // line holds too.
                    boolean loop = from == to;
                    int[] found = null;
                    for (int attempt = headed ? 0 : STEERED; found == null && attempt < ATTEMPTS - pass
                            && (attempt < STEERED || !loop); attempt++) {
                        if (!loop && (attempt == 2 || attempt == 1 && !drawn)) {
                            continue;
                        }
                        span.closedStamp += attempt == ATTEMPTS - 1 ? 1 : 0;
                        span.countsTurns = loop ? attempt < 2 : drawn && attempt == 0;
                        span.axis = attempt == 0 && (loop || drawn) ? axis : null;
                        // A line's closure first runs on round without ever turning back: home
                        // along the groove the line lies in is cheaper, and encloses nothing.
                        span.neverBack = drawn && attempt == 0;
                        found = span.trace(from, to, attempt < STEERED ? leaving : null, arriving);
                        if (found == null && span.neverBack) {
                            span.neverBack = false;
                            found = span.trace(from, to, leaving, arriving);
                        }
                        if (found != null) {
                            unsteered[anchor] = attempt > 0;
                            cost[anchor] = span.cost;
                        }
                    }
                    path[anchor] = found != null ? found : path[anchor];
                }
                span.closedStamp++;
                boolean shared = false;
                for (int anchor = 0; anchor < count && pass == 0; anchor++) {
                    searching[anchor] = false;
                    for (int step = 0; path[anchor] != null && step + 1 < path[anchor].length; step++) {
                        int vertex = metric.vertexIndexByVertexId[path[anchor][step]];
                        searching[anchor] |= span.closedStampByVertex[vertex] == span.closedStamp
                                && spanByVertex[vertex] != anchor;
                        span.closedStampByVertex[vertex] = span.closedStamp;
                        spanByVertex[vertex] = anchor;
                    }
                    searching[anchor] &= !(drawn && anchor == 0);
                    shared |= searching[anchor];
                }
                if (!shared) {
                    break;
                }
            }
            int unsteeredThisWay = 0;
            double total = 0.0;
            for (int anchor = 0; anchor < count; anchor++) {
                unsteeredThisWay += unsteered[anchor] ? 1 : 0;
                total += path[anchor] == null ? Double.POSITIVE_INFINITY : cost[anchor];
            }
            if (cheapest == Double.POSITIVE_INFINITY || total < Double.POSITIVE_INFINITY
                    && (unsteeredThisWay < unsteeredSpans
                            || unsteeredThisWay == unsteeredSpans && total < cheapest)) {
                unsteeredSpans = unsteeredThisWay;
                cheapest = total;
                spanPath = path;
            }
        }
        boolean laid = true;
        for (int[] path : spanPath) {
            laid &= path != null;
        }
        return laid;
    }
}
