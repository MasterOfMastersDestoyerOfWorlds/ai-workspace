package ixdar.tools.connection;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.annotations.tool.ToolAnnotation;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.GrownPatch;
import ixdar.geometry.mesh.data.rings.RingSegmentMode;
import ixdar.graphics.render.model.HalfEdgeMeshRuntime;
import ixdar.platform.Platforms;
import ixdar.platform.input.Keys;
import ixdar.scenes.ring.RingScene;
import ixdar.tools.ControlHint;
import ixdar.tools.Tool;
import ixdar.tools.ring.RingTool;

/**
 * The editing scene's grow tool: a click grows a patch over the flat surface round it, up to the
 * rings and the bottoms of the grooves that bound it, and Enter makes its open outline rings.
 */
@ToolAnnotation(id = GrowTool.TOOL_NAME)
public final class GrowTool extends Tool {

    public static final String LOG_PREFIX = "[grow] ";

    public static final String TOOL_NAME = "grow";

    public static final String PATCH_TAG = "grown_patch";

    public static final float THRESHOLD_STEP = 0.05f;

    // An outline stretch shorter than this is a nick beside a wall, not a boundary.
    public static final int SHORTEST_STRETCH = 6;

    // An open outline stretch is steered by one anchor for each this many of its edges: enough
    // to keep the cut in the groove, few enough to smooth the outline's teeth.
    public static final int OUTLINE_EDGES_PER_ANCHOR = 16;

    /** Scene the tool runs on, whose ring tool holds the rings that act as walls. */
    public final RingScene scene;

    /** Whether the tool is the scene's active one. */
    public boolean active;

    /** The patch grown from the last click, or {@code null} before one. */
    public GrownPatch patch;

    /** Face the patch grows from, or -1 before a click. */
    public int seedFaceId = -1;

    /** Valley strength from which a face is groove, where the patch stops. */
    public float threshold = SurfaceCreases.CREASE_STRENGTH;

    private boolean pendingClick;

    /**
     * Binds the tool to its scene.
     *
     * @param scene the editing scene whose surface and rings the tool reads
     */
    public GrowTool(RingScene scene) {
        this.scene = scene;
    }

    @Override
    public String toolName() {
        return TOOL_NAME;
    }

    @Override
    public String desc() {
        return "Click a part to grow a patch over it up to the rings and groove bottoms round it; "
                + "Enter makes the patch's outline rings and bisectors in the ring tool";
    }

    /** Show the patch the tool holds; clicks arrive through the pointer callbacks. */
    @Override
    public void activate() {
        active = true;
        if (seedFaceId >= 0) {
            grow();
        }
    }

    /** Take the patch's colour off the surface, keeping the place it grew from. */
    @Override
    public void deactivate() {
        active = false;
        pendingClick = false;
        HalfEdgeMeshRuntime runtime = scene.surfaceRuntime();
        if (runtime != null && patch != null) {
            runtime.clearTags();
            runtime.clearTagColors();
            scene.looks.clearOverride(RingScene.REGIONS_LOOK);
        }
    }

    @Override
    public void addControls(List<ControlHint> controls) {
        controls.add(new ControlHint(ControlHint.NO_KEY, "click", "grow a patch from that place"));
        // Enter: each closed stretch of the patch's outline becomes a ring and each open stretch a
        // bisector between the walls it ends on, in the ring tool; the error names the stretches
        // that made none.
        controls.add(new ControlHint("confirm-grow", Keys.ENTER, "enter",
                "make the patch's outline rings and bisectors", () -> {
                    lastError = "";
                    RingTool rings = scene.ringTool;
                    if (patch == null || seedFaceId < 0 || rings.draft != null) {
                        lastError = rings.draft == null ? "click a part to grow a patch first"
                                : "the ring tool has a draft open - Ctrl+R, then confirm (Enter) or discard (X) it";
                        scene.errorToasts.show(TOOL_NAME, lastError);
                        return;
                    }
                    List<int[]> loops = List.copyOf(patch.loops);
                    List<int[]> chains = List.copyOf(patch.chains);
                    scene.switchTool(rings);
                    int made = 0;
                    StringBuilder refused = new StringBuilder();
                    for (int stretch = 0; stretch < loops.size() + chains.size(); stretch++) {
                        boolean closed = stretch < loops.size();
                        int[] vertices = closed ? loops.get(stretch) : chains.get(stretch - loops.size());
                        if (vertices.length < SHORTEST_STRETCH) {
                            continue;
                        }
                        boolean done = closed ? rings.confirmLoop(vertices, TOOL_NAME) >= 0
                                : rings.bisector.draftAlong(vertices, RingSegmentMode.GEODESIC,
                                        vertices.length / OUTLINE_EDGES_PER_ANCHOR)
                                        && rings.confirmDraft();
                        if (!done && rings.draft != null) {
                            rings.discardDraft();
                        }
                        made += done ? 1 : 0;
                        refused.append(done ? "" : (closed ? " closed " : " open ") + vertices.length
                                + " edges: " + rings.lastError + ";");
                    }
                    seedFaceId = -1;
                    lastRow = made + " ring(s) and bisector(s) made from the grown patch's outline";
                    rings.lastRow = lastRow;
                    lastError = refused.length() == 0 ? "" : "outline stretches that made no ring:" + refused;
                    scene.errorToasts.show(TOOL_NAME, lastError);
                    Platforms.get().log(LOG_PREFIX + lastRow + (lastError.isEmpty() ? "" : "; " + lastError));
                }));
        controls.add(new ControlHint("grow-less", Keys.LEFT_BRACKET, "[",
                "stop at shallower grooves: a smaller patch", () -> {
                    threshold = Math.max(THRESHOLD_STEP, threshold - THRESHOLD_STEP);
                    grow();
                }));
        controls.add(new ControlHint("grow-more", Keys.RIGHT_BRACKET, "]",
                "pass over shallower grooves: a larger patch", () -> {
                    threshold = Math.min(1f, threshold + THRESHOLD_STEP);
                    grow();
                }));
    }

    /** One frame while active: pick under the cursor, then grow from a queued click. */
    @Override
    public void perFrame() {
        HalfEdgeMeshRuntime runtime = scene.surfaceRuntime();
        MeshTopology surface = scene.halfEdgeSurface();
        if (!active || runtime == null || surface == null || surface.faceCount() == 0) {
            if (pendingClick) {
                lastError = RingScene.NO_SURFACE_REFUSAL;
                scene.errorToasts.show(TOOL_NAME, lastError);
            }
            pendingClick = false;
            return;
        }
        if (!runtime.facePickReady()) {
            runtime.uploadFacePickBuffer(surface, scene.regionLayer.hiddenByActiveFace);
        }
        boolean hit = scene.pickCursor(runtime, surface);
        if (pendingClick) {
            pendingClick = false;
            lastError = "";
            if (hit) {
                seedFaceId = scene.cursorFaceId;
                grow();
            } else {
                lastError = scene.cursorMissReason;
            }
            scene.errorToasts.show(TOOL_NAME, lastError);
        }
    }

    /**
     * Grow the patch from the clicked face with every ring and bisector a wall, and colour it on
     * the surface.
     *
     * @return true when a patch was grown
     */
    public boolean grow() {
        lastError = "";
        MeshTopology surface = scene.halfEdgeSurface();
        HalfEdgeMeshRuntime runtime = scene.surfaceRuntime();
        RingTool rings = scene.ringTool;
        if (surface == null || runtime == null || seedFaceId < 0 || !surface.hasFace(seedFaceId)
                || !rings.readyCreases(surface)) {
            lastError = seedFaceId < 0 ? "click a part to grow from first" : rings.lastError;
            return false;
        }
        long start = System.nanoTime();
        if (patch == null || patch.mesh != surface) {
            patch = new GrownPatch(surface, rings.creases.valleyStrength, rings.creases.valleyCurvature);
        }
        boolean[] walls = new boolean[surface.edgeIdBound()];
        for (boolean[] marks : rings.liveRingMarks().values()) {
            for (int edgeId = 0; marks != null && edgeId < Math.min(marks.length, walls.length); edgeId++) {
                walls[edgeId] |= marks[edgeId];
            }
        }
        patch.grow(seedFaceId, threshold, walls);
        patch.outline();
        Map<Integer, Integer> activeVertexById = new HashMap<>();
        for (int activeVertex = 0; activeVertex < surface.vertexCount(); activeVertex++) {
            activeVertexById.put(surface.vertexIdAt(activeVertex), activeVertex);
        }
        boolean[] mask = new boolean[surface.vertexCount()];
        for (int face = 0; face < surface.faceCount(); face++) {
            int faceId = surface.faceIdAt(face);
            for (int corner = 0; patch.inPatchByFaceId[faceId] && corner < surface.faceVertexCount(faceId);
                    corner++) {
                mask[activeVertexById.get(surface.faceVertexAt(faceId, corner))] = true;
            }
        }
        runtime.clearTagColors();
        runtime.setTagColor(PATCH_TAG, scene.palette.selected.toVector4f());
        scene.looks.override(RingScene.REGIONS_LOOK);
        runtime.setTags(Map.of(PATCH_TAG, mask));
        int[] lengths = new int[patch.loops.size() + patch.chains.size()];
        for (int stretch = 0; stretch < lengths.length; stretch++) {
            lengths[stretch] = stretch < patch.loops.size() ? patch.loops.get(stretch).length
                    : patch.chains.get(stretch - patch.loops.size()).length;
        }
        lastRow = String.format(Locale.ROOT, "patch of %d faces (%.1f%% of the surface) at groove strength "
                + "%.2f; outline off the rings: %d closed, %d open, edges %s; %.0f ms. [ smaller, ] larger, "
                + "Enter makes the outline rings", patch.faceCount, 100.0 * patch.faceCount / surface.faceCount(),
                threshold, patch.loops.size(), patch.chains.size(), Arrays.toString(lengths),
                (System.nanoTime() - start) / 1e6);
        Platforms.get().log(LOG_PREFIX + lastRow);
        return true;
    }

    /**
     * Queue a click for the next frame, which picks the surface under the cursor first.
     *
     * @param x     framebuffer x of the release, unused
     * @param y     framebuffer y of the release, unused
     * @param click true when the press did not move
     * @return {@code click}: every click is the tool's
     */
    @Override
    public boolean onRelease(float x, float y, boolean click) {
        pendingClick = click && active;
        return click;
    }
}
