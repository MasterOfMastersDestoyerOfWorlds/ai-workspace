package ixdar.geometry.mesh.data.rings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeMap;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.geodesic.TracedSurfacePath;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.numeric.sparse.DirectSolver;
import ixdar.numeric.sparse.matrix.NormalMatrix;
import ixdar.numeric.sparse.ordering.OrderingMethod;

/**
 * Moves the anchors of a surface's rings so the regions between them are well cut: each ring
 * goes to the grooves nearest it, a ring with none to the middle of its region.
 */
public final class RingAnchorFit {

    public static final int COORDINATES_PER_POINT = 3;

    // How many times more a vertex in a groove's bottom pays than one on smooth surface.
    public static final double GROOVE_WEIGHT = 1000.0;

    // A vertex pays its distance to the nearest ring, in mean edges, raised to this: under one,
    // so a ring between two grooves goes to the nearer.
    public static final double POWER = 0.5;

    // What each mean edge of ring length pays: little, so that of two rings covering alike the
    // straighter wins, yet a ring is not held where it is by how its length happens to trace.
    public static final double LENGTH_WEIGHT = 100.0;

    // A groove counts at its bottom only, so a ring gains nothing by weaving across a wide one: a
    // vertex is a bottom when its valley curvature is this many times that of both of two
    // neighbours whose directions from it are opposite to within this cosine.
    public static final double BOTTOM_MARGIN = 1.02;

    public static final double ACROSS = 0.7;

    // A ring pays this for each mean edge of its length, times how many mean edges that stretch
    // of it is from the nearest groove bottom, no further than the reach: it draws a ring that is
    // near a groove the rest of the way in.
    public static final double FIELD_WEIGHT = 0.0;

    public static final double FIELD_REACH_EDGES = 6.0;

    // How strongly neighbouring anchors of a ring move together, against what moves them: a ring
    // moves as one at first, and each time its whole move is turned down its anchors are let
    // move this much more freely, down to the least, before its stride is shortened.
    public static final double STIFFNESS = 300.0;

    public static final double SOFTENING = 0.1;

    public static final double LEAST_STIFFNESS = 0.3;

    // An anchor moves no further than this many mean edges in one round.
    public static final double MOST_STEP_EDGES = 8.0;

    // A vertex this share of a mean edge from a ring's point counts as standing on it.
    public static final double ON_POINT = 0.25;

    // A vertex draws its ring's point toward where its way to the ring is this many mean edges
    // from it, or toward itself when nearer: one edge alone points wherever the mesh's edges do.
    public static final double AIM_EDGES = 3.0;

    // Damping of a ring's anchors, as a share of the ring's mean diagonal.
    public static final double DAMPING = 1e-3;

    // A ring's solved move is taken this many times over: doubled when its move is kept, halved
    // when not, grown by the growth when it reaches no other vertex, between these bounds.
    public static final double FIRST_STRIDE = 1.0;

    public static final double STRIDE_GROWTH = 1.5;

    public static final double MOST_STRIDE = 64.0;

    public static final double LEAST_STRIDE = 1.0 / 64.0;

    public static final int ROUNDS = 200;

    /** Rounds the last {@link #relax} ran. */
    public int rounds;

    /** Anchors the last {@link #relax} moved to another vertex, counted once per kept move. */
    public int movedAnchors;

    /** Surface the rings lie on. */
    public final MeshTopology mesh;

    /** Groove strength per vertex id, 0 on smooth surface up to 1 in a groove's bottom. */
    public final float[] strength;

    /** What each vertex's distance to its ring counts for, by vertex id: its area, a groove's more. */
    public final double[] weight;

    /** Each vertex's way along edges to the nearest groove bottom, by vertex id. */
    public final double[] toBottom;

    /** The vertex each vertex's way to the nearest groove bottom steps to first, by vertex id. */
    public final int[] bottomward;

    /** Mean edge length of the surface, the unit the energy is counted in. */
    public final double meanEdgeLength;

    /** Traced path of each ring added, in the order added. */
    public final List<TracedSurfacePath> paths = new ArrayList<>();

    /** Anchor vertices of each ring added, in ring order. */
    public final List<int[]> anchors = new ArrayList<>();

    /** How many times over each ring's solved move is taken. */
    public final List<Double> strides = new ArrayList<>();

    /** Anchor vertices the last {@link #solve} moved each ring's anchors to, in ring order. */
    public final List<int[]> proposed = new ArrayList<>();

    // How strongly each ring's anchors move together now.
    private final List<Double> stiffness = new ArrayList<>();
    private final double[] lengthByEdge;
    // Per vertex id as last measured: the way along edges to the nearest ring, that ring and its
    // path point, and the vertex the way there leaves that point toward.
    private final double[] far;
    private final int[] ringOf;
    private final int[] pointOf;
    private final int[] aim;
    // The system the last solve put together.
    private double[] diagonal = new double[0];
    private double[] rightHandSide = new double[0];
    private final TreeMap<Long, Double> upper = new TreeMap<>();
    private final Vector3f position = new Vector3f();
    private final Vector3f other = new Vector3f();
    private final Vector3f base = new Vector3f();
    private final Vector3f pathPoint = new Vector3f();

    /**
     * A fit over one surface's grooves.
     *
     * @param mesh      surface the rings lie on
     * @param strength  groove strength per vertex id
     * @param curvature valley curvature per vertex id, what the strength was ranked from
     */
    public RingAnchorFit(MeshTopology mesh, float[] strength, float[] curvature) {
        this.mesh = mesh;
        this.strength = strength;
        lengthByEdge = new double[mesh.edgeIdBound()];
        far = new double[mesh.vertexIdBound()];
        ringOf = new int[mesh.vertexIdBound()];
        pointOf = new int[mesh.vertexIdBound()];
        aim = new int[mesh.vertexIdBound()];
        weight = new double[mesh.vertexIdBound()];
        toBottom = new double[mesh.vertexIdBound()];
        bottomward = new int[mesh.vertexIdBound()];
        double total = 0;
        for (int active = 0; active < mesh.edgeCount(); active++) {
            int halfEdge = mesh.edgeHalfEdge(mesh.edgeIdAt(active));
            lengthByEdge[mesh.edgeIdAt(active)] = mesh.vertexPosition(mesh.halfEdgeVertex(halfEdge), position)
                    .distance(mesh.vertexPosition(mesh.halfEdgeEndVertex(halfEdge), other));
            total += lengthByEdge[mesh.edgeIdAt(active)];
        }
        meanEdgeLength = total / Math.max(1, mesh.edgeCount());
        float[] areas = mesh.vertexAreas();
        double area = 0;
        for (float one : areas) {
            area += one;
        }
        PriorityQueue<double[]> queue = new PriorityQueue<>((first, second) -> Double.compare(first[0], second[0]));
        for (int active = 0; active < mesh.vertexCount(); active++) {
            int vertexId = mesh.vertexIdAt(active);
            // A groove's bottom: the valley curvature there is more than at both of two
            // neighbours that lie about opposite each other, which are the two across the groove.
            boolean bottom = false;
            mesh.vertexPosition(vertexId, base);
            for (int one = 0; strength[vertexId] >= SurfaceCreases.CREASE_STRENGTH && !bottom && one < mesh
                    .vertexEdgeCount(vertexId); one++) {
                int first = mesh.edgeOtherVertex(mesh.vertexEdgeAt(vertexId, one), vertexId);
                mesh.vertexPosition(first, position).sub(base).normalize();
                for (int two = one + 1; !bottom && two < mesh.vertexEdgeCount(vertexId); two++) {
                    int second = mesh.edgeOtherVertex(mesh.vertexEdgeAt(vertexId, two), vertexId);
                    bottom = mesh.vertexPosition(second, other).sub(base).normalize().dot(position) < -ACROSS
                            && curvature[vertexId] > BOTTOM_MARGIN * Math.max(curvature[first], curvature[second]);
                }
            }
            double groove = strength[vertexId] >= SurfaceCreases.CREASE_STRENGTH ? 1 : 0;
            weight[vertexId] = areas[active] * mesh.vertexCount() / Math.max(area, Double.MIN_NORMAL)
                    * (1 + GROOVE_WEIGHT * groove);
            toBottom[vertexId] = bottom ? 0 : Double.POSITIVE_INFINITY;
            bottomward[vertexId] = vertexId;
            if (bottom) {
                queue.add(new double[] { 0, vertexId });
            }
        }
        // Every vertex's way along edges to the nearest groove bottom, and its first step there.
        while (!queue.isEmpty()) {
            double[] head = queue.poll();
            int at = (int) head[1];
            for (int index = 0; head[0] <= toBottom[at] && index < mesh.vertexEdgeCount(at); index++) {
                int edgeId = mesh.vertexEdgeAt(at, index);
                int next = mesh.edgeOtherVertex(edgeId, at);
                if (head[0] + lengthByEdge[edgeId] < toBottom[next]) {
                    toBottom[next] = head[0] + lengthByEdge[edgeId];
                    bottomward[next] = at;
                    queue.add(new double[] { toBottom[next], next });
                }
            }
        }
    }

    /**
     * Adds a ring or bisector as traced through its anchors.
     *
     * @param path           the traced path
     * @param anchorVertexId its authored anchors, in ring order
     * @param stride         how many times over its solved move is taken at first
     */
    public void add(TracedSurfacePath path, int[] anchorVertexId, double stride) {
        paths.add(path);
        anchors.add(anchorVertexId);
        strides.add(stride);
        stiffness.add(STIFFNESS);
    }

    /**
     * The energy of the regions the rings cut: the weighted mean over every vertex of its
     * distance to the nearest ring, in mean edges and raised to {@link #POWER}, plus the rings'
     * length.
     *
     * @return the energy, never negative
     */
    public double energy() {
        measure();
        double paid = 0;
        double weighed = 0;
        for (int active = 0; active < mesh.vertexCount(); active++) {
            int vertexId = mesh.vertexIdAt(active);
            if (Double.isFinite(far[vertexId])) {
                paid += weight[vertexId] * Math.pow(far[vertexId] / meanEdgeLength, POWER);
                weighed += weight[vertexId];
            }
        }
        for (int ring = 0; ring < paths.size(); ring++) {
            TracedSurfacePath path = paths.get(ring);
            paid += LENGTH_WEIGHT * path.length / meanEdgeLength;
            for (int point = 0; point < path.pointCount; point++) {
                paid += FIELD_WEIGHT * share(path, point) / meanEdgeLength * Math.min(FIELD_REACH_EDGES, toBottom[under(path,
                        point)] / meanEdgeLength);
            }
        }
        return weighed > 0 ? paid / weighed : 0;
    }

    /**
     * A field look of the fit: where it takes the groove bottoms to be, or what each vertex
     * pays as the rings now stand, as the logarithm of one more than it so grooves and plain
     * surface both show.
     *
     * @param paid true for what each vertex pays, false for the groove bottoms
     * @return one value per active vertex, in active order
     */
    public float[] field(boolean paid) {
        if (paid) {
            measure();
        }
        float[] field = new float[mesh.vertexCount()];
        for (int active = 0; active < field.length; active++) {
            int vertexId = mesh.vertexIdAt(active);
            field[active] = !paid ? toBottom[vertexId] == 0 ? 1 : 0
                    : Double.isFinite(far[vertexId]) ? (float) Math.log10(1 + weight[vertexId] * Math.pow(far[vertexId]
                            / meanEdgeLength, POWER)) : 0;
        }
        return field;
    }

    /**
     * The mean groove strength under one traced ring, by length.
     *
     * @param path traced path
     * @return the depth, 0 to 1
     */
    public double depth(TracedSurfacePath path) {
        double depth = 0;
        double length = 0;
        for (int point = 0; point < path.pointCount; point++) {
            depth += share(path, point) * strength[under(path, point)];
            length += share(path, point);
        }
        return length > 0 ? depth / length : 0;
    }

    /**
     * Solve for every anchor's move at once and walk each moved anchor to the vertex nearest
     * it, into {@link #proposed}: a least-squares step of every ring toward its grooves, or the
     * middle of its region, a path point moving with the two anchors it lies between.
     */
    public void solve() {
        proposed.clear();
        measure();
        int[] firstUnknown = new int[paths.size() + 1];
        RingBlend[] blends = new RingBlend[paths.size()];
        for (int ring = 0; ring < paths.size(); ring++) {
            blends[ring] = new RingBlend(mesh, paths.get(ring), anchors.get(ring));
            firstUnknown[ring + 1] = firstUnknown[ring] + anchors.get(ring).length;
        }
        int unknowns = firstUnknown[paths.size()];
        diagonal = new double[unknowns];
        rightHandSide = new double[unknowns];
        upper.clear();
        List<int[]> termRows = new ArrayList<>();
        List<double[]> terms = new ArrayList<>();
        double[] felt = new double[paths.size()];
        // Every vertex draws the point of its nearest ring that it is nearest toward itself, a
        // groove's bottom far more: that takes a ring into its grooves, and one with none to the
        // middle of what is nearest it.
        for (int active = 0; active < mesh.vertexCount(); active++) {
            int vertexId = mesh.vertexIdAt(active);
            int ring = Double.isFinite(far[vertexId]) ? ringOf[vertexId] : -1;
            if (ring < 0 || blends[ring].between == null) {
                continue;
            }
            int point = pointOf[vertexId];
            mesh.vertexPosition(aim[vertexId], position).sub(at(paths.get(ring), point));
            if (position.length() > ON_POINT * meanEdgeLength) {
                // Only what draws the point across its ring within the surface counts: along
                // the ring the point comes no nearer the vertex.
                double draws = position.normalize().dot(blends[ring].across[point]);
                // The power of the distance is stood in for by the square that touches it from
                // above where the vertex now is, whose least is the ring's point reaching the
                // vertex: it counts for less the further the vertex, and is held within an edge
                // of the ring, where the power's own has no bound.
                double counts = weight[vertexId] * POWER * Math.pow(Math.max(1, far[vertexId] / meanEdgeLength),
                        POWER - 2);
                termRows.add(rows(firstUnknown[ring], blends[ring].between[point], blends[ring].between[point]));
                terms.add(new double[] { draws * (1 - blends[ring].onto[point]), draws * blends[ring].onto[point],
                    counts, counts * far[vertexId] * strides.get(ring) });
                felt[ring] += counts * draws * draws / Math.max(1, anchors.get(ring).length);
            } else {
                // A vertex the ring already runs through holds its point there, a groove's bottom
                // far more: the part of a ring in its groove stays while the rest comes in.
                termRows.add(rows(firstUnknown[ring], blends[ring].between[point], blends[ring].between[point]));
                terms.add(new double[] { 1 - blends[ring].onto[point], blends[ring].onto[point], weight[vertexId]
                    * POWER, 0 });
            }
        }
        // Each stretch of a ring within reach of a groove bottom is drawn along its way there.
        for (int ring = 0; ring < paths.size(); ring++) {
            TracedSurfacePath path = paths.get(ring);
            for (int point = 0; blends[ring].between != null && point < path.pointCount; point++) {
                int toward = under(path, point);
                double gap = toBottom[toward];
                for (int hop = 0; hop < AIM_EDGES; hop++) {
                    toward = bottomward[toward];
                }
                mesh.vertexPosition(toward, position).sub(at(path, point));
                if (gap > 0 && gap <= FIELD_REACH_EDGES * meanEdgeLength && position.length() > ON_POINT
                        * meanEdgeLength) {
                    double draws = position.normalize().dot(blends[ring].across[point]);
                    double counts = FIELD_WEIGHT * share(path, point) / meanEdgeLength / Math.max(1, gap
                            / meanEdgeLength);
                    termRows.add(rows(firstUnknown[ring], blends[ring].between[point], blends[ring].between[point]));
                    terms.add(new double[] { draws * (1 - blends[ring].onto[point]), draws * blends[ring].onto[point],
                        counts, counts * gap * strides.get(ring) });
                    felt[ring] += counts * draws * draws / Math.max(1, anchors.get(ring).length);
                }
            }
        }
        // The anchors of a ring move together, and none runs away where nothing moves it.
        double whole = 0;
        for (int ring = 0; ring < paths.size(); ring++) {
            TracedSurfacePath path = paths.get(ring);
            whole += felt[ring];
            double stiff = stiffness.get(ring) * felt[ring] * path.pointCount / Math.max(1, anchors.get(ring).length);
            for (int point = 0; blends[ring].between != null && point < (path.closed ? path.pointCount
                    : path.pointCount - 1); point++) {
                int next = (point + 1) % path.pointCount;
                termRows.add(rows(firstUnknown[ring], blends[ring].between[next], blends[ring].between[point]));
                terms.add(new double[] { 1 - blends[ring].onto[next], blends[ring].onto[next],
                    blends[ring].onto[point] - 1, -blends[ring].onto[point], stiff, 0 });
            }
            for (int unknown = firstUnknown[ring]; unknown < firstUnknown[ring + 1]; unknown++) {
                diagonal[unknown] += DAMPING * felt[ring] + Double.MIN_NORMAL;
            }
        }
        // Each term is a squared blend of some anchors' moves across their ring: a share for each
        // anchor, then what the term adds to the matrix and to the right-hand side.
        for (int term = 0; term < terms.size(); term++) {
            int[] rows = termRows.get(term);
            double[] shares = terms.get(term);
            for (int first = 0; first < rows.length; first++) {
                rightHandSide[rows[first]] += shares[rows.length + 1] * shares[first];
                for (int second = 0; second < rows.length; second++) {
                    double value = shares[rows.length] * shares[first] * shares[second];
                    if (rows[first] == rows[second]) {
                        diagonal[rows[first]] += value;
                    } else if (rows[first] < rows[second]) {
                        upper.merge((long) rows[first] << NormalMatrix.KEY_ROW_SHIFT | rows[second], value,
                                Double::sum);
                    }
                }
            }
        }
        double[] move = unknowns == 0 || whole == 0 ? new double[unknowns]
                : DirectSolver.solve(new NormalMatrix(diagonal, upper, rightHandSide), new double[unknowns],
                        new boolean[unknowns], OrderingMethod.AMD);
        for (int ring = 0; ring < paths.size(); ring++) {
            int[] moved = anchors.get(ring).clone();
            // The middle one of the anchors' moves, in mean edges: anchors moving about as far as
            // that take as many edges, so the ring keeps its shape.
            double[] sorted = Arrays.copyOfRange(move, firstUnknown[ring], firstUnknown[ring + 1]);
            Arrays.sort(sorted);
            double middle = sorted.length == 0 ? 0 : sorted[sorted.length / 2] / meanEdgeLength;            for (int anchor = 0; anchor < moved.length; anchor++) {
                // The anchor walks across its ring as many edges as its solved move is mean edges.
                long edges = Math.round(middle) + Math.round(move[firstUnknown[ring] + anchor] / meanEdgeLength
                        - middle);
                int landed = blends[ring].walked(mesh, anchor, moved[anchor], Math.max(-Math.round(MOST_STEP_EDGES),
                        Math.min(Math.round(MOST_STEP_EDGES), edges)));
                int reached = landed;                moved[anchor] = Arrays.stream(moved).anyMatch(held -> held == reached) ? moved[anchor] : landed;
            }
            // A bisector's end goes where the anchor next to it went; whoever traces it puts the
            // end back on its ring from there.
            if (!paths.get(ring).closed && moved.length > 2) {
                moved[0] = moved[1];
                moved[moved.length - 1] = moved[moved.length - 2];
            }
            proposed.add(moved);
        }
    }

    /**
     * Move the anchors until no step lowers the energy of the regions: each round solves for
     * every anchor, has each moved ring traced again, and keeps a ring's move only when the
     * energy with every other ring where it stands came down.
     *
     * @param tracer traces a ring through moved anchors and takes or drops the result
     */
    public void relax(Tracer tracer) {
        movedAnchors = 0;
        double lowest = energy();
        boolean moving = true;
        // The stride each ring's move was last turned down at, no move kept anywhere since.
        double[] turnedDown = new double[paths.size()];
        Arrays.fill(turnedDown, 2 * MOST_STRIDE);
        for (rounds = 0; moving && rounds < ROUNDS; rounds++) {
            solve();
            moving = false;
            for (int ring = 0; ring < paths.size(); ring++) {
                int[] onto = proposed.get(ring);
                // A ring added with no stride counts as a ring but stays as it is.
                if (strides.get(ring) <= 0) {
                    continue;
                }
                if (strides.get(ring) < LEAST_STRIDE || Arrays.equals(onto, anchors.get(ring))) {
                    // A move too short to reach another vertex is taken further the next round,
                    // short of one that was turned down.
                    boolean further = strides.get(ring) * STRIDE_GROWTH < turnedDown[ring];
                    strides.set(ring, further ? strides.get(ring) * STRIDE_GROWTH : strides.get(ring));
                    boolean freer = !further && stiffness.get(ring) > LEAST_STIFFNESS;
                    stiffness.set(ring, freer ? stiffness.get(ring) * SOFTENING : stiffness.get(ring));
                    moving |= further || freer;
                    continue;
                }
                // The ring's solved move is taken whole or not at all; when it is not kept it is
                // solved again with its anchors freer, then shorter.
                TracedSurfacePath stood = paths.get(ring);
                TracedSurfacePath traced = tracer.trace(ring, onto);
                double reached = Double.POSITIVE_INFINITY;
                if (traced != null) {
                    paths.set(ring, traced);
                    reached = energy();
                }
                boolean kept = reached < lowest;                if (kept) {
                    for (int anchor = 0; anchor < onto.length; anchor++) {
                        movedAnchors += onto[anchor] == anchors.get(ring)[anchor] ? 0 : 1;
                    }
                    anchors.set(ring, onto);
                    lowest = reached;
                } else {
                    paths.set(ring, stood);
                }
                tracer.settle(ring, kept);
                boolean softer = !kept && strides.get(ring) <= FIRST_STRIDE && stiffness.get(ring) > LEAST_STIFFNESS;
                stiffness.set(ring, softer ? stiffness.get(ring) * SOFTENING : stiffness.get(ring));
                turnedDown[ring] = kept || softer ? turnedDown[ring] : strides.get(ring);
                strides.set(ring, kept ? Math.min(MOST_STRIDE, strides.get(ring) * 2)
                        : softer ? strides.get(ring) : strides.get(ring) / 2);
                moving |= kept || strides.get(ring) >= LEAST_STRIDE;
                // A kept move changes what every other ring has to gain, so each gets to try again.
                for (int stuck = 0; kept && stuck < paths.size(); stuck++) {
                    strides.set(stuck, strides.get(stuck) <= 0 ? 0 : Math.max(FIRST_STRIDE, strides.get(stuck)));
                    turnedDown[stuck] = 2 * MOST_STRIDE;
                }
            }
        }
    }

    /** What {@link #relax} asks of whoever holds the rings. */
    public interface Tracer {

        /**
         * Trace a ring through moved anchors without keeping it yet. A bisector's two ends are
         * put back on the rings they end on, in the array given.
         *
         * @param ring           the ring, by the order it was added
         * @param anchorVertexId the anchors to trace through, in ring order
         * @return the traced path, or {@code null} when no ring runs through them
         */
        TracedSurfacePath trace(int ring, int[] anchorVertexId);

        /**
         * Keep or drop the ring last traced.
         *
         * @param ring the ring, by the order it was added
         * @param kept whether the traced ring replaces the one before it
         */
        void settle(int ring, boolean kept);
    }

    /**
     * Measures every vertex's way along edges to the nearest ring as the rings now stand.
     */
    private void measure() {
        Arrays.fill(far, Double.POSITIVE_INFINITY);
        PriorityQueue<double[]> queue = new PriorityQueue<>((first, second) -> Double.compare(first[0], second[0]));
        for (int ring = 0; ring < paths.size(); ring++) {
            TracedSurfacePath path = paths.get(ring);
            for (int point = 0; point < path.pointCount; point++) {
                int vertexId = under(path, point);
                double gap = mesh.vertexPosition(vertexId, position).distance(at(path, point));
                // A vertex under two rings, as where a bisector ends, stays with the first added.
                if (Double.isInfinite(far[vertexId]) || ringOf[vertexId] == ring && gap < far[vertexId]) {
                    far[vertexId] = gap;
                    ringOf[vertexId] = ring;
                    pointOf[vertexId] = point;
                    aim[vertexId] = vertexId;
                    queue.add(new double[] { gap, vertexId });
                }
            }
        }
        while (!queue.isEmpty()) {
            double[] head = queue.poll();
            int at = (int) head[1];
            for (int index = 0; head[0] <= far[at] && index < mesh.vertexEdgeCount(at); index++) {
                int edgeId = mesh.vertexEdgeAt(at, index);
                int next = mesh.edgeOtherVertex(edgeId, at);
                if (head[0] + lengthByEdge[edgeId] < far[next]) {
                    far[next] = head[0] + lengthByEdge[edgeId];
                    ringOf[next] = ringOf[at];
                    pointOf[next] = pointOf[at];
                    aim[next] = far[at] <= AIM_EDGES * meanEdgeLength ? next : aim[at];
                    queue.add(new double[] { far[next], next });
                }
            }
        }
    }

    /**
     * The vertex a path point stands on, or the nearer end of the edge it crosses, or a corner
     * of its face.
     *
     * @param path  traced path
     * @param point point of it
     * @return the vertex id
     */
    private int under(TracedSurfacePath path, int point) {
        int halfEdge = path.edgeId[point] >= 0 ? mesh.edgeHalfEdge(path.edgeId[point]) : -1;
        return path.vertexId[point] >= 0 ? path.vertexId[point]
                : halfEdge < 0 ? mesh.faceVertexAt(path.faceId[point], 0)
                : path.fraction[point] < 1.0 / 2 ? mesh.halfEdgeVertex(halfEdge) : mesh.halfEdgeEndVertex(halfEdge);
    }

    /**
     * The first unknowns of the anchors two path points lie between, the first point's two and
     * then the second's when it is another.
     *
     * @param first  first unknown of the ring
     * @param one    the two anchors the first point lies between
     * @param other  the two anchors the second point lies between, or the first's again
     * @return the first unknown of each anchor
     */
    private static int[] rows(int first, int[] one, int[] other) {
        int[] rows = new int[one == other ? 2 : 4];
        for (int index = 0; index < rows.length; index++) {
            rows[index] = first + (index < 2 ? one[index] : other[index - 2]);
        }
        return rows;
    }

    /**
     * Where a path point is.
     *
     * @param path  traced path
     * @param point point of it
     * @return its position, in a vector the next call overwrites
     */
    private Vector3f at(TracedSurfacePath path, int point) {
        return pathPoint.set((float) path.positions[COORDINATES_PER_POINT * point],
                (float) path.positions[COORDINATES_PER_POINT * point + 1],
                (float) path.positions[COORDINATES_PER_POINT * point + 2]);
    }

    /**
     * The length of a path a point stands for: half the step to it and half the step from it.
     *
     * @param path  traced path
     * @param point point of it
     * @return the length
     */
    private double share(TracedSurfacePath path, int point) {
        return (step(path, point > 0 ? point - 1 : path.closed ? path.pointCount - 1 : point) + step(path, point)) / 2;
    }

    /**
     * The length of the path from one point to the next, the last point of a closed path
     * stepping back to its first.
     *
     * @param path  traced path
     * @param point point the step leaves
     * @return the step's length, nothing past the end of an open path
     */
    private double step(TracedSurfacePath path, int point) {
        int next = point + 1 < path.pointCount ? point + 1 : path.closed ? 0 : point;
        double squared = 0;
        for (int axis = 0; axis < COORDINATES_PER_POINT; axis++) {
            double gap = path.positions[COORDINATES_PER_POINT * next + axis]
                    - path.positions[COORDINATES_PER_POINT * point + axis];
            squared += gap * gap;
        }
        return Math.sqrt(squared);
    }
}
