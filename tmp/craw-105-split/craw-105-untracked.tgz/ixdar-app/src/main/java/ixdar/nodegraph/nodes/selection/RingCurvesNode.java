package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.labels.MeshLabels;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The assembly stage of fit_rings: cuts every wall into curves where walls meet and builds the
 * DOF system of the curve points' offsets across their curves.
 */
@MeshNodeAnnotation(id = RingCurvesNode.NODE_ID, category = NodeCategory.SELECTION)
public class RingCurvesNode implements MeshNode {

    public static final String NODE_ID = "ring_curves";

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort CREASES = SplineRingNode.CREASES;
    public static final InputPort LABELS = new InputPort("labels", PortType.STRING, "");
    public static final InputPort BAND = new InputPort("band", PortType.FLOAT,
            (float) RingCurveFit.DEFAULT_BAND_EDGES, 0f, 1000f);
    public static final InputPort PULL = new InputPort("pull", PortType.FLOAT,
            (float) RingCurveFit.DEFAULT_PULL, 0f, 1000f);
    public static final InputPort SMOOTHNESS = new InputPort("smoothness", PortType.FLOAT,
            (float) RingCurveFit.DEFAULT_SMOOTHNESS, 0f, 1000f);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort DOFS = new OutputPort("dofs", PortType.DOF_SYSTEM);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CREASES, LABELS, BAND, PULL, SMOOTHNESS);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, DOFS);
    }

    @Override
    public String description() {
        return "Builds the system that fits a surface's rings and bisectors to its grooves "
                + "together. Every wall is cut into curves at the vertices where it forks, ends "
                + "or meets another wall. Each curve point gets one degree of freedom, how far "
                + "it slides along the surface across its curve, and the groove depth measured "
                + "along that line; the points where curves meet are frozen. The energy is the "
                + "groove depth the points miss plus the curves' stretch and bend (an active "
                + "contour), and the system's solve is the damped Newton relaxation.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying ring edge marks, after the last spline_ring, "
                        + "spline_cut and add_label statement: no curve slides across a label "
                        + "point. Output: the same bundle with the curves to fit "
                        + "in the " + RingCurveFit.SLOT + " slot, which the relaxation fits in "
                        + "place.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "here when not wired.",
                LABELS.name,
                "Comma-separated edge-mark labels to fit. Empty takes every boolean edge-mark "
                        + "label on the bundle, which after the ring nodes is every ring.",
                BAND.name,
                "How far a curve point may slide either side of where it was drawn, in mean edge "
                        + "lengths; it never slides onto another wall.",
                PULL.name,
                "Weight of the groove depth under a curve point; 0 only smooths the curves.",
                SMOOTHNESS.name,
                "Weight of the curves' stretch and bend, which carries a curve across a gap in "
                        + "its groove.",
                DOFS.name,
                "The DOF system of the offsets, what a newton_solver node relaxes.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (bundle == null) {
            bundle = GeometryBundle.empty();
        }
        MeshTopology mesh = bundle.mesh();
        if (mesh == null || mesh.faceCount() == 0) {
            ctx.setOutput(GEOMETRY.name, bundle);
            ctx.setOutput(DOFS.name, null);
            return;
        }
        SurfaceCreases creases = ctx.getInput(CREASES.name, SurfaceCreases.class);
        RingCurveFit fit = new RingCurveFit(
                RingRegions.ofBundle(bundle, ctx.getInput(LABELS.name, String.class)),
                creases == null ? SurfaceCreases.of(mesh) : creases,
                ctx.getInputValue(BAND.name) instanceof Number band ? band.doubleValue()
                        : RingCurveFit.DEFAULT_BAND_EDGES);
        fit.assemble(
                ctx.getInputValue(PULL.name) instanceof Number pull ? pull.doubleValue()
                        : RingCurveFit.DEFAULT_PULL,
                ctx.getInputValue(SMOOTHNESS.name) instanceof Number smoothness ? smoothness.doubleValue()
                        : RingCurveFit.DEFAULT_SMOOTHNESS,
                MeshLabels.inBundle(bundle).pointsByLabel);
        ctx.setOutput(GEOMETRY.name, bundle.withSlot(RingCurveFit.SLOT, fit));
        ctx.setOutput(DOFS.name, fit.system);
    }
}
