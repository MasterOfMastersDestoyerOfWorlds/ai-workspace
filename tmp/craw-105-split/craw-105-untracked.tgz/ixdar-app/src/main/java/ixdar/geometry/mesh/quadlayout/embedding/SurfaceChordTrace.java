package ixdar.geometry.mesh.quadlayout.embedding;

import java.util.ArrayList;
import java.util.List;

import org.joml.Vector3d;
import org.joml.Vector3f;

import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * The straight line over a triangle surface between two points standing on its edges or
 * vertices, as the points where it leaves each face it crosses.
 */
public final class SurfaceChordTrace {

    public static final int CORNERS = 3;

    // A chord crossing more faces than this is given up on.
    public static final int LONGEST_CHORD_FACES = 256;

    // A crossing this share of an edge from one of its ends passes through that vertex.
    public static final double CORNER_SNAP = 0.02;

    // A cut that has run this many times the chord's own length is going the wrong way round.
    public static final double LONGEST_DETOUR = 4;

    // How many chord lengths further from the end a crossing behind the walk counts as.
    public static final double BEHIND = 1000;

    /** Surface the chords cross. */
    public final HalfEdgeMesh mesh;

    /**
     * The two vertices of the edge the last chord left each face by, in travel order, equal where
     * it left through a vertex; the last pair is the chord's end.
     */
    public final List<int[]> crossingEnds = new ArrayList<>();

    /** How far from the first vertex of its pair to the second each crossing stands. */
    public final List<Double> crossingFractions = new ArrayList<>();

    private final Vector3f corner = new Vector3f();
    private final Vector3f normal = new Vector3f();

    /**
     * Stores the surface for the chords to come.
     *
     * @param mesh triangle surface the chords cross
     */
    public SurfaceChordTrace(HalfEdgeMesh mesh) {
        this.mesh = mesh;
    }

    /**
     * Traces the chord between two surface points, each given as the two vertices of the edge it
     * stands on and how far along it; equal vertices are a point on a vertex. The line is the
     * surface's cut by the plane through both points and the surface normal there.
     *
     * @param fromA        first vertex of the start's edge
     * @param fromB        second vertex of the start's edge
     * @param fromFraction how far from the first to the second the start stands
     * @param toA          first vertex of the end's edge
     * @param toB          second vertex of the end's edge
     * @param toFraction   how far from the first to the second the end stands
     * @return whether the chord reached its end; when not, the crossings hold only that end
     */
    public boolean trace(int fromA, int fromB, double fromFraction, int toA, int toB, double toFraction) {
        crossingEnds.clear();
        crossingFractions.clear();
        Vector3d start = new Vector3d(mesh.vertexPosition(fromA, corner))
                .lerp(new Vector3d(mesh.vertexPosition(fromB, corner)), fromFraction);
        Vector3d end = new Vector3d(mesh.vertexPosition(toA, corner))
                .lerp(new Vector3d(mesh.vertexPosition(toB, corner)), toFraction);
        Vector3d chord = new Vector3d(end).sub(start);
        Vector3d plane = new Vector3d(mesh.vertexNormal(fromA, normal)).add(new Vector3d(mesh.vertexNormal(toA, normal)));
        chord.cross(plane, plane);
        Vector3d here = new Vector3d(start);
        Vector3d crossing = new Vector3d();
        int standsA = fromA;
        int standsB = fromB;
        int cameFrom = MeshTopology.NONE;
        double walked = 0;
        List<Integer> faces = new ArrayList<>();
        for (int step = 0; step < LONGEST_CHORD_FACES; step++) {
            // The faces holding the point reached: the two of its edge, or its vertex's fan.
            faces.clear();
            for (int index = 0; index < (standsA == standsB ? mesh.vertexEdgeCount(standsA) : 1); index++) {
                int edgeId = standsA == standsB ? mesh.vertexEdgeAt(standsA, index) : mesh.edgeBetween(standsA, standsB);
                for (int side = 0; side < 2 && edgeId != MeshTopology.NONE; side++) {
                    int faceId = mesh.edgeFace(edgeId, side);
                    if (faceId != MeshTopology.NONE && faceId != cameFrom && !faces.contains(faceId)) {
                        faces.add(faceId);
                    }
                }
            }
            int chosen = MeshTopology.NONE;
            int exitA = toA;
            int exitB = toB;
            double exitFraction = toFraction;
            double nearest = Double.POSITIVE_INFINITY;
            boolean reaches = false;
            for (int index = 0; index < faces.size() && !reaches; index++) {
                int faceId = faces.get(index);
                int[] corners = { mesh.faceVertexAt(faceId, 0), mesh.faceVertexAt(faceId, 1),
                        mesh.faceVertexAt(faceId, 2) };
                reaches = (corners[0] == toA || corners[1] == toA || corners[2] == toA)
                        && (corners[0] == toB || corners[1] == toB || corners[2] == toB);
                chosen = reaches ? faceId : chosen;
                for (int side = 0; side < CORNERS && !reaches; side++) {
                    int first = corners[side];
                    int second = corners[(side + 1) % CORNERS];
                    boolean stoodOn = standsA == standsB ? first == standsA || second == standsA
                            : first == standsA && second == standsB || first == standsB && second == standsA;
                    Vector3d tail = new Vector3d(mesh.vertexPosition(first, corner));
                    Vector3d head = new Vector3d(mesh.vertexPosition(second, corner));
                    double tailSide = plane.dot(new Vector3d(tail).sub(start));
                    double headSide = plane.dot(new Vector3d(head).sub(start));
                    if (stoodOn || tailSide * headSide > 0 || tailSide == headSide) {
                        continue;
                    }
                    double fraction = tailSide / (tailSide - headSide);
                    tail.lerp(head, fraction);
                    // A crossing ahead along the chord wins over one behind, which is taken only
                    // where the surface folds back and the cut has nowhere else to go.
                    double away = tail.distanceSquared(end)
                            + (new Vector3d(tail).sub(here).dot(chord) > 0 ? 0 : BEHIND * chord.lengthSquared());
                    if (away < nearest) {
                        nearest = away;
                        chosen = faceId;
                        exitA = fraction > 1 - CORNER_SNAP ? second : first;
                        exitB = fraction < CORNER_SNAP ? first : second;
                        exitFraction = exitA == exitB ? 0 : fraction;
                        crossing.set(tail);
                    }
                }
            }
            if (chosen == MeshTopology.NONE) {
                break;
            }
            exitA = reaches ? toA : exitA;
            exitB = reaches ? toB : exitB;
            exitFraction = reaches ? toFraction : exitFraction;
            crossingEnds.add(new int[] { exitA, exitB });
            crossingFractions.add(exitFraction);
            if (reaches) {
                return true;
            }
            standsA = exitA;
            standsB = exitB;
            cameFrom = chosen;
            walked += here.distance(crossing);
            here.set(crossing);
            if (walked > LONGEST_DETOUR * chord.length()) {
                // The cut set off the long way round the part; its end is joined some other way.
                break;
            }
        }
        // A chord that lost its way leaves only its end, for the caller to join some other way.
        crossingEnds.clear();
        crossingFractions.clear();
        crossingEnds.add(new int[] { toA, toB });
        crossingFractions.add(toFraction);
        return false;
    }
}
