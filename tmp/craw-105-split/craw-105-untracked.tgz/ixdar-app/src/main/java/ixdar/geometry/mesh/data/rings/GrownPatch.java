package ixdar.geometry.mesh.data.rings;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * A patch of faces grown from one face over the flat surface around it, up to the walls and the
 * bottoms of the grooves that bound it, and the outline that grooves leave open.
 */
public final class GrownPatch {

    // A pocket the patch surrounds is taken into it while it holds less than the patch's faces
    // over this: groove bits and scan noise, not a neighbouring part.
    public static final int POCKET_SHARE = 20;

    // A pocket that is mostly crease, the strip a wall beside a groove's bottom leaves, may be
    // larger: up to the patch's faces over this.
    public static final int LARGEST_POCKET_SHARE = 4;

    /** Surface the patch lies on. */
    public final MeshTopology mesh;

    /** Faces in the patch, by face id. */
    public final boolean[] inPatchByFaceId;

    /** Faces in the patch. */
    public int faceCount;

    /** Closed stretches of the outline off every wall, each its vertex ids in walking order. */
    public final List<int[]> loops = new ArrayList<>();

    /** Open stretches of the outline off every wall, end to end, each end where the outline stops. */
    public final List<int[]> chains = new ArrayList<>();

    private final float[] faceStrength;
    private final float[] faceDepth;
    private boolean[] wallByEdgeId = new boolean[0];

    /**
     * Measures every face's groove strength and depth as the mean over its corners.
     *
     * @param mesh     surface to grow on
     * @param strength valley strength in [0, 1] per vertex id, which the threshold reads
     * @param depth    unsaturated valley signal per vertex id, which the climb to a groove's bottom
     *                 reads
     */
    public GrownPatch(MeshTopology mesh, float[] strength, float[] depth) {
        this.mesh = mesh;
        inPatchByFaceId = new boolean[mesh.faceIdBound()];
        faceStrength = new float[mesh.faceIdBound()];
        faceDepth = new float[mesh.faceIdBound()];
        for (int face = 0; face < mesh.faceCount(); face++) {
            int faceId = mesh.faceIdAt(face);
            int corners = mesh.faceVertexCount(faceId);
            for (int corner = 0; corner < corners; corner++) {
                int vertexId = mesh.faceVertexAt(faceId, corner);
                faceStrength[faceId] += strength[vertexId] / corners;
                faceDepth[faceId] += depth[vertexId] / corners;
            }
        }
    }

    /**
     * Grow the patch from a face: over every face flatter than the threshold that no wall cuts
     * off, then up each bounding groove while it deepens, then over the pockets left inside.
     *
     * @param seedFaceId face to grow from
     * @param threshold  valley strength from which a face is groove, not flat surface
     * @param walls      edges the patch never crosses, by edge id
     */
    public void grow(int seedFaceId, float threshold, boolean[] walls) {
        wallByEdgeId = walls;
        Arrays.fill(inPatchByFaceId, false);
        faceCount = 0;
        ArrayDeque<Integer> open = new ArrayDeque<>();
        List<Integer> taken = new ArrayList<>();
        inPatchByFaceId[seedFaceId] = true;
        open.add(seedFaceId);
        // Flat faces first, breadth first; the groove faces are climbed from all of them after,
        // so a groove is entered from the flat surface on this side of it only.
        for (int climbing = 0; climbing < 2; climbing++) {
            while (!open.isEmpty()) {
                int faceId = open.poll();
                taken.add(faceId);
                for (int side = 0; side < mesh.faceEdgeCount(faceId); side++) {
                    int next = across(faceId, mesh.faceEdgeAt(faceId, side));
                    if (next == MeshTopology.NONE || inPatchByFaceId[next]) {
                        continue;
                    }
                    boolean flat = faceStrength[next] < threshold;
                    if (climbing == 0 ? flat : !flat && faceDepth[next] > faceDepth[faceId]) {
                        inPatchByFaceId[next] = true;
                        open.add(next);
                    }
                }
            }
            if (climbing == 0) {
                open.addAll(taken);
                taken.clear();
            }
        }
        faceCount = taken.size();
        // Pockets: each flood of outside faces from the patch's edge that ends before it grows
        // large is closed in by the patch and the walls, and may join the patch.
        int[] floodOfFaceId = new int[inPatchByFaceId.length];
        boolean[] outside = new boolean[inPatchByFaceId.length];
        int flood = 0;
        for (int from : taken) {
            for (int edge = 0; edge < mesh.faceEdgeCount(from); edge++) {
                int startId = across(from, mesh.faceEdgeAt(from, edge));
                if (startId == MeshTopology.NONE || inPatchByFaceId[startId] || outside[startId]) {
                    continue;
                }
                List<Integer> pocket = new ArrayList<>();
                flood++;
                floodOfFaceId[startId] = flood;
                open.add(startId);
                boolean closedIn = true;
                int groove = 0;
                while (closedIn && !open.isEmpty()) {
                    int faceId = open.poll();
                    pocket.add(faceId);
                    groove += faceStrength[faceId] < SurfaceCreases.CREASE_STRENGTH ? 0 : 1;
                    closedIn = pocket.size() * LARGEST_POCKET_SHARE < faceCount;
                    for (int side = 0; closedIn && side < mesh.faceEdgeCount(faceId); side++) {
                        int next = across(faceId, mesh.faceEdgeAt(faceId, side));
                        if (next != MeshTopology.NONE && !inPatchByFaceId[next]
                                && floodOfFaceId[next] != flood) {
                            closedIn = !outside[next];
                            floodOfFaceId[next] = flood;
                            open.add(next);
                        }
                    }
                }
                open.clear();
                // A small pocket is noise; a larger one joins only when it is mostly groove, the
                // strip a wall beside the groove's bottom leaves, not a neighbouring part.
                closedIn &= pocket.size() * POCKET_SHARE < faceCount || groove * 2 > pocket.size();
                for (int faceId : pocket) {
                    inPatchByFaceId[faceId] = closedIn;
                    outside[faceId] = !closedIn;
                }
                faceCount += closedIn ? pocket.size() : 0;
            }
        }
    }

    private int across(int faceId, int edgeId) {
        if (edgeId < wallByEdgeId.length && wallByEdgeId[edgeId]) {
            return MeshTopology.NONE;
        }
        int other = mesh.edgeFace(edgeId, 0);
        return other == faceId ? mesh.edgeFace(edgeId, 1) : other;
    }

    /**
     * Walk the outline edges that are not walls into {@link #chains}, from every vertex where
     * the outline stops or forks, then into the {@link #loops} left over.
     */
    public void outline() {
        loops.clear();
        chains.clear();
        boolean[] open = new boolean[mesh.edgeIdBound()];
        int[] degree = new int[mesh.vertexIdBound()];
        for (int edge = 0; edge < mesh.edgeCount(); edge++) {
            int edgeId = mesh.edgeIdAt(edge);
            int left = mesh.edgeFace(edgeId, 0);
            int right = mesh.edgeFace(edgeId, 1);
            if (left == MeshTopology.NONE || right == MeshTopology.NONE
                    || inPatchByFaceId[left] == inPatchByFaceId[right]
                    || edgeId < wallByEdgeId.length && wallByEdgeId[edgeId]) {
                continue;
            }
            open[edgeId] = true;
            int halfEdge = mesh.edgeHalfEdge(edgeId);
            degree[mesh.halfEdgeVertex(halfEdge)]++;
            degree[mesh.halfEdgeEndVertex(halfEdge)]++;
        }
        for (int closed = 0; closed < 2; closed++) {
            for (int vertex = 0; vertex < mesh.vertexCount(); vertex++) {
                int startId = mesh.vertexIdAt(vertex);
                if (degree[startId] == 0 || closed == 0 && degree[startId] == 2) {
                    continue;
                }
                for (int index = 0; index < mesh.vertexEdgeCount(startId); index++) {
                    int edgeId = mesh.vertexEdgeAt(startId, index);
                    if (!open[edgeId]) {
                        continue;
                    }
                    List<Integer> walked = new ArrayList<>();
                    walked.add(startId);
                    int at = startId;
                    while (edgeId != MeshTopology.NONE) {
                        open[edgeId] = false;
                        at = mesh.edgeOtherVertex(edgeId, at);
                        walked.add(at);
                        edgeId = MeshTopology.NONE;
                        for (int onward = 0; degree[at] == 2 && at != startId
                                && onward < mesh.vertexEdgeCount(at); onward++) {
                            int candidate = mesh.vertexEdgeAt(at, onward);
                            edgeId = open[candidate] ? candidate : edgeId;
                        }
                    }
                    boolean loop = closed == 1 && at == startId;
                    int[] stretch = new int[walked.size() - (loop ? 1 : 0)];
                    for (int step = 0; step < stretch.length; step++) {
                        stretch[step] = walked.get(step);
                    }
                    (loop ? loops : chains).add(stretch);
                }
            }
        }
    }
}
