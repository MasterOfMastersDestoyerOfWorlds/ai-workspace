package ixdar.geometry.mesh.data.rings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.numeric.graph.UnionFind;
import ixdar.numeric.sparse.DirectSolver;
import ixdar.numeric.sparse.matrix.NormalMatrix;
import ixdar.numeric.sparse.ordering.OrderingMethod;
import ixdar.numeric.sparse.system.DofSystem;

/**
 * Settles every wall of a ring segmentation in one sparse solve: region middles are pinned, the
 * band beside the walls is free, and grooves insulate, so walls move into them.
 */
public final class RingSettle {

    // Random walker segmentation (Grady, "Random Walks for Image Segmentation", PAMI 2006) on the
    // face graph: each region's membership is harmonic, one on its own pinned faces and zero on
    // the others', and a free face goes to the region with the largest.

    // Width of the free band either side of a wall, in mean edge lengths.
    public static final double DEFAULT_BAND_EDGES = 8.0;

    // An edge in a groove just deep enough to saturate the groove strength conducts
    // exp(-insulation) as well as one on flat surface, and a deeper one less still.
    public static final double DEFAULT_INSULATION = 6.0;

    // Depth, in mean edge lengths, under which a region is a strip that pins nothing.
    public static final double DEFAULT_THIN_EDGES = 2.0;

    // Added to every diagonal entry so a free patch no pinned face touches still factorizes.
    public static final double REGULARIZATION = 1.0e-9;

    // A region shallower than twice the band pins the faces deeper than its depth over this.
    public static final int DEPTH_SHARE = 2;

    public static final String SLOT = "_ring_settle";

    public static final int COORDINATES = 3;

    // The deepest groove conducts exp(-this) as well as flat surface: deeper adds nothing, and
    // the system stays well conditioned.
    public static final double STRONGEST_INSULATION = 18.0;

    // Sweeps over the faces that each take the one-face teeth off the settled walls.
    public static final int TOOTH_PASSES = 4;

    // A boundary stretch's edges are followed by its two end vertices and its ring.
    public static final int STRETCH_TAIL = 3;

    // Two faces count as at least this share of the mean edge length apart, so a degenerate pair
    // whose centroids coincide conducts strongly, not without bound.
    public static final double SHORTEST_STEP = 0.01;

    /** The regions as the rings were drawn, whose middles are pinned. */
    public final RingRegions regions;

    /** Surface the regions lie on. */
    public final MeshTopology mesh;

    /** Region of each face once settled, by dense face index, numbered as {@link #regions} are. */
    public final int[] regionByActiveFace;

    /** Mean edge length of the surface, the unit of the band and strip widths. */
    public double meanEdgeLength;

    /** Faces the solve was free to move. */
    public int freeFaces;

    /** Faces the solve gave to another region. */
    public int movedFaces;

    /** Regions that pinned nothing, slivers and strips, whose faces their neighbours took. */
    public int unpinnedRegions;

    /** Boundary stretches moved to another ring's label so that the settled walls all wall. */
    public int mergedStretches;

    /** Seconds the last solve took. */
    public double seconds;

    /**
     * The solve state, as the quad-layout stages hold theirs: one degree of freedom per face,
     * the pinned faces frozen; relaxing it settles {@link #regionByActiveFace}.
     */
    public final DofSystem system;

    private final int[] activeByFaceId;
    private final float[] centroid;
    private final double[] depth;
    private final double[] regionDepth;
    private final Map<Long, int[]> ringOfPair = new HashMap<>();
    private final boolean[] pinned;
    private final boolean[] regionPins;
    private final double[] largest;
    private int solvingRegion;
    private SurfaceCreases creases;

    /**
     * Measures how deep inside its region every face lies: the distance over face centroids to
     * the nearest wall, never across one.
     *
     * @param regions built regions of the rings to settle
     */
    public RingSettle(RingRegions regions) {
        this.regions = regions;
        mesh = regions.mesh;
        int faceCount = mesh.faceCount();
        regionByActiveFace = Arrays.copyOf(regions.regionByActiveFace, faceCount);
        system = new DofSystem(faceCount);
        pinned = system.frozen;
        regionPins = new boolean[regions.regionCount];
        largest = new double[faceCount];
        activeByFaceId = new int[mesh.faceIdBound()];
        centroid = new float[COORDINATES * faceCount];
        Vector3f corner = new Vector3f();
        for (int face = 0; face < faceCount; face++) {
            int faceId = mesh.faceIdAt(face);
            activeByFaceId[faceId] = face;
            int corners = mesh.faceVertexCount(faceId);
            for (int slot = 0; slot < corners; slot++) {
                mesh.vertexPosition(mesh.faceVertexAt(faceId, slot), corner);
                centroid[COORDINATES * face] += corner.x / corners;
                centroid[COORDINATES * face + 1] += corner.y / corners;
                centroid[COORDINATES * face + 2] += corner.z / corners;
            }
        }
        boolean[] wall = new boolean[mesh.edgeIdBound()];
        for (int ring = 0; ring < regions.ringLabels.length; ring++) {
            for (int edgeId : regions.ringIsWall[ring] ? regions.ringEdgeIds[ring] : new int[0]) {
                wall[edgeId] = true;
            }
        }
        for (int edge = 0; edge < mesh.edgeCount(); edge++) {
            meanEdgeLength += mesh.edgeLength(mesh.edgeIdAt(edge)) / Math.max(1, mesh.edgeCount());
        }
        // Dijkstra over the faces from every face on a wall; the queue holds a distance's float
        // bits above its face, which order as the distances do.
        depth = new double[faceCount];
        Arrays.fill(depth, Double.POSITIVE_INFINITY);
        PriorityQueue<Long> open = new PriorityQueue<>();
        for (int face = 0; face < faceCount; face++) {
            int faceId = mesh.faceIdAt(face);
            for (int side = 0; side < mesh.faceEdgeCount(faceId); side++) {
                if (wall[mesh.faceEdgeAt(faceId, side)] && depth[face] > 0) {
                    depth[face] = 0;
                    open.add((long) face);
                }
            }
        }
        while (!open.isEmpty()) {
            long entry = open.poll();
            int face = (int) entry;
            if (Float.intBitsToFloat((int) (entry >>> Integer.SIZE)) > depth[face]) {
                continue;
            }
            int faceId = mesh.faceIdAt(face);
            for (int side = 0; side < mesh.faceEdgeCount(faceId); side++) {
                int edgeId = mesh.faceEdgeAt(faceId, side);
                int otherId = mesh.edgeFace(edgeId, 0) == faceId ? mesh.edgeFace(edgeId, 1)
                        : mesh.edgeFace(edgeId, 0);
                if (wall[edgeId] || otherId == MeshTopology.NONE) {
                    continue;
                }
                int other = activeByFaceId[otherId];
                // Rounded to the float the queue holds, so the entry is not taken for a stale one.
                double reached = (float) (depth[face] + centroidDistance(face, other));
                if (reached < depth[other]) {
                    depth[other] = reached;
                    open.add((long) Float.floatToIntBits((float) reached) << Integer.SIZE | other);
                }
            }
        }
        regionDepth = new double[regions.regionCount];
        for (int face = 0; face < faceCount; face++) {
            int region = regions.regionByActiveFace[face];
            regionDepth[region] = Math.max(regionDepth[region], depth[face]);
        }
        // Which ring separated each pair of regions as drawn: the one with most edges between them.
        int ringCount = regions.ringLabels.length;
        Map<Long, Integer> votes = new HashMap<>();
        for (int ring = 0; ring < ringCount; ring++) {
            for (int edgeId : regions.ringIsWall[ring] ? regions.ringEdgeIds[ring] : new int[0]) {
                int left = mesh.edgeFace(edgeId, 0);
                int right = mesh.edgeFace(edgeId, 1);
                if (left == MeshTopology.NONE || right == MeshTopology.NONE) {
                    continue;
                }
                int one = regions.regionByActiveFace[activeByFaceId[left]];
                int two = regions.regionByActiveFace[activeByFaceId[right]];
                if (one != two) {
                    long pair = (long) Math.min(one, two) * regions.regionCount + Math.max(one, two);
                    int count = votes.merge(pair * ringCount + ring, 1, Integer::sum);
                    int[] leader = ringOfPair.computeIfAbsent(pair, absent -> new int[2]);
                    if (count > leader[1]) {
                        leader[0] = ring;
                        leader[1] = count;
                    }
                }
            }
        }
    }

    /**
     * Distance between two faces' centroids.
     *
     * @param face  dense index of one face
     * @param other dense index of the other
     * @return the distance, at least a small share of the mean edge length
     */
    public double centroidDistance(int face, int other) {
        double x = centroid[COORDINATES * face] - centroid[COORDINATES * other];
        double y = centroid[COORDINATES * face + 1] - centroid[COORDINATES * other + 1];
        double z = centroid[COORDINATES * face + 2] - centroid[COORDINATES * other + 2];
        return Math.max(Math.sqrt(x * x + y * y + z * z), SHORTEST_STEP * meanEdgeLength);
    }

    /**
     * Pin the faces that stay and fill {@link #system}: the face graph's Laplacian with grooves
     * insulating, the pins frozen, and the solve and write-back that settle the regions.
     *
     * @param grooves    groove strength of the surface, which insulates
     * @param bandEdges  width of the free band either side of a wall, in mean edge lengths
     * @param insulation how strongly a groove insulates: conductance falls by {@code exp(-this)}
     *                   at full groove strength
     * @param thinEdges  depth in mean edge lengths under which a region pins nothing
     * @param kept       surface points, packed xyz, whose faces stay in their region: the points
     *                   part labels name regions by, so no wall moves across a name
     */
    public void assemble(SurfaceCreases grooves, double bandEdges, double insulation, double thinEdges,
            List<float[]> kept) {
        int faceCount = mesh.faceCount();
        creases = grooves;
        Arrays.fill(pinned, false);
        Arrays.fill(regionPins, false);
        List<Integer> keptFaces = new ArrayList<>();
        for (float[] points : kept) {
            for (int point = 0; point < points.length / COORDINATES; point++) {
                keptFaces.add(regions.nearestActiveFace(points[COORDINATES * point],
                        points[COORDINATES * point + 1], points[COORDINATES * point + 2]));
                regionPins[regions.regionByActiveFace[keptFaces.get(keptFaces.size() - 1)]] = true;
            }
        }
        unpinnedRegions = 0;
        for (int region = 0; region < regions.regionCount; region++) {
            regionPins[region] |= !regions.isSliver(region)
                    && regionDepth[region] >= thinEdges * meanEdgeLength;
            unpinnedRegions += regionPins[region] ? 0 : 1;
        }
        for (int face = 0; face < faceCount; face++) {
            int region = regions.regionByActiveFace[face];
            pinned[face] = regionPins[region] && depth[face] >= Math.min(bandEdges * meanEdgeLength,
                    regionDepth[region] / DEPTH_SHARE);
        }
        // A kept face is pinned with the fewest faces that join it to its region's pinned middle,
        // found breadth first inside the region, so no wall passes between a name and its part.
        for (int keptFace : keptFaces) {
            Map<Integer, Integer> cameFrom = new HashMap<>();
            List<Integer> reached = new ArrayList<>(List.of(keptFace));
            cameFrom.put(keptFace, keptFace);
            int middle = keptFace;
            for (int head = 0; head < reached.size() && !pinned[middle]; head++) {
                int face = reached.get(head);
                int faceId = mesh.faceIdAt(face);
                middle = pinned[face] ? face : middle;
                for (int side = 0; !pinned[face] && side < mesh.faceEdgeCount(faceId); side++) {
                    int edgeId = mesh.faceEdgeAt(faceId, side);
                    int otherId = mesh.edgeFace(edgeId, 0) == faceId ? mesh.edgeFace(edgeId, 1)
                            : mesh.edgeFace(edgeId, 0);
                    int other = otherId == MeshTopology.NONE ? face : activeByFaceId[otherId];
                    if (regions.regionByActiveFace[other] == regions.regionByActiveFace[face]
                            && cameFrom.putIfAbsent(other, face) == null) {
                        reached.add(other);
                    }
                }
            }
            for (int face = middle; !pinned[keptFace]; face = cameFrom.get(face)) {
                pinned[face] = true;
            }
        }
        freeFaces = 0;
        for (int face = 0; face < faceCount; face++) {
            freeFaces += pinned[face] ? 0 : 1;
        }
        // The weighted face-graph Laplacian: a face's row holds minus the conductance to each
        // neighbour and their sum on the diagonal. Keys are written in row then column order.
        double[] diagonal = new double[faceCount];
        Arrays.fill(diagonal, REGULARIZATION);
        long[] keys = new long[2 * faceCount];
        double[] values = new double[2 * faceCount];
        int entries = 0;
        for (int face = 0; face < faceCount; face++) {
            int faceId = mesh.faceIdAt(face);
            int rowStart = entries;
            for (int side = 0; side < mesh.faceEdgeCount(faceId); side++) {
                int edgeId = mesh.faceEdgeAt(faceId, side);
                int otherId = mesh.edgeFace(edgeId, 0) == faceId ? mesh.edgeFace(edgeId, 1)
                        : mesh.edgeFace(edgeId, 0);
                int other = otherId == MeshTopology.NONE ? face : activeByFaceId[otherId];
                if (other == face || pinned[face] && pinned[other]) {
                    continue;
                }
                int halfEdge = mesh.edgeHalfEdge(edgeId);
                // The unsaturated groove depth, so a groove's bottom insulates more than its flanks.
                double groove = (grooves.valleyCurvature[mesh.halfEdgeVertex(halfEdge)]
                        + grooves.valleyCurvature[mesh.halfEdgeEndVertex(halfEdge)])
                        / (2 * Math.max(grooves.saturation, Double.MIN_NORMAL));
                double conductance = mesh.edgeLength(edgeId) / centroidDistance(face, other)
                        * Math.exp(-Math.min(insulation * groove, STRONGEST_INSULATION));
                diagonal[face] += conductance;
                if (other < face) {
                    continue;
                }
                long key = (long) face << NormalMatrix.KEY_ROW_SHIFT | other;
                int at = rowStart;
                while (at < entries && keys[at] < key) {
                    at++;
                }
                if (at < entries && keys[at] == key) {
                    values[at] -= conductance;
                    continue;
                }
                if (entries == keys.length) {
                    keys = Arrays.copyOf(keys, 2 * entries);
                    values = Arrays.copyOf(values, 2 * entries);
                }
                System.arraycopy(keys, at, keys, at + 1, entries - at);
                System.arraycopy(values, at, values, at + 1, entries - at);
                keys[at] = key;
                values[at] = -conductance;
                entries++;
            }
        }
        // The system is linear, so its matrix is the same at every solution. Its solution is one
        // region's membership at a time, which the write-back takes into the settled regions:
        // a free face goes to the region with the largest membership so far.
        NormalMatrix laplacian = new NormalMatrix(diagonal, Arrays.copyOf(keys, entries),
                Arrays.copyOf(values, entries), new double[faceCount]);
        system.assembler = solution -> laplacian;
        system.solve = this::relaxRegions;
        system.writeBack = () -> {
            for (int face = 0; face < faceCount; face++) {
                if (!pinned[face] && system.solution[face] > largest[face]) {
                    largest[face] = system.solution[face];
                    regionByActiveFace[face] = solvingRegion;
                }
            }
        };
    }

    /**
     * The system's solve: factorize once, then for each region that pins faces hold its pins at
     * one and the others' at zero, solve its membership and write it back.
     */
    public void relaxRegions() {
        long started = System.nanoTime();
        int faceCount = mesh.faceCount();
        System.arraycopy(regions.regionByActiveFace, 0, regionByActiveFace, 0, faceCount);
        Arrays.fill(largest, 0.0);
        NormalMatrix matrix = system.assemble();
        DirectSolver.CholeskyHandle handle = DirectSolver.factorize(matrix, pinned, OrderingMethod.AMD);
        for (int region = 0; region < regions.regionCount && freeFaces < faceCount; region++) {
            if (!regionPins[region]) {
                continue;
            }
            solvingRegion = region;
            for (int face = 0; face < faceCount; face++) {
                if (pinned[face]) {
                    system.solution[face] = regions.regionByActiveFace[face] == region ? 1 : 0;
                }
            }
            DirectSolver.solveCompact(handle, matrix, matrix.rightHandSide, system.solution, system.solution,
                    pinned);
            system.writeBack.run();
        }
        DirectSolver.releaseHandle(handle);
        movedFaces = 0;
        for (int face = 0; face < faceCount; face++) {
            movedFaces += regionByActiveFace[face] == regions.regionByActiveFace[face] ? 0 : 1;
        }
        seconds = (System.nanoTime() - started) / 1e9;
    }

    /**
     * Tidy the settled regions: a free face most of whose neighbours lie in one other region
     * joins it, which takes the teeth off the walls; then each island with no pinned face goes
     * to the region it shares the longest border with.
     *
     * @return faces that changed region
     */
    public int tidy() {
        int faceCount = mesh.faceCount();
        int absorbed = 0;
        int[] patch = new int[faceCount];
        int[] queue = new int[faceCount];
        for (int pass = 0; pass < TOOTH_PASSES && freeFaces < faceCount; pass++) {
            for (int face = 0; face < faceCount; face++) {
                int faceId = mesh.faceIdAt(face);
                int sides = mesh.faceEdgeCount(faceId);
                // The region across each side; a region across more than half of them takes the face.
                for (int side = 0; !pinned[face] && side < sides; side++) {
                    int edgeId = mesh.faceEdgeAt(faceId, side);
                    int otherId = mesh.edgeFace(edgeId, 0) == faceId ? mesh.edgeFace(edgeId, 1)
                            : mesh.edgeFace(edgeId, 0);
                    queue[side] = otherId == MeshTopology.NONE ? regionByActiveFace[face]
                            : regionByActiveFace[activeByFaceId[otherId]];
                    int agreeing = 0;
                    for (int earlier = 0; earlier <= side; earlier++) {
                        agreeing += queue[earlier] == queue[side] ? 1 : 0;
                    }
                    if (2 * agreeing > sides && queue[side] != regionByActiveFace[face]) {
                        regionByActiveFace[face] = queue[side];
                        absorbed++;
                    }
                }
            }
        }
        for (boolean changed = freeFaces > 0 && freeFaces < faceCount; changed;) {
            changed = false;
            Arrays.fill(patch, MeshTopology.NONE);
            for (int seed = 0; seed < faceCount; seed++) {
                if (patch[seed] != MeshTopology.NONE) {
                    continue;
                }
                int region = regionByActiveFace[seed];
                Map<Integer, Double> borders = new HashMap<>();
                boolean holdsPin = false;
                int tail = 0;
                queue[tail++] = seed;
                patch[seed] = seed;
                for (int head = 0; head < tail; head++) {
                    int face = queue[head];
                    int faceId = mesh.faceIdAt(face);
                    holdsPin |= pinned[face];
                    for (int side = 0; side < mesh.faceEdgeCount(faceId); side++) {
                        int edgeId = mesh.faceEdgeAt(faceId, side);
                        int otherId = mesh.edgeFace(edgeId, 0) == faceId ? mesh.edgeFace(edgeId, 1)
                                : mesh.edgeFace(edgeId, 0);
                        int other = otherId == MeshTopology.NONE ? face : activeByFaceId[otherId];
                        if (regionByActiveFace[other] != region) {
                            borders.merge(regionByActiveFace[other], (double) mesh.edgeLength(edgeId), Double::sum);
                        } else if (patch[other] == MeshTopology.NONE) {
                            patch[other] = seed;
                            queue[tail++] = other;
                        }
                    }
                }
                if (holdsPin || borders.isEmpty()) {
                    continue;
                }
                int taker = region;
                for (Map.Entry<Integer, Double> border : borders.entrySet()) {
                    taker = taker == region || border.getValue() > borders.get(taker) ? border.getKey() : taker;
                }
                for (int index = 0; index < tail; index++) {
                    regionByActiveFace[queue[index]] = taker;
                }
                absorbed += tail;
                changed = true;
            }
        }
        movedFaces = 0;
        for (int face = 0; face < faceCount; face++) {
            movedFaces += regionByActiveFace[face] == regions.regionByActiveFace[face] ? 0 : 1;
        }
        return absorbed;
    }

    /**
     * The settled walls as one edge mask per ring: each stretch of boundary between two settled
     * regions goes to the ring that separated those two regions as drawn.
     *
     * @return masks by edge id, parallel to the regions' ring labels; a ring that walled nothing
     *         keeps its mask
     */
    public boolean[][] marks() {
        int ringCount = regions.ringLabels.length;
        boolean[] open = new boolean[mesh.edgeIdBound()];
        int[] degree = new int[mesh.vertexIdBound()];
        long[] pairByEdgeId = new long[mesh.edgeIdBound()];
        for (int edge = 0; edge < mesh.edgeCount(); edge++) {
            int edgeId = mesh.edgeIdAt(edge);
            int left = mesh.edgeFace(edgeId, 0);
            int right = mesh.edgeFace(edgeId, 1);
            if (left == MeshTopology.NONE || right == MeshTopology.NONE) {
                continue;
            }
            int one = regionByActiveFace[activeByFaceId[left]];
            int two = regionByActiveFace[activeByFaceId[right]];
            if (one != two) {
                open[edgeId] = true;
                pairByEdgeId[edgeId] = (long) Math.min(one, two) * regions.regionCount + Math.max(one, two);
                int halfEdge = mesh.edgeHalfEdge(edgeId);
                degree[mesh.halfEdgeVertex(halfEdge)]++;
                degree[mesh.halfEdgeEndVertex(halfEdge)]++;
            }
        }
        // Walk the boundary into stretches between its forks, then the loops left over: each its
        // edges, its two end vertices, then its ring, one bounding a region where no ring fits.
        List<int[]> stretches = new ArrayList<>();
        for (int closed = 0; closed < 2; closed++) {
            for (int vertex = 0; vertex < mesh.vertexCount(); vertex++) {
                int startId = mesh.vertexIdAt(vertex);
                if (degree[startId] == 0 || closed == 0 && degree[startId] == 2) {
                    continue;
                }
                for (int index = 0; index < mesh.vertexEdgeCount(startId); index++) {
                    int edgeId = mesh.vertexEdgeAt(startId, index);
                    if (!open[edgeId]) {
                        continue;
                    }
                    int[] stretch = new int[STRETCH_TAIL];
                    int edges = 0;
                    int at = startId;
                    while (edgeId != MeshTopology.NONE) {
                        open[edgeId] = false;
                        if (edges == stretch.length) {
                            stretch = Arrays.copyOf(stretch, 2 * stretch.length);
                        }
                        stretch[edges++] = edgeId;
                        at = mesh.edgeOtherVertex(edgeId, at);
                        edgeId = MeshTopology.NONE;
                        for (int onward = 0; degree[at] == 2 && at != startId
                                && onward < mesh.vertexEdgeCount(at); onward++) {
                            int candidate = mesh.vertexEdgeAt(at, onward);
                            edgeId = open[candidate] ? candidate : edgeId;
                        }
                    }
                    int[] leader = ringOfPair.get(pairByEdgeId[stretch[0]]);
                    int[] bounding = regions.boundingRingsByRegion[(int) (pairByEdgeId[stretch[0]]
                            / regions.regionCount)];
                    stretch = Arrays.copyOf(stretch, edges + STRETCH_TAIL);
                    stretch[edges] = startId;
                    stretch[edges + 1] = at;
                    stretch[edges + 2] = leader != null ? leader[0] : bounding.length > 0 ? bounding[0] : 0;
                    stretches.add(stretch);
                }
            }
        }
        // The rings that wall as the region flood reads them: closed, or every loose end on a
        // wall. A ring's loose end is a vertex only one of its stretches ends at.
        long vertexBound = mesh.vertexIdBound();
        Map<Long, Integer> endsAt = new HashMap<>();
        for (int[] stretch : stretches) {
            int edges = stretch.length - STRETCH_TAIL;
            endsAt.merge(stretch[edges + 2] * vertexBound + stretch[edges], 1, Integer::sum);
            endsAt.merge(stretch[edges + 2] * vertexBound + stretch[edges + 1], 1, Integer::sum);
        }
        boolean[] walls = new boolean[ringCount];
        boolean[] onWall = new boolean[mesh.vertexIdBound()];
        for (boolean grew = true; grew;) {
            grew = false;
            boolean[] landed = new boolean[ringCount];
            Arrays.fill(landed, true);
            for (int[] stretch : stretches) {
                int edges = stretch.length - STRETCH_TAIL;
                for (int end = edges; end < edges + 2; end++) {
                    landed[stretch[edges + 2]] &= onWall[stretch[end]]
                            || endsAt.get(stretch[edges + 2] * vertexBound + stretch[end]) > 1;
                }
            }
            for (int[] stretch : stretches) {
                int edges = stretch.length - STRETCH_TAIL;
                if (walls[stretch[edges + 2]] || !landed[stretch[edges + 2]]) {
                    continue;
                }
                grew = true;
                for (int step = 0; step < edges; step++) {
                    int halfEdge = mesh.edgeHalfEdge(stretch[step]);
                    onWall[mesh.halfEdgeVertex(halfEdge)] = true;
                    onWall[mesh.halfEdgeEndVertex(halfEdge)] = true;
                }
            }
            for (int ring = 0; ring < ringCount; ring++) {
                walls[ring] |= landed[ring];
            }
        }
        // Stretches left on rings that wall nothing would let the regions leak, so each connected
        // run of them goes whole to the ring holding most of it: its ends then all lie on walls.
        int[] run = UnionFind.singletons(stretches.size());
        Map<Integer, Integer> firstAt = new HashMap<>();
        for (int index = 0; index < stretches.size(); index++) {
            int[] stretch = stretches.get(index);
            int edges = stretch.length - STRETCH_TAIL;
            for (int end = edges; !walls[stretch[edges + 2]] && end < edges + 2; end++) {
                Integer first = firstAt.putIfAbsent(stretch[end], index);
                if (first != null) {
                    UnionFind.union(run, first, index);
                }
            }
        }
        Map<Long, Integer> held = new HashMap<>();
        Map<Integer, int[]> holder = new HashMap<>();
        for (int index = 0; index < stretches.size(); index++) {
            int[] stretch = stretches.get(index);
            int ring = stretch[stretch.length - 1];
            if (!walls[ring]) {
                int root = UnionFind.find(run, index);
                int count = held.merge((long) root * ringCount + ring, stretch.length, Integer::sum);
                int[] most = holder.computeIfAbsent(root, absent -> new int[2]);
                if (count > most[1]) {
                    most[0] = ring;
                    most[1] = count;
                }
            }
        }
        boolean[][] masks = new boolean[ringCount][];
        for (int ring = 0; ring < ringCount; ring++) {
            masks[ring] = regions.ringIsWall[ring] ? new boolean[mesh.edgeIdBound()]
                    : regions.ringMarksByEdgeId[ring];
        }
        mergedStretches = 0;
        for (int index = 0; index < stretches.size(); index++) {
            int[] stretch = stretches.get(index);
            int drawn = stretch[stretch.length - 1];
            int ring = walls[drawn] ? drawn : holder.get(UnionFind.find(run, index))[0];
            mergedStretches += ring == drawn ? 0 : 1;
            for (int step = 0; step < stretch.length - STRETCH_TAIL; step++) {
                masks[ring][stretch[step]] = true;
            }
        }
        return masks;
    }

    /**
     * One line saying what the last solve did, with the walls' length and their mean groove
     * strength, the energy the solve lowers, as drawn and settled.
     *
     * @return the free and moved face counts, the regions that pinned nothing, the walls and the time
     */
    public String report() {
        // Length, then length times groove strength: of the walls as drawn, then as settled.
        double[] walls = new double[4];
        for (int edge = 0; edge < mesh.edgeCount(); edge++) {
            int edgeId = mesh.edgeIdAt(edge);
            int left = mesh.edgeFace(edgeId, 0);
            int right = mesh.edgeFace(edgeId, 1);
            if (left == MeshTopology.NONE || right == MeshTopology.NONE) {
                continue;
            }
            int halfEdge = mesh.edgeHalfEdge(edgeId);
            double length = mesh.edgeLength(edgeId);
            double groove = length * (creases.valleyCurvature[mesh.halfEdgeVertex(halfEdge)]
                    + creases.valleyCurvature[mesh.halfEdgeEndVertex(halfEdge)])
                    / (2 * Math.max(creases.saturation, Double.MIN_NORMAL));
            int[][] regionOf = { regions.regionByActiveFace, regionByActiveFace };
            for (int settled = 0; settled < 2; settled++) {
                if (regionOf[settled][activeByFaceId[left]] != regionOf[settled][activeByFaceId[right]]) {
                    walls[2 * settled] += length;
                    walls[2 * settled + 1] += groove;
                }
            }
        }
        return String.format(Locale.ROOT, "settled %d rings: %d of %d faces free, %d moved to another region, "
                + "%d of %d regions pinned nothing, %d boundary stretches relabelled to wall; walls %.2f long at "
                + "mean groove depth %.3f as drawn, %.2f long at %.3f settled; mean edge %.5f, %.1f s",
                regions.ringLabels.length, freeFaces, mesh.faceCount(), movedFaces, unpinnedRegions,
                regions.regionCount, mergedStretches, walls[0], walls[1] / Math.max(walls[0], Double.MIN_NORMAL),
                walls[2], walls[3] / Math.max(walls[2], Double.MIN_NORMAL), meanEdgeLength, seconds);
    }
}
