package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.quadlayout.embedding.RingPatchNetwork;
import ixdar.geometry.mesh.quadlayout.gridmap.GlobalGridMap;
import ixdar.geometry.mesh.quadlayout.gridmap.GridWallPull;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The energy stage of fit_rings: adds the crease field to an assembled grid map's relaxation,
 * pulling the grid lines of the ring arcs onto the grooves beside them.
 */
@MeshNodeAnnotation(id = RingCreaseEnergyNode.NODE_ID, category = NodeCategory.SELECTION)
public class RingCreaseEnergyNode implements MeshNode {

    public static final String NODE_ID = "ring_crease_energy";

    public static final double DEFAULT_PULL = 10.0;

    public static final double DEFAULT_BAND_CELLS = 1.0;

    public static final InputPort UV = new InputPort("uv", PortType.UV_FIELD, null);
    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort CREASES = SplineRingNode.CREASES;
    public static final InputPort PULL = new InputPort("pull", PortType.FLOAT, (float) DEFAULT_PULL, 0f,
            100000f);
    public static final InputPort BAND = new InputPort("band", PortType.FLOAT, (float) DEFAULT_BAND_CELLS,
            0.01f, 1000f);
    public static final OutputPort UV_OUT = new OutputPort(UV.name, PortType.UV_FIELD);
    public static final OutputPort DOFS = new OutputPort("dofs", PortType.DOF_SYSTEM);

    @Override
    public List<InputPort> inputs() {
        return List.of(UV, GEOMETRY, CREASES, PULL, BAND);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(UV_OUT, DOFS);
    }

    @Override
    public String description() {
        return "Adds the crease field as an energy to a grid map's relaxation. Every vertex within "
                + "reach of a ring arc's grid line is drawn onto that line with the strength of "
                + "the groove it stands in, so the relaxation moves the line, and with it the "
                + "wall and the nodes on it, into the deepest groove beside it. The map's "
                + "distortion energy stays, as what keeps the map from folding. Seams, cuts and "
                + "the arcs the conforming added pull nothing.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                UV.name,
                "The assembled grid map, from grid_map_assembly; passed on with the energy added.",
                GEOMETRY.name,
                "The bundle ring_network put its network on, which says which arcs are rings.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on the surface the rings "
                        + "were drawn on; measured here when not wired.",
                PULL.name,
                "Weight of the crease energy against the map's distortion; 0 relaxes the "
                        + "distortion alone.",
                BAND.name,
                "How far either side of a wall a groove draws it, in grid cells.",
                DOFS.name,
                "The grid map's DOF system, what a newton_solver node relaxes.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (!(ctx.getInput(UV.name, Object.class) instanceof GlobalGridMap map) || bundle == null
                || !(bundle.slots().get(RingPatchNetwork.SLOT) instanceof RingPatchNetwork rings)) {
            ctx.setOutput(UV.name, null);
            ctx.setOutput(DOFS.name, null);
            return;
        }
        SurfaceCreases creases = ctx.getInput(CREASES.name, SurfaceCreases.class);
        float[] strength = (creases == null ? SurfaceCreases.of(bundle.mesh()) : creases).valleyStrength;
        double[] field = new double[strength.length];
        for (int vertexId = 0; vertexId < field.length; vertexId++) {
            field[vertexId] = strength[vertexId];
        }
        map.wallPull = new GridWallPull(map, rings.ringArcs(), field,
                ctx.getInputValue(PULL.name) instanceof Number pull ? pull.doubleValue() : DEFAULT_PULL,
                ctx.getInputValue(BAND.name) instanceof Number band ? band.doubleValue() : DEFAULT_BAND_CELLS);
        ctx.setOutput(UV.name, map);
        ctx.setOutput(DOFS.name, map.gridDofs.system);
    }
}
