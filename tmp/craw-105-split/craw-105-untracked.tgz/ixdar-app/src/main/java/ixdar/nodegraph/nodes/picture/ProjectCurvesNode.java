package ixdar.nodegraph.nodes.picture;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.CurveGeometry;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.sculpt.CurveProjection;
import ixdar.geometry.mesh.data.sculpt.StrokeSketch;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * Lays curves drawn on a multiview SVG onto a surface, as seen through the cell each was drawn in,
 * so spline_ring and add_label can take a drawn line by its index.
 */
@MeshNodeAnnotation(id = ProjectCurvesNode.NODE_ID, category = NodeCategory.CURVE_OPERATIONS)
public class ProjectCurvesNode implements MeshNode {

    public static final String NODE_ID = "project_curves";

    public static final InputPort GEOMETRY = InputPort.manifoldGeometry("geometry");

    public static final InputPort CURVES = new InputPort("curves", PortType.GEOMETRY_BUNDLE, null);

    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name, PortType.GEOMETRY_BUNDLE);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CURVES);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT);
    }

    @Override
    public String description() {
        return "Casts each curve of svg_to_curves onto a surface, one ray a pixel along the line through the "
                + "cell it was drawn in, and keeps its longest run over one piece of the surface: where two "
                + "neighbouring rays land on faces that do not touch, the gap is bisected until it closes, and "
                + "a gap that never closes (a silhouette, or a slit onto a face behind) breaks the line.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name, "Input: the surface. Output: the same surface carrying the projected curves in the "
                        + CurveProjection.SLOT + " slot, curve k from SVG shape k: its surface points, point "
                        + "attribute " + CurveProjection.DRAWN_ATTRIBUTE + " (1 on the points drawn in the SVG), "
                        + "and curve attributes " + CurveProjection.DROPPED_ATTRIBUTE + " (drawn points missed or "
                        + "outside the kept run) and " + String.join(", ", CurveProjection.NORMAL_ATTRIBUTES)
                        + " (the plane of the rays through its first and last drawn points). spline_ring and "
                        + "add_label read curve k with curve=k.",
                CURVES.name, "The geometry output of svg_to_curves.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = Objects.requireNonNullElse(ctx.getInput(GEOMETRY.name, GeometryBundle.class),
                GeometryBundle.empty());
        GeometryBundle drawn = ctx.getInput(CURVES.name, GeometryBundle.class);
        StrokeSketch sketch = StrokeSketch.templateOf(drawn, NODE_ID);
        MeshTopology mesh = bundle.mesh();
        if (sketch == null || mesh == null || mesh.faceCount() == 0) {
            ctx.setOutput(GEOMETRY.name, bundle);
            return;
        }
        CurveGeometry curves = (CurveGeometry) drawn.slots().get(CurveGeometry.SLOT);
        ctx.setOutput(GEOMETRY.name, bundle.withSlot(CurveProjection.SLOT,
                new CurveProjection(mesh).project(sketch, curves)));
    }
}
