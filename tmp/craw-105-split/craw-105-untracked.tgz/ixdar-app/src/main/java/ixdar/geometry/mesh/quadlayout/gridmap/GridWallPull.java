package ixdar.geometry.mesh.quadlayout.gridmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.quadlayout.embedding.ArcNetwork;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedArc;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedMeshTopology;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedPatch;

/**
 * An energy a grid map's relaxation adds to its distortion: a field over the surface pulling
 * the vertices where it is strong onto the grid lines of chosen arcs, so those arcs settle
 * where the field is strongest.
 */
public final class GridWallPull {

    // A vertex further than this many widths from an arc's grid line feels nothing of it.
    public static final double REACH_WIDTHS = 4;

    private static final int KEY_SHIFT = 32;

    private static final double GRID_KEY_SCALE = 1024;

    /** Width of the pull either side of a grid line, in grid units. */
    public final double width;

    /** Solver variable of each pulled coordinate. */
    public int[] variables = new int[0];

    /** Grid line value each pulled coordinate is drawn to. */
    public double[] lines = new double[0];

    /** Strength of each pull: the field at the vertex, by the surface it stands for. */
    public double[] weights = new double[0];

    /**
     * Gathers the pulls of an assembled map: every vertex within reach of the grid line of a
     * pulling arc, weighted by the field there and its share of the surface.
     *
     * @param gridMap          assembled map, its DOF system built
     * @param pullsByArcId     which arcs pull, by arc id
     * @param fieldByVertexId  field strength by source vertex id, 0 to 1
     * @param strength         weight of the whole pull against the map's distortion
     * @param width            width of the pull either side of a grid line, in grid units
     */
    public GridWallPull(GlobalGridMap gridMap, boolean[] pullsByArcId, double[] fieldByVertexId, double strength,
            double width) {
        this.width = width;
        ArcNetwork tmesh = gridMap.tmesh;
        EmbeddedMeshTopology topology = tmesh.topology;
        HalfEdgeMesh copy = topology.copy;
        List<double[]> pulls = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        double surface = 0;
        for (EmbeddedPatch patch : tmesh.patches) {
            if (!patch.alive) {
                continue;
            }
            // The field and the surface share of every vertex of the patch, off its faces.
            Map<Integer, double[]> fieldAndArea = new HashMap<>();
            for (int copyFace : gridMap.patchMaps.regions.copyFacesByPatch.get(patch.patchId)) {
                int sourceFace = topology.sourceFaceByCopyFace()[copyFace];
                for (int corner = 0; corner < HalfEdgeMesh.TRIANGLE_CORNERS; corner++) {
                    int copyVertex = copy.faceVertexAt(copyFace, corner);
                    double[] barycentric = topology.barycentricOf(sourceFace, copyVertex);
                    double field = 0;
                    for (int index = 0; barycentric != null && index < HalfEdgeMesh.TRIANGLE_CORNERS; index++) {
                        field += barycentric[index]
                                * fieldByVertexId[topology.sourceMesh.faceVertexAt(sourceFace, index)];
                    }
                    double[] entry = fieldAndArea.computeIfAbsent(copyVertex, key -> new double[2]);
                    entry[0] = field;
                    entry[1] += copy.faceArea(copyFace) / HalfEdgeMesh.TRIANGLE_CORNERS;
                    surface += copy.faceArea(copyFace) / HalfEdgeMesh.TRIANGLE_CORNERS;
                }
            }
            double[] uv = gridMap.uvByPatchId[patch.patchId];
            Map<Integer, Integer> denseByCopyVertex = gridMap.denseByCopyVertexByPatchId[patch.patchId];
            PatchRectangleMap map = gridMap.patchMaps.mapByPatchId[patch.patchId];
            for (int side = 0; side < EmbeddedPatch.SIDES; side++) {
                EmbeddedArc arc = tmesh.arcs.get(patch.sideArcIds.get(side).get(0));
                if (!pullsByArcId[arc.arcId]) {
                    continue;
                }
                // The side lies on one grid line of the patch's chart: the coordinate its two
                // ends share.
                List<Integer> path = arc.path.copyVertexPath;
                int first = denseByCopyVertex.get(path.get(0)) * GlobalGridMap.GRID_COORDINATES;
                int last = denseByCopyVertex.get(path.get(path.size() - 1)) * GlobalGridMap.GRID_COORDINATES;
                int axis = Math.abs(uv[first] - uv[last]) < Math.abs(uv[first + 1] - uv[last + 1]) ? 0 : 1;
                double line = uv[first + axis];
                for (int dense = 0; dense < map.vertexLabel.length; dense++) {
                    double[] entry = fieldAndArea.get(map.vertexLabel[dense]);
                    boolean ownChart = gridMap.gridDofs.rotationByPatchDense[patch.patchId][dense] == 0
                            && gridMap.gridDofs.translationUByPatchDense[patch.patchId][dense] == 0
                            && gridMap.gridDofs.translationVByPatchDense[patch.patchId][dense] == 0;
                    int variable = gridMap.gridDofs.slotByPatchDense[patch.patchId][dense]
                            * GlobalGridMap.GRID_COORDINATES + axis;
                    if (entry == null || !ownChart || Math.abs(uv[dense * GlobalGridMap.GRID_COORDINATES + axis]
                            - line) > REACH_WIDTHS * width
                            || !seen.add((long) variable << KEY_SHIFT | Math.round(line * GRID_KEY_SCALE)
                                    & (1L << KEY_SHIFT) - 1)) {
                        continue;
                    }
                    pulls.add(new double[] { variable, line, strength * entry[0] * entry[1] });
                }
            }
        }
        variables = new int[pulls.size()];
        lines = new double[pulls.size()];
        weights = new double[pulls.size()];
        // A vertex's share is counted against the mean share, so the strength means the same on
        // any mesh.
        double meanShare = surface / Math.max(1, copy.vertexCount());
        for (int pull = 0; pull < variables.length; pull++) {
            variables[pull] = (int) pulls.get(pull)[0];
            lines[pull] = pulls.get(pull)[1];
            weights[pull] = pulls.get(pull)[2] / Math.max(meanShare, Double.MIN_NORMAL);
        }
    }

    /**
     * The pull's energy at one set of slot values: lower the more strong-field vertices sit on
     * their grid lines.
     *
     * @param x interleaved slot coordinates
     * @return the energy, never positive
     */
    public double energy(double[] x) {
        double total = 0;
        for (int pull = 0; pull < variables.length; pull++) {
            double away = (x[variables[pull]] - lines[pull]) / width;
            total -= weights[pull] * Math.exp(-away * away / 2);
        }
        return total;
    }

    /**
     * Adds the pull's negative gradient and its Hessian diagonal, the curvature kept only where
     * it is positive so the system stays solvable.
     *
     * @param x             interleaved slot coordinates
     * @param diagonal      Hessian diagonal to add to
     * @param rightHandSide negative gradient to add to
     */
    public void assembleInto(double[] x, double[] diagonal, double[] rightHandSide) {
        for (int pull = 0; pull < variables.length; pull++) {
            double away = (x[variables[pull]] - lines[pull]) / width;
            double bump = weights[pull] * Math.exp(-away * away / 2) / width;
            rightHandSide[variables[pull]] -= bump * away;
            diagonal[variables[pull]] += Math.max(0, bump * (1 - away * away) / width);
        }
    }
}
