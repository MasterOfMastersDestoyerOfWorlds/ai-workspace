package ixdar.geometry.mesh.data.rings;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.geodesic.TracedSurfacePath;
import ixdar.geometry.mesh.data.representation.MeshTopology;

/**
 * Where each point of a traced ring lies between the ring's anchors: a point moves with the two
 * anchors it lies between, by its share of the way from the first to the second.
 */
public final class RingBlend {

    public static final int COORDINATES_PER_POINT = 3;

    // A walked anchor takes the edge that runs least along its ring, among those that run along
    // it by less than this cosine; where none does, the edge that runs most across.
    public static final double MOST_SLIDE = 0.5;

    /** The path point nearest each anchor, in anchor order. */
    public final int[] place;

    /**
     * The two anchors each path point lies between, by path point; {@code null} for a path that
     * does not pass its anchors in their order once round.
     */
    public final int[][] between;

    /** Each path point's share of the way from its first anchor to its second. */
    public final double[] onto;

    /** The ring's direction at each path point, a unit vector. */
    public final Vector3f[] tangent;

    /**
     * The direction across the ring within the surface at each path point, a unit vector to the
     * same side of the ring all the way along it.
     */
    public final Vector3f[] across;

    /**
     * The blend of one traced ring.
     *
     * @param mesh           surface the ring lies on
     * @param path           the ring as traced
     * @param anchorVertexId its anchors, in ring order
     */
    public RingBlend(MeshTopology mesh, TracedSurfacePath path, int[] anchorVertexId) {
        place = new int[anchorVertexId.length];
        onto = new double[path.pointCount];
        Vector3f position = new Vector3f();
        int turnsBack = 0;
        for (int anchor = 0; anchor < anchorVertexId.length; anchor++) {
            mesh.vertexPosition(anchorVertexId[anchor], position);
            double nearest = Double.POSITIVE_INFINITY;
            for (int point = 0; point < path.pointCount; point++) {
                double apart = position.distanceSquared((float) path.positions[COORDINATES_PER_POINT * point],
                        (float) path.positions[COORDINATES_PER_POINT * point + 1],
                        (float) path.positions[COORDINATES_PER_POINT * point + 2]);
                if (apart < nearest) {
                    nearest = apart;
                    place[anchor] = point;
                }
            }
            turnsBack += anchor > 0 && place[anchor] < place[anchor - 1] ? 1 : 0;
        }
        turnsBack += anchorVertexId.length > 1 && place[0] < place[anchorVertexId.length - 1] ? 1 : 0;
        double[] along = new double[path.pointCount + 1];
        for (int point = 0; point < path.pointCount; point++) {
            int next = point + 1 < path.pointCount ? point + 1 : path.closed ? 0 : point;
            double squared = 0;
            for (int axis = 0; axis < COORDINATES_PER_POINT; axis++) {
                double gap = path.positions[COORDINATES_PER_POINT * next + axis]
                        - path.positions[COORDINATES_PER_POINT * point + axis];
                squared += gap * gap;
            }
            along[point + 1] = along[point] + Math.sqrt(squared);
        }
        between = turnsBack > 1 ? null : new int[path.pointCount][];
        for (int point = 0; between != null && point < path.pointCount; point++) {
            int before = path.closed ? anchorVertexId.length - 1 : 0;
            for (int anchor = 0; anchor < anchorVertexId.length; anchor++) {
                before = place[anchor] <= point ? anchor : before;
            }
            int after = before + 1 < anchorVertexId.length ? before + 1 : path.closed ? 0 : before;
            double span = place[after] > place[before] ? along[place[after]] - along[place[before]]
                    : after == before ? 0 : along[path.pointCount] - along[place[before]] + along[place[after]];
            double gone = point >= place[before] ? along[point] - along[place[before]]
                    : along[path.pointCount] - along[place[before]] + along[point];
            between[point] = new int[] { before, after };
            onto[point] = span > 0 ? Math.max(0, Math.min(1, gone / span)) : 0;
        }
        tangent = new Vector3f[path.pointCount];
        across = new Vector3f[path.pointCount];
        Vector3f normal = new Vector3f();
        for (int point = 0; point < path.pointCount; point++) {
            int ahead = COORDINATES_PER_POINT * (point + 1 < path.pointCount ? point + 1 : path.closed ? 0 : point);
            int behind = COORDINATES_PER_POINT * (point > 0 ? point - 1 : path.closed ? path.pointCount - 1 : point);
            position.set((float) (path.positions[ahead] - path.positions[behind]), (float) (path.positions[ahead + 1]
                    - path.positions[behind + 1]), (float) (path.positions[ahead + 2] - path.positions[behind + 2]));
            if (position.lengthSquared() > 0) {
                position.normalize();
            }
            if (path.vertexId[point] >= 0) {
                mesh.vertexNormal(path.vertexId[point], normal);
            } else if (path.edgeId[point] >= 0) {
                mesh.vertexNormal(mesh.halfEdgeVertex(mesh.edgeHalfEdge(path.edgeId[point])), normal);
            } else {
                mesh.faceNormal(path.faceId[point], normal);
            }
            tangent[point] = new Vector3f(position);
            normal.cross(position);
            if (normal.lengthSquared() > 0) {
                normal.normalize();
            }
            across[point] = new Vector3f(normal);
        }
    }

    /**
     * Walks an anchor across the ring edge by edge: each time by the edge that slides it least
     * along the ring, or where every edge slides it far, by the one that runs most across.
     *
     * @param mesh     surface the ring lies on
     * @param anchor   anchor of the ring
     * @param vertexId vertex the anchor stands on
     * @param edges    how many edges to walk, to the side {@link #across} points when positive
     * @return the vertex reached, the one given when no edge leaves it to that side
     */
    public int walked(MeshTopology mesh, int anchor, int vertexId, long edges) {
        Vector3f heading = new Vector3f(across[place[anchor]]).mul(Math.signum(edges));
        Vector3f base = new Vector3f();
        Vector3f gap = new Vector3f();
        int landed = vertexId;
        for (int hop = 0, last = MeshTopology.NONE; hop < Math.abs(edges) && last != landed; hop++) {
            last = landed;
            double least = MOST_SLIDE;
            double most = 0;
            mesh.vertexPosition(last, base);
            for (int spoke = 0; spoke < mesh.vertexEdgeCount(last); spoke++) {
                int neighbour = mesh.edgeOtherVertex(mesh.vertexEdgeAt(last, spoke), last);
                mesh.vertexPosition(neighbour, gap).sub(base).normalize();
                double slide = Math.abs(gap.dot(tangent[place[anchor]]));
                double runs = gap.dot(heading);
                if (runs > 0 && slide < least || least == MOST_SLIDE && runs > most) {
                    least = Math.min(least, slide);
                    most = runs;
                    landed = neighbour;
                }
            }
        }
        return landed;
    }
}
