package ixdar.nodegraph.nodes.selection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.EdgeMarks;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.labels.MeshLabels;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.quadlayout.embedding.RingNetworkCarve;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The extraction stage of fit_rings: carves the relaxed curves into a copy of the surface as an
 * arc network, the way quad_layout embeds its arcs, so the walls run where the curves do.
 */
@MeshNodeAnnotation(id = FittedRingMarksNode.NODE_ID, category = NodeCategory.SELECTION)
public class FittedRingMarksNode implements MeshNode {

    public static final String NODE_ID = "fitted_ring_marks";

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort DOFS = new InputPort("dofs", PortType.DOF_SYSTEM, null);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort REPORT = new OutputPort("report", PortType.STRING);
    public static final OutputPort TMESH = new OutputPort("tmesh", PortType.ARC_NETWORK);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, DOFS);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, REPORT, TMESH);
    }

    @Override
    public String description() {
        return "Carves relaxed ring curves into a working copy of the surface as an arc network, "
                + "in the quad layout's own embedding types. A vertex where walls meet is a node and each "
                + "curve between two is an arc; a loop is cut into two arcs. Each arc follows the "
                + "straight lines over the surface between its curve points, and the copy gets a "
                + "vertex wherever an arc crosses an edge, so a wall is no longer held to the "
                + "surface's own edges. The output surface is that copy, each ring's marks the "
                + "edges of its arcs; a ring that walled nothing keeps its marks.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: the bundle a ring_curves node put the curves to fit on. Output: the "
                        + "refined copy of its surface carrying every ring's carved marks and the "
                        + "part labels; anything else measured on the input surface is left "
                        + "behind, since its vertices are not the copy's.",
                DOFS.name,
                "The relaxed DOF system, from the newton_solver node that relaxed the "
                        + "ring_curves node's: wiring it runs the relaxation first.",
                REPORT.name,
                "The fit's curves, points, iterations and energies; the carve's nodes, arcs, "
                        + "wall length and groove depth and how much the surface grew; the region "
                        + "and sliver counts before and after; and the rings that stopped walling "
                        + "and the part names left without a region, both empty when all is well.",
                TMESH.name,
                "The carved arc network over the working copy: nodes, arcs and their edge paths, "
                        + "with no patches.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (bundle == null || !(bundle.slots().get(RingCurveFit.SLOT) instanceof RingCurveFit fit)) {
            ctx.setOutput(GEOMETRY.name, bundle == null ? GeometryBundle.empty() : bundle);
            ctx.setOutput(REPORT.name, "");
            ctx.setOutput(TMESH.name, null);
            return;
        }
        // The walls rounded to the surface's own edges, which the fit's report measures.
        fit.marks();
        RingNetworkCarve carve = new RingNetworkCarve(fit);
        carve.build();
        boolean[][] masks = carve.marks();
        RingRegions drawn = fit.regions;
        GeometryBundle out = GeometryBundle.ofMesh(carve.topology.copy).withSlot(MeshLabels.SLOT,
                MeshLabels.inBundle(bundle));
        for (int ring = 0; ring < masks.length; ring++) {
            out = EdgeMarks.with(out, drawn.ringLabels[ring], masks[ring]);
        }
        RingRegions fitted = new RingRegions(carve.topology.copy, drawn.ringLabels, masks).build();
        int[] slivers = new int[2];
        for (int region = 0; region < Math.max(drawn.regionCount, fitted.regionCount); region++) {
            slivers[0] += region < drawn.regionCount && drawn.isSliver(region) ? 1 : 0;
            slivers[1] += region < fitted.regionCount && fitted.isSliver(region) ? 1 : 0;
        }
        // The part names holding a region as drawn that hold none on the carved walls.
        MeshLabels labels = MeshLabels.inBundle(bundle);
        boolean[][] named = new boolean[2][labels.names.size()];
        for (int side = 0; side < 2; side++) {
            RingRegions regions = side == 0 ? drawn : fitted;
            int[] labelByRegion = new int[regions.regionCount];
            Arrays.fill(labelByRegion, MeshLabels.UNLABELLED);
            for (int label = 0; label < labels.names.size(); label++) {
                float[] points = labels.pointsByLabel.get(label);
                for (int point = 0; point + 2 < points.length; point += MeshLabels.XYZ) {
                    int activeFace = regions.nearestActiveFace(points[point], points[point + 1], points[point + 2]);
                    labelByRegion[regions.regionByActiveFace[activeFace]] = label;
                }
            }
            for (int label : labelByRegion) {
                named[side][Math.max(label, 0)] |= label != MeshLabels.UNLABELLED;
            }
        }
        List<String> lost = new ArrayList<>();
        for (int label = 0; label < labels.names.size(); label++) {
            if (named[0][label] && !named[1][label]) {
                lost.add(labels.names.get(label));
            }
        }
        List<String> opened = new ArrayList<>();
        for (int ring = 0; ring < masks.length; ring++) {
            if (drawn.ringIsWall[ring] && !fitted.ringIsWall[ring]) {
                opened.add(drawn.ringLabels[ring]);
            }
        }
        ctx.setOutput(GEOMETRY.name, out);
        ctx.setOutput(TMESH.name, carve.network);
        ctx.setOutput(REPORT.name, String.format(Locale.ROOT,
                "%s; %s; regions %d -> %d, slivers %d -> %d, rings that stopped walling %s, part names left "
                        + "without a region %s",
                fit.report(), carve.report(), drawn.regionCount, fitted.regionCount, slivers[0], slivers[1], opened,
                lost));
    }
}
