package ixdar.geometry.mesh.quadlayout.embedding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedMeshTopology;

/**
 * Fitted ring curves carved into a working copy of their surface as an {@link ArcNetwork}, the
 * way a quad layout's arcs are: the places walls meet are its nodes, the curves between its arcs.
 */
public final class RingNetworkCarve {

    // A loop shorter than this many points cannot be cut into two arcs.
    public static final int SHORTEST_LOOP_POINTS = 4;

    // Two crossings of one edge closer than this share of it take one vertex.
    public static final double SHARED_CROSSING = 0.02;

    // How many vertices are searched for the edges between two crossings no edge joins.
    public static final int BRIDGE_VERTICES = 4096;

    private static final int PAIR_SHIFT = 32;

    /** The relaxed curves being carved. */
    public final RingCurveFit fit;

    /** Surface the curves were fitted on, which is only read. */
    public final HalfEdgeMesh sourceMesh;

    /** Working copy the curves are carved into. */
    public final EmbeddedMeshTopology topology;

    /** The carved walls: a node where walls meet, an arc per curve; {@code null} until built. */
    public ArcNetwork network;

    /** Source vertex each node stands on. */
    public final List<Integer> vertexIdByNode = new ArrayList<>();

    /** Start and end node of each curve piece. */
    public final List<int[]> nodesByPiece = new ArrayList<>();

    /** Rings each curve piece is a stretch of; two rings drawn along one edge share a piece. */
    public final List<List<Integer>> ringsByPiece = new ArrayList<>();

    /** Arc of {@link #network} carrying each curve piece, {@link ArcNetwork#NONE} when none was laid. */
    public int[] arcByPiece = new int[0];

    /** Loops too short to cut in two, left out. */
    public int droppedLoops;

    /** Curve points no straight line over the surface reached, joined along edges instead. */
    public int skippedPoints;

    /** Curve pieces that could not be laid on the copy at all. */
    public int unlaidPieces;

    /** Steps between two crossings that no edge joined, walked along the copy's edges instead. */
    public int bridgedSteps;

    /** Length of the carved walls, and that length weighted by the groove depth under it. */
    public final double[] walls = new double[2];

    /** Seconds the last {@link #build} took. */
    public double seconds;

    private final List<int[]> endsByPiece = new ArrayList<>();
    private final List<double[]> fractionByPiece = new ArrayList<>();

    /**
     * Reads the curves off a relaxed fit as pieces between nodes: a curve's two ends, and for a
     * loop two of its own points moved onto their nearest vertices.
     *
     * @param fit relaxed curve fit, on a triangle {@link HalfEdgeMesh}
     * @throws IllegalArgumentException when the fit's surface is not a half-edge mesh
     */
    public RingNetworkCarve(RingCurveFit fit) {
        if (!(fit.mesh instanceof HalfEdgeMesh halfEdges)) {
            throw new IllegalArgumentException("ring curves can only be carved into a half-edge mesh");
        }
        this.fit = fit;
        sourceMesh = halfEdges;
        topology = new EmbeddedMeshTopology(sourceMesh);
        Map<Integer, Integer> nodeByVertexId = new HashMap<>();
        Map<Long, Integer> pieceByEdge = new HashMap<>();
        int[] ends = new int[2];
        for (int curve = 0; curve < fit.curveCount; curve++) {
            int first = fit.curveStart[curve];
            int count = fit.curveStart[curve + 1] - first;
            int length = fit.curveClosed[curve] ? count + 1 : count;
            int[] pointEnds = new int[2 * length];
            double[] pointFraction = new double[length];
            for (int place = 0; place < length; place++) {
                pointFraction[place] = fit.slidPoint(first + place % count, ends);
                pointEnds[2 * place] = ends[0];
                pointEnds[2 * place + 1] = ends[1];
            }
            // A curve that comes back to where it began is cut in two at its middle, so no arc
            // is a loop; the cuts stand on vertices, as every node does.
            boolean loop = pointEnds[0] == pointEnds[2 * length - 2] && pointFraction[0] == pointFraction[length - 1]
                    && pointEnds[1] == pointEnds[2 * length - 1];
            int[] cuts = loop ? new int[] { 0, length / 2, length - 1 } : new int[] { 0, length - 1 };
            for (int cut : cuts) {
                int onto = pointEnds[2 * cut + (pointFraction[cut] < 1.0 / 2 ? 0 : 1)];
                pointEnds[2 * cut] = onto;
                pointEnds[2 * cut + 1] = onto;
                pointFraction[cut] = 0;
            }
            if (loop && (length < SHORTEST_LOOP_POINTS || pointEnds[2 * cuts[1]] == pointEnds[0])) {
                droppedLoops++;
                continue;
            }
            for (int piece = 0; piece + 1 < cuts.length; piece++) {
                // The piece's points, a point standing where the one before does left out.
                int[] kept = new int[2 * (cuts[piece + 1] - cuts[piece] + 1)];
                double[] keptFraction = new double[kept.length / 2];
                int keptCount = 0;
                for (int place = cuts[piece]; place <= cuts[piece + 1]; place++) {
                    boolean repeats = keptCount > 0 && kept[2 * keptCount - 2] == pointEnds[2 * place]
                            && kept[2 * keptCount - 1] == pointEnds[2 * place + 1]
                            && keptFraction[keptCount - 1] == pointFraction[place];
                    if (!repeats) {
                        kept[2 * keptCount] = pointEnds[2 * place];
                        kept[2 * keptCount + 1] = pointEnds[2 * place + 1];
                        keptFraction[keptCount++] = pointFraction[place];
                    }
                }
                int[] nodes = new int[2];
                for (int end = 0; end < 2; end++) {
                    int vertexId = kept[end == 0 ? 0 : 2 * keptCount - 2];
                    nodes[end] = nodeByVertexId.computeIfAbsent(vertexId, id -> {
                        vertexIdByNode.add(id);
                        return vertexIdByNode.size() - 1;
                    });
                }
                long edge = (long) Math.min(nodes[0], nodes[1]) << PAIR_SHIFT | Math.max(nodes[0], nodes[1]);
                Integer shared = keptCount == 2 ? pieceByEdge.get(edge) : null;
                if (shared != null) {
                    ringsByPiece.get(shared).add(fit.curveRing[curve]);
                } else if (keptCount >= 2) {
                    if (keptCount == 2) {
                        pieceByEdge.put(edge, endsByPiece.size());
                    }
                    endsByPiece.add(Arrays.copyOf(kept, 2 * keptCount));
                    fractionByPiece.add(Arrays.copyOf(keptFraction, keptCount));
                    nodesByPiece.add(nodes);
                    ringsByPiece.add(new ArrayList<>(List.of(fit.curveRing[curve])));
                }
            }
        }
    }

    /**
     * Carves every piece into the working copy as an arc: the copy's edges are split where the
     * piece's straight lines cross them, which also joins each crossing to the one before.
     *
     * @return the carved network, also kept as {@link #network}
     */
    public ArcNetwork build() {
        long started = System.nanoTime();
        HalfEdgeMesh copy = topology.copy;
        // Every copy edge remembers the surface edge it lies on, through every split.
        float[] valley = fit.creases.valleyCurvature;
        Map<Integer, Double> depthByVertex = new HashMap<>();
        for (int activeEdge = 0; activeEdge < sourceMesh.edgeCount(); activeEdge++) {
            int halfEdge = sourceMesh.edgeHalfEdge(sourceMesh.edgeIdAt(activeEdge));
            int tail = sourceMesh.halfEdgeVertex(halfEdge);
            int head = sourceMesh.halfEdgeEndVertex(halfEdge);
            topology.sourceEdgeByCopyEdge()[copy.edgeBetween(topology.copyVertexForSourceVertexId(tail),
                    topology.copyVertexForSourceVertexId(head))] = activeEdge;
            depthByVertex.put(topology.copyVertexForSourceVertexId(tail), (double) valley[tail]);
            depthByVertex.put(topology.copyVertexForSourceVertexId(head), (double) valley[head]);
        }
        network = new ArcNetwork(topology);
        for (int vertexId : vertexIdByNode) {
            network.addNode(ArcNetwork.NONE, topology.copyVertexForSourceVertexId(vertexId), true, false);
        }
        int pieces = endsByPiece.size();
        arcByPiece = new int[pieces];
        Arrays.fill(arcByPiece, ArcNetwork.NONE);
        SurfaceChordTrace chord = new SurfaceChordTrace(sourceMesh);
        // The vertices minted on each surface edge, as {share from its lower-id end, copy vertex}.
        Map<Long, List<double[]>> mintedByEdge = new HashMap<>();
        List<List<Integer>> pathByPiece = new ArrayList<>();
        for (int piece = 0; piece < pieces; piece++) {
            int[] ends = endsByPiece.get(piece);
            double[] fraction = fractionByPiece.get(piece);
            List<Integer> path = new ArrayList<>(List.of(topology.copyVertexForSourceVertexId(ends[0])));
            pathByPiece.add(path);
            for (int place = 1; place < fraction.length; place++) {
                // A line that loses its way leaves only the point itself, joined along edges below.
                skippedPoints += chord.trace(ends[2 * place - 2], ends[2 * place - 1], fraction[place - 1],
                        ends[2 * place], ends[2 * place + 1], fraction[place]) ? 0 : 1;
                for (int crossing = 0; crossing < chord.crossingEnds.size(); crossing++) {
                    int low = Math.min(chord.crossingEnds.get(crossing)[0], chord.crossingEnds.get(crossing)[1]);
                    int high = Math.max(chord.crossingEnds.get(crossing)[0], chord.crossingEnds.get(crossing)[1]);
                    double share = chord.crossingEnds.get(crossing)[0] == low ? chord.crossingFractions.get(crossing)
                            : 1 - chord.crossingFractions.get(crossing);
                    int vertex = topology.copyVertexForSourceVertexId(low);
                    if (low != high) {
                        // The stretch of the edge the crossing falls in is split there, unless a
                        // vertex minted for another crossing already stands at it.
                        List<double[]> minted = mintedByEdge.computeIfAbsent((long) low << PAIR_SHIFT | high,
                                key -> new ArrayList<>(List.of(new double[] { 0, topology.copyVertexForSourceVertexId(low) },
                                        new double[] { 1, topology.copyVertexForSourceVertexId(high) })));
                        int after = 1;
                        while (minted.get(after)[0] < share) {
                            after++;
                        }
                        double[] below = minted.get(after - 1);
                        double[] above = minted.get(after);
                        if (share - below[0] < SHARED_CROSSING || above[0] - share < SHARED_CROSSING) {
                            vertex = (int) (share - below[0] < above[0] - share ? below : above)[1];
                        } else {
                            int edgeId = copy.edgeBetween((int) below[1], (int) above[1]);
                            double along = (share - below[0]) / (above[0] - below[0]);
                            vertex = topology.splitEdgeAtParameter(edgeId,
                                    copy.halfEdgeVertex(copy.edgeHalfEdge(edgeId)) == (int) below[1] ? along : 1 - along);
                            minted.add(after, new double[] { share, vertex });
                            depthByVertex.put(vertex, valley[low] + share * (valley[high] - valley[low]));
                        }
                    }
                    if (vertex != path.get(path.size() - 1)) {
                        path.add(vertex);
                    }
                }
            }
        }
        // The arcs are laid once every edge is split, so no later crossing cuts an edge of an arc.
        // Two crossings one face apart are joined by the edge the second split made; where
        // another wall cut the face or the edge between them, the few edges between are walked.
        for (int piece = 0; piece < pieces; piece++) {
            List<Integer> path = pathByPiece.get(piece);
            boolean reached = true;
            List<Integer> walked = new ArrayList<>(List.of(path.get(0)));
            for (int step = 1; reached && step < path.size(); step++) {
                int goal = path.get(step);
                Map<Integer, Integer> cameFrom = new HashMap<>(Map.of(goal, goal));
                List<Integer> frontier = new ArrayList<>(List.of(goal));
                for (int head = 0; head < frontier.size() && head < BRIDGE_VERTICES
                        && !cameFrom.containsKey(path.get(step - 1)); head++) {
                    int at = frontier.get(head);
                    for (int index = 0; index < copy.vertexEdgeCount(at); index++) {
                        int next = copy.edgeOtherVertex(copy.vertexEdgeAt(at, index), at);
                        if (cameFrom.putIfAbsent(next, at) == null) {
                            frontier.add(next);
                        }
                    }
                }
                reached = cameFrom.containsKey(path.get(step - 1));
                bridgedSteps += reached && cameFrom.get(path.get(step - 1)) != goal ? 1 : 0;
                for (int at = path.get(step - 1); reached && at != goal;) {
                    at = cameFrom.get(at);
                    // A walk that comes back to a vertex drops the loop or spur it made.
                    int seen = walked.indexOf(at);
                    if (seen >= 0) {
                        walked.subList(seen + 1, walked.size()).clear();
                    } else {
                        walked.add(at);
                    }
                }
            }
            reached &= walked.size() > 1 && walked.get(walked.size() - 1).equals(path.get(path.size() - 1));
            unlaidPieces += reached ? 0 : 1;
            for (int step = 1; reached && step < walked.size(); step++) {
                double length = copy.edgeLength(copy.edgeBetween(walked.get(step - 1), walked.get(step)));
                walls[0] += length;
                walls[1] += length * (depthByVertex.get(walked.get(step - 1)) + depthByVertex.get(walked.get(step)))
                        / (2 * Math.max(fit.creases.saturation, Double.MIN_NORMAL));
            }
            arcByPiece[piece] = reached ? network.addArc(ArcNetwork.NONE, nodesByPiece.get(piece)[0],
                    nodesByPiece.get(piece)[1], 1, false, walked) : ArcNetwork.NONE;
        }
        copy.computeNormals();
        seconds = (System.nanoTime() - started) / 1e9;
        return network;
    }

    /**
     * The carved walls as one edge mask per ring over the working copy: the edges of the arcs
     * carrying the ring's pieces. A ring that walled nothing keeps the edges it was drawn on.
     *
     * @return masks by copy edge id, parallel to the fit's ring labels
     */
    public boolean[][] marks() {
        HalfEdgeMesh copy = topology.copy;
        boolean[][] masks = new boolean[fit.regions.ringLabels.length][copy.edgeIdBound()];
        // How many of each ring's marked edges meet at each vertex, and of its pieces end there.
        List<Map<Integer, Integer>> degreeByRing = new ArrayList<>();
        List<Map<Integer, Integer>> endingsByRing = new ArrayList<>();
        for (int ring = 0; ring < masks.length; ring++) {
            Map<Integer, Integer> degree = new HashMap<>();
            Map<Integer, Integer> endings = new HashMap<>();
            degreeByRing.add(degree);
            endingsByRing.add(endings);
            for (int piece = 0; piece < arcByPiece.length; piece++) {
                if (arcByPiece[piece] == ArcNetwork.NONE || !ringsByPiece.get(piece).contains(ring)) {
                    continue;
                }
                for (int edgeId : network.arcs.get(arcByPiece[piece]).path.copyEdgePath) {
                    if (!masks[ring][edgeId]) {
                        masks[ring][edgeId] = true;
                        degree.merge(copy.halfEdgeVertex(copy.edgeHalfEdge(edgeId)), 1, Integer::sum);
                        degree.merge(copy.halfEdgeEndVertex(copy.edgeHalfEdge(edgeId)), 1, Integer::sum);
                    }
                }
                for (int node : nodesByPiece.get(piece)) {
                    endings.merge(topology.copyVertexForSourceVertexId(vertexIdByNode.get(node)), 1, Integer::sum);
                }
            }
        }
        // Two pieces leaving a node by one edge leave a spur there, which is not an end of the
        // ring: only a vertex an odd number of its pieces end at is. The spur is taken off the
        // ring and given to the walls that met it at its tip, so they still reach the ring.
        for (int ring = 0; ring < masks.length; ring++) {
            Map<Integer, Integer> degree = degreeByRing.get(ring);
            List<Integer> tips = new ArrayList<>(degree.keySet());
            for (int next = 0; next < tips.size(); next++) {
                int tip = tips.get(next);
                if (degree.get(tip) != 1 || endingsByRing.get(ring).getOrDefault(tip, 0) % 2 == 1) {
                    continue;
                }
                int spur = ArcNetwork.NONE;
                for (int index = 0; index < copy.vertexEdgeCount(tip); index++) {
                    spur = masks[ring][copy.vertexEdgeAt(tip, index)] ? copy.vertexEdgeAt(tip, index) : spur;
                }
                for (int other = 0; other < masks.length; other++) {
                    boolean meets = false;
                    for (int index = 0; other != ring && index < copy.vertexEdgeCount(tip); index++) {
                        meets |= masks[other][copy.vertexEdgeAt(tip, index)];
                    }
                    masks[other][spur] |= meets;
                }
                masks[ring][spur] = false;
                degree.merge(tip, -1, Integer::sum);
                degree.merge(copy.edgeOtherVertex(spur, tip), -1, Integer::sum);
                tips.add(copy.edgeOtherVertex(spur, tip));
            }
        }
        int[] sourceEdge = topology.sourceEdgeByCopyEdge();
        for (int ring = 0; ring < masks.length; ring++) {
            for (int edgeId = 0; !fit.regions.ringIsWall[ring] && edgeId < masks[ring].length; edgeId++) {
                masks[ring][edgeId] = edgeId < sourceEdge.length && sourceEdge[edgeId] != EmbeddedMeshTopology.UNCLAIMED
                        && fit.regions.ringMarksByEdgeId[ring][sourceMesh.edgeIdAt(sourceEdge[edgeId])];
            }
        }
        return masks;
    }

    /**
     * One line saying what the last {@link #build} did.
     *
     * @return the node and arc counts, the copy's growth, what was left out and the time
     */
    public String report() {
        return String.format(Locale.ROOT, "carved %d nodes and %d arcs: surface %d -> %d vertices, %d -> %d "
                + "faces; walls %.2f long at mean groove depth %.3f; %d loops too short, %d points no line "
                + "reached, %d steps walked along edges, %d pieces not laid; %.1f s", vertexIdByNode.size(),
                network == null ? 0 : network.arcs.size(), sourceMesh.vertexCount(), topology.copy.vertexCount(),
                sourceMesh.faceCount(), topology.copy.faceCount(), walls[0],
                walls[1] / Math.max(walls[0], Double.MIN_NORMAL), droppedLoops, skippedPoints, bridgedSteps,
                unlaidPieces, seconds);
    }
}
