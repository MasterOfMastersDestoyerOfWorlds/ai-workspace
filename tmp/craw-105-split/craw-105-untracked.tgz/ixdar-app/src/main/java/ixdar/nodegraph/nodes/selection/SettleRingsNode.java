package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;
import ixdar.nodegraph.runtime.GraphNodeContext;
import ixdar.nodegraph.runtime.GroupBuilder;
import ixdar.nodegraph.runtime.NodeGroup;

/**
 * Settles every ring and bisector on a surface together, as a compiled group of its stage nodes
 * the way quad_layout is: assemble the memberships' DOF system, relax it, extract the ring marks.
 */
@MeshNodeAnnotation(id = SettleRingsNode.NODE_ID, desktopOnly = true, category = NodeCategory.SELECTION)
public class SettleRingsNode extends NodeGroup {

    public static final String NODE_ID = "settle_rings";

    // The relaxation stage by registered id, as a DSL call names it: it is desktop-only.
    public static final String RELAX_TYPE = "newton_solver";

    public static final String DOFS_PORT = RingMembershipNode.DOFS.name;

    public static final InputPort GEOMETRY = RingMembershipNode.GEOMETRY;
    public static final InputPort CREASES = RingMembershipNode.CREASES;
    public static final InputPort LABELS = RingMembershipNode.LABELS;
    public static final InputPort BAND = RingMembershipNode.BAND;
    public static final InputPort INSULATION = RingMembershipNode.INSULATION;
    public static final InputPort THIN = RingMembershipNode.THIN;
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort REPORT = SettledRingMarksNode.REPORT;
    public static final OutputPort DOFS = new OutputPort(DOFS_PORT, PortType.DOF_SYSTEM);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CREASES, LABELS, BAND, INSULATION, THIN);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, REPORT, DOFS);
    }

    @Override
    public String description() {
        return "Settles every ring and bisector together, as a group of its stage nodes: "
                + "ring_membership pins each region's middle and builds the DOF system of the "
                + "free faces beside the walls, newton_solver relaxes it (one sparse Cholesky "
                + "factorization, one solve per region), and settled_ring_marks turns the "
                + "borders between the settled regions back into ring marks. A wall beside a "
                + "groove moves into it, a wall on smooth surface straightens, and a sliver or "
                + "thin strip goes to its neighbours.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying ring edge marks, after the last spline_ring, "
                        + "spline_cut and add_label statement: the face under each label point "
                        + "is pinned too, so no wall moves across a part's name. Output: the same "
                        + "bundle with every ring's marks replaced by its settled ones.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "when not wired.",
                LABELS.name,
                "Comma-separated edge-mark labels to settle. Empty takes every boolean edge-mark "
                        + "label on the bundle, which after the ring nodes is every ring.",
                BAND.name,
                "How far a wall may move: the width of the free band either side of it, in mean "
                        + "edge lengths.",
                INSULATION.name,
                "How strongly a groove holds a wall; 0 ignores the grooves and only straightens.",
                THIN.name,
                "A region no deeper than this many mean edge lengths, or a sliver, pins nothing "
                        + "and is taken by its neighbours.",
                REPORT.name,
                "How many faces were free and how many moved, the walls as drawn and settled, "
                        + "and the region and sliver counts before and after.",
                DOFS_PORT,
                "The relaxed DOF system of the memberships.");
    }

    @Override
    public void build(GroupBuilder group) {
        GraphNodeContext parameters = group.scope;
        GraphNodeContext membership = group.node("membership", RingMembershipNode::new)
                .input(RingMembershipNode.GEOMETRY.name, parameters, GEOMETRY.name)
                .input(RingMembershipNode.CREASES.name, parameters, CREASES.name)
                .input(RingMembershipNode.LABELS.name, parameters, LABELS.name)
                .input(RingMembershipNode.BAND.name, parameters, BAND.name)
                .input(RingMembershipNode.INSULATION.name, parameters, INSULATION.name)
                .input(RingMembershipNode.THIN.name, parameters, THIN.name);
        GraphNodeContext relax = group.node("relax", RELAX_TYPE)
                .input(DOFS_PORT, membership, DOFS_PORT);
        GraphNodeContext marks = group.node("marks", SettledRingMarksNode::new)
                .input(SettledRingMarksNode.GEOMETRY.name, membership, RingMembershipNode.GEOMETRY_OUT.name)
                .input(SettledRingMarksNode.DOFS.name, relax, DOFS_PORT);

        group.output(GEOMETRY_OUT.name, marks, SettledRingMarksNode.GEOMETRY_OUT.name);
        group.output(REPORT.name, marks, SettledRingMarksNode.REPORT.name);
        group.output(DOFS_PORT, relax, DOFS_PORT);
    }
}
