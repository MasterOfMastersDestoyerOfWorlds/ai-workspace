package ixdar.geometry.mesh.quadlayout.embedding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.stream.IntStream;

import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedArc;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedMeshTopology;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedNode;
import ixdar.geometry.mesh.quadlayout.embedding.model.EmbeddedPatch;
import ixdar.geometry.mesh.quadlayout.quantization.IntegerProgram;

/**
 * The walls of a ring carve as a quad layout's T-mesh: cuts leave every region as discs whose
 * boundaries turn four times, and the arcs take whole lengths the layout can conform.
 */
public final class RingPatchNetwork {

    // Bundle slot the later stages of fit_rings read the network from.
    public static final String SLOT = "_ring_patch_network";

    // A region's second seam foot on a loop stands at least this share of the loop from its first.
    public static final double FOOT_SPREAD = 0.25;

    // A disc whose boundary turns more often than this is cut across before it is starred.
    public static final int STAR_CORNERS = 6;

    // A disc with more turns than this tries only this many as corners, spread round it.
    public static final int CANDIDATES_TRIED = 12;

    // How much less a vertex where a wall arrives from outside is wanted as a corner than a plain one.
    public static final double NODE_RELUCTANCE = 1e-3;

    // A disc is padded only round a vertex at least this many edges from its boundary.
    public static final int PAD_DEPTH = 2;

    // A star's centre has this many edges for every spoke that must reach it.
    public static final int SPOKE_ROOM = 3;

    /** The carve whose walls are patched; its own arcs are given up. */
    public final RingNetworkCarve carve;

    /** Working copy the walls are carved into. */
    public final EmbeddedMeshTopology topology;

    /**
     * What each wall edge of the copy carries, by edge id: the rings drawn along it, or for an
     * edge of a cut the cut's own negative id.
     */
    public final Map<Integer, int[]> ringsByEdge = new LinkedHashMap<>();

    /** Rings of each wall edge that separated nothing and was left out, by its two vertices. */
    public final Map<Long, int[]> ringsByDroppedEdge = new LinkedHashMap<>();

    /** Copy vertices nodes stand on: where walls and cuts meet, and patch corners. */
    public final Set<Integer> nodeVertices = new LinkedHashSet<>();

    /** Rings of each ring arc, indexed by the arc's source arc id; a cut's arc has no source. */
    public final List<int[]> ringsByWall = new ArrayList<>();

    /** Boundary of each disc as the copy vertices round it, the disc on the left. */
    public List<int[]> loopByDisc = new ArrayList<>();

    /** Places of each disc's four corners along its boundary, ascending. */
    public final List<int[]> cornersByDisc = new ArrayList<>();

    /** The T-mesh: {@code null} until {@link #lay()}. */
    public ArcNetwork network;

    /** Cuts made: seams between loops, pads, chords across discs and the spokes of stars. */
    public int cutCount;

    /** Corners that had to stand where the boundary does not turn. */
    public int addedCorners;

    /** Arcs the conforming ran across patches. */
    public int extensionCount;

    // Discs a star could not be finished in, by the vertices their boundaries turn at.
    private final Set<Set<Integer>> unstarred = new LinkedHashSet<>();
    private int regionCount;
    private int[] regionByFace = new int[0];
    private double[] distance = new double[0];
    private int[] cameFrom = new int[0];

    /**
     * Reads the carved walls off a built carve as marked edges, gives up the carve's own arcs,
     * and leaves out every wall edge with one region on both sides.
     *
     * @param carve built carve
     */
    public RingPatchNetwork(RingNetworkCarve carve) {
        this.carve = carve;
        topology = carve.topology;
        HalfEdgeMesh copy = topology.copy;
        for (int piece = 0; piece < carve.arcByPiece.length; piece++) {
            if (carve.arcByPiece[piece] == ArcNetwork.NONE) {
                continue;
            }
            int[] rings = carve.ringsByPiece.get(piece).stream().mapToInt(Integer::intValue).toArray();
            for (int edgeId : carve.network.arcs.get(carve.arcByPiece[piece]).path.copyEdgePath) {
                int[] held = ringsByEdge.get(edgeId);
                ringsByEdge.put(edgeId, held == null ? rings
                        : IntStream.concat(Arrays.stream(held), Arrays.stream(rings)).distinct().toArray());
            }
        }
        for (EmbeddedArc arc : carve.network.arcs) {
            if (arc.alive) {
                carve.network.discardArc(arc.arcId);
            }
        }
        for (EmbeddedNode node : carve.network.nodes) {
            topology.ownerNodeByCopyVertex()[node.copyVertex] = EmbeddedMeshTopology.UNCLAIMED;
        }
        int[] region = flood();
        Set<Integer> onWalls = new LinkedHashSet<>();
        for (Iterator<Map.Entry<Integer, int[]>> walls = ringsByEdge.entrySet().iterator(); walls.hasNext();) {
            Map.Entry<Integer, int[]> wall = walls.next();
            int halfEdge = copy.edgeHalfEdge(wall.getKey());
            int tail = copy.halfEdgeVertex(halfEdge);
            int head = copy.halfEdgeEndVertex(halfEdge);
            if (region[copy.halfEdgeFace(halfEdge)] == region[copy.halfEdgeFace(copy.halfEdgeTwin(halfEdge))]) {
                ringsByDroppedEdge.put((long) Math.min(tail, head) << Integer.SIZE | Math.max(tail, head),
                        wall.getValue());
                walls.remove();
            } else {
                onWalls.add(tail);
                onWalls.add(head);
            }
        }
        for (int vertex : onWalls) {
            if (wallDegree(vertex) > 2) {
                nodeVertices.add(vertex);
            }
        }
    }

    /**
     * Cuts every region with several boundary loops into two discs: a chain of seams from loop
     * to loop and one closing it.
     *
     * @throws IllegalStateException when a seam finds no way across its region
     * @return this, its seams marked as cuts
     */
    public RingPatchNetwork seam() {
        HalfEdgeMesh copy = topology.copy;
        flood();
        // Room is left between walls that stand an edge apart, for the seams to pass.
        Set<Integer> onWalls = new LinkedHashSet<>();
        for (int edgeId : ringsByEdge.keySet()) {
            onWalls.add(copy.halfEdgeVertex(copy.edgeHalfEdge(edgeId)));
            onWalls.add(copy.halfEdgeEndVertex(copy.edgeHalfEdge(edgeId)));
        }
        for (int vertex : onWalls) {
            relieve(vertex);
        }
        // A region with a handle is still no disc after its seams, and is seamed again.
        boolean seamed = true;
        List<List<int[]>> loopsByRegion = List.of();
        for (int regionId = 0; seamed || regionId < loopsByRegion.size(); regionId++) {
            if (regionId >= loopsByRegion.size()) {
                seamed = false;
                regionId = 0;
                loopsByRegion = loops(flood());
            }
            List<int[]> loops = loopsByRegion.get(regionId);
            seamed |= loops.size() > 1;
            // The places along each loop where this region's seams stand.
            List<List<Integer>> feet = new ArrayList<>();
            for (int loop = 0; loop < loops.size(); loop++) {
                feet.add(new ArrayList<>());
            }
            boolean[] joined = new boolean[loops.size() + 1];
            joined[0] = true;
            int current = 0;
            for (int seam = 0; loops.size() > 1 && seam < loops.size(); seam++) {
                List<Integer> sources = new ArrayList<>();
                for (int place : footPlaces(loops.get(current), feet.get(current))) {
                    sources.add(loops.get(current)[place]);
                }
                // The vertices the seam may end on, as {loop, place}: the last seam closes the chain.
                Map<Integer, int[]> targets = new HashMap<>();
                for (int loop = 0; loop < loops.size(); loop++) {
                    if (seam == loops.size() - 1 ? loop != 0 : joined[loop]) {
                        continue;
                    }
                    for (int place : footPlaces(loops.get(loop), feet.get(loop))) {
                        targets.put(loops.get(loop)[place], new int[] { loop, place });
                    }
                }
                List<Integer> path = route(regionId, sources, targets.keySet());
                if (path.isEmpty()) {
                    throw new IllegalStateException("no seam could be routed across region " + regionId + " of "
                            + loops.size() + " boundary loops, from its loop " + current + " of " + sources.size()
                            + " places to " + targets.size() + (seam == loops.size() - 1 ? " on its first loop"
                                    : " on its other loops"));
                }
                cut(path);
                int[] target = targets.get(path.get(0));
                feet.get(target[0]).add(target[1]);
                for (int place = 0; place < loops.get(current).length; place++) {
                    if (loops.get(current)[place] == path.get(path.size() - 1)) {
                        feet.get(current).add(place);
                    }
                }
                joined[target[0]] = true;
                current = target[0];
            }
        }
        return this;
    }

    /**
     * Cuts one handle of every region that has a single boundary loop and is still no disc, as
     * fused parts of a scan leave it: along a loop round the handle that does not part the region.
     *
     * @return whether a handle was cut, which leaves its region for {@link #seam()} to cut
     */
    public boolean handle() {
        HalfEdgeMesh copy = topology.copy;
        List<List<int[]>> loopsByRegion = loops(flood());
        // Inner vertices less inner edges plus faces, which is one for a disc.
        int[] characteristic = new int[regionCount];
        int[] seedFace = new int[regionCount];
        for (int active = 0; active < copy.faceCount(); active++) {
            characteristic[regionByFace[copy.faceIdAt(active)]]++;
            seedFace[regionByFace[copy.faceIdAt(active)]] = copy.faceIdAt(active);
        }
        for (int active = 0; active < copy.edgeCount(); active++) {
            if (!ringsByEdge.containsKey(copy.edgeIdAt(active))) {
                characteristic[regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(copy.edgeIdAt(active)))]]--;
            }
        }
        for (int active = 0; active < copy.vertexCount(); active++) {
            int vertex = copy.vertexIdAt(active);
            if (copy.vertexEdgeCount(vertex) > 0 && wallDegree(vertex) == 0) {
                characteristic[regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(copy.vertexEdgeAt(vertex, 0)))]]++;
            }
        }
        boolean cut = false;
        for (int regionId = 0; regionId < regionCount; regionId++) {
            if (loopsByRegion.get(regionId).size() != 1 || characteristic[regionId] == 1) {
                continue;
            }
            // A tree of the region's vertices grown inwards from its boundary.
            Map<Integer, Integer> before = new HashMap<>();
            Map<Integer, Integer> depth = new HashMap<>();
            BitSet inTree = new BitSet();
            List<Integer> frontier = new ArrayList<>();
            for (int vertex : loopsByRegion.get(regionId).get(0)) {
                if (depth.putIfAbsent(vertex, 0) == null) {
                    before.put(vertex, MeshTopology.NONE);
                    frontier.add(vertex);
                }
            }
            for (int head = 0; head < frontier.size(); head++) {
                int at = frontier.get(head);
                for (int index = 0; index < copy.vertexEdgeCount(at); index++) {
                    int edgeId = copy.vertexEdgeAt(at, index);
                    int next = copy.edgeOtherVertex(edgeId, at);
                    if (!ringsByEdge.containsKey(edgeId) && regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(
                            edgeId))] == regionId && wallDegree(next) == 0
                            && depth.putIfAbsent(next, depth.get(at) + 1) == null) {
                        before.put(next, at);
                        inTree.set(edgeId);
                        frontier.add(next);
                    }
                }
            }
            // A tree of its faces that crosses no edge of the first; the edges in neither tree
            // each close a loop round a handle.
            BitSet reached = new BitSet();
            BitSet crossed = new BitSet();
            List<Integer> faces = new ArrayList<>(List.of(seedFace[regionId]));
            List<Integer> uncrossed = new ArrayList<>();
            reached.set(seedFace[regionId]);
            for (int head = 0; head < faces.size(); head++) {
                int halfEdge = copy.faceHalfEdge(faces.get(head));
                for (int corner = 0; corner < HalfEdgeMesh.TRIANGLE_CORNERS; corner++) {
                    int edgeId = copy.halfEdgeEdge(halfEdge);
                    int across = copy.halfEdgeFace(copy.halfEdgeTwin(halfEdge));
                    if (!ringsByEdge.containsKey(edgeId) && !inTree.get(edgeId) && across != MeshTopology.NONE) {
                        if (reached.get(across)) {
                            uncrossed.add(edgeId);
                        } else {
                            reached.set(across);
                            crossed.set(edgeId);
                            faces.add(across);
                        }
                    }
                    halfEdge = copy.halfEdgeNext(halfEdge);
                }
            }
            int closing = MeshTopology.NONE;
            int shortest = Integer.MAX_VALUE;
            for (int edgeId : uncrossed) {
                int tail = copy.halfEdgeVertex(copy.edgeHalfEdge(edgeId));
                int head = copy.halfEdgeEndVertex(copy.edgeHalfEdge(edgeId));
                if (!crossed.get(edgeId) && depth.containsKey(tail) && depth.containsKey(head)
                        && depth.get(tail) + depth.get(head) < shortest) {
                    shortest = depth.get(tail) + depth.get(head);
                    closing = edgeId;
                }
            }
            if (closing == MeshTopology.NONE) {
                continue;
            }
            // From each end of that edge back to the boundary, less the stretch the two ways share.
            List<Integer> first = new ArrayList<>();
            for (int at = copy.halfEdgeVertex(copy.edgeHalfEdge(closing)); at != MeshTopology.NONE; at = before
                    .get(at)) {
                first.add(at);
            }
            List<Integer> second = new ArrayList<>();
            for (int at = copy.halfEdgeEndVertex(copy.edgeHalfEdge(closing)); at != MeshTopology.NONE; at = before
                    .get(at)) {
                second.add(at);
            }
            int met = 0;
            while (met < first.size() && !second.contains(first.get(met))) {
                met++;
            }
            boolean closed = met < first.size();
            List<Integer> path = new ArrayList<>();
            for (int step = closed ? met : met - 1; step >= 0; step--) {
                path.add(first.get(step));
            }
            path.addAll(second.subList(0, closed ? second.indexOf(first.get(met)) : second.size()));
            int[] round = { -++cutCount };
            for (int step = closed ? 0 : 1; step < path.size(); step++) {
                ringsByEdge.put(copy.edgeBetween(path.get((step + path.size() - 1) % path.size()), path.get(step)),
                        round);
            }
            // Its ends on the boundary are nodes; a loop that closes inside the region has none.
            if (!closed || depth.get(path.get(0)) == 0) {
                nodeVertices.add(path.get(0));
                nodeVertices.add(path.get(closed ? 0 : path.size() - 1));
            }
            cut = true;
        }
        return cut;
    }

    /**
     * Pads every disc whose ring boundary turns at most once with a small loop round its
     * innermost vertex, so its missing corners stand on that loop and not on a ring.
     *
     * @return whether a disc was padded, which leaves it for {@link #seam()} to cut
     */
    public boolean pad() {
        HalfEdgeMesh copy = topology.copy;
        List<List<int[]>> loopsByRegion = loops(flood());
        boolean padded = false;
        for (int regionId = 0; regionId < loopsByRegion.size(); regionId++) {
            // A shell no wall touches has no boundary and is left alone.
            if (loopsByRegion.get(regionId).isEmpty()) {
                continue;
            }
            int[] loop = loopsByRegion.get(regionId).get(0);
            boolean ringed = false;
            for (int place = 0; place < loop.length; place++) {
                ringed |= ringsByEdge.get(copy.edgeBetween(loop[place], loop[(place + 1) % loop.length]))[0] >= 0;
            }
            int centre = !ringed || loopsByRegion.get(regionId).size() > 1 || turns(loop).size() > 1
                    ? MeshTopology.NONE : innermost(regionId, loop, 0, PAD_DEPTH);
            if (centre == MeshTopology.NONE) {
                continue;
            }
            int[] pad = { -++cutCount };
            for (int index = 0; index < copy.vertexEdgeCount(centre); index++) {
                int outward = copy.edgeHalfEdge(copy.vertexEdgeAt(centre, index));
                outward = copy.halfEdgeVertex(outward) == centre ? outward : copy.halfEdgeTwin(outward);
                ringsByEdge.put(copy.halfEdgeEdge(copy.halfEdgeNext(outward)), pad);
            }
            padded = true;
        }
        return padded;
    }

    /**
     * Cuts every disc whose boundary turns more often than a star can take across, from the
     * middle of one side to the middle of the side opposite.
     *
     * @return whether a disc was cut
     */
    public boolean chord() {
        List<List<int[]>> loopsByRegion = loops(flood());
        boolean cut = false;
        for (int regionId = 0; regionId < loopsByRegion.size(); regionId++) {
            // A shell no wall touches has no boundary and is left alone.
            if (loopsByRegion.get(regionId).isEmpty()) {
                continue;
            }
            int[] loop = loopsByRegion.get(regionId).get(0);
            List<Integer> turns = loopsByRegion.get(regionId).size() > 1 ? List.of() : turns(loop);
            int count = turns.size();
            List<Integer> path = List.of();
            for (int side = 0; count > STAR_CORNERS && path.isEmpty() && side < count / 2; side++) {
                int from = middle(loop, turns.get(side), turns.get(side + 1));
                int onto = middle(loop, turns.get(side + count / 2), turns.get((side + count / 2 + 1) % count));
                // Where the boundary touches itself the two middles can be one vertex, and no cut.
                if (from != MeshTopology.NONE && onto != MeshTopology.NONE && loop[from] != loop[onto]) {
                    path = route(regionId, List.of(loop[from]), Set.of(loop[onto]));
                }
            }
            if (!path.isEmpty()) {
                cut(path);
                cut = true;
            }
        }
        return cut;
    }

    /**
     * Cuts every disc whose boundary turns two, three, five or six times into four-cornered
     * pieces: a spoke from the middle of each side to its innermost vertex.
     *
     * @return whether a disc was starred
     */
    public boolean star() {
        HalfEdgeMesh copy = topology.copy;
        // A side one edge long is halved first, to give its spoke a foot.
        Set<Integer> oneEdgeSides = new LinkedHashSet<>();
        for (List<int[]> loops : loops(flood())) {
            int[] loop = loops.isEmpty() ? new int[0] : loops.get(0);
            List<Integer> turns = loops.size() != 1 ? List.of() : turns(loop);
            int count = turns.size();
            for (int side = 0; count > 1 && count != EmbeddedPatch.SIDES && count <= STAR_CORNERS
                    && side < count; side++) {
                if ((turns.get(side) + 1) % loop.length == turns.get((side + 1) % count)) {
                    oneEdgeSides.add(copy.edgeBetween(loop[turns.get(side)], loop[turns.get((side + 1) % count)]));
                }
            }
        }
        for (int edgeId : oneEdgeSides) {
            int from = copy.halfEdgeVertex(copy.edgeHalfEdge(edgeId));
            int onto = copy.halfEdgeEndVertex(copy.edgeHalfEdge(edgeId));
            int[] rings = ringsByEdge.remove(edgeId);
            int halfway = topology.splitEdgeAtMidpoint(edgeId);
            ringsByEdge.put(copy.edgeBetween(from, halfway), rings);
            ringsByEdge.put(copy.edgeBetween(halfway, onto), rings);
        }
        List<List<int[]>> loopsByRegion = loops(flood());
        boolean starred = false;
        for (int regionId = 0; regionId < loopsByRegion.size(); regionId++) {
            // A shell no wall touches has no boundary and is left alone.
            if (loopsByRegion.get(regionId).isEmpty()) {
                continue;
            }
            int[] loop = loopsByRegion.get(regionId).get(0);
            List<Integer> turns = loopsByRegion.get(regionId).size() > 1 ? List.of() : turns(loop);
            int count = turns.size();
            Set<Integer> corners = new LinkedHashSet<>();
            for (int turn : turns) {
                corners.add(loop[turn]);
            }
            if (count < 2 || count == EmbeddedPatch.SIDES || count > STAR_CORNERS || unstarred.contains(corners)) {
                continue;
            }
            // A centre deep inside is given edges until every spoke has room to arrive; a shallow
            // one must have them already.
            int centre = innermost(regionId, loop, 0, PAD_DEPTH);
            while (centre != MeshTopology.NONE && copy.vertexEdgeCount(centre) < SPOKE_ROOM * count) {
                List<Integer> link = new ArrayList<>();
                for (int index = 0; index < copy.vertexEdgeCount(centre); index++) {
                    int outward = copy.edgeHalfEdge(copy.vertexEdgeAt(centre, index));
                    outward = copy.halfEdgeVertex(outward) == centre ? outward : copy.halfEdgeTwin(outward);
                    link.add(copy.halfEdgeEdge(copy.halfEdgeNext(outward)));
                }
                for (int edgeId : link) {
                    halve(edgeId);
                }
            }
            centre = centre == MeshTopology.NONE ? innermost(regionId, loop, count, 1) : centre;
            List<List<Integer>> spokes = new ArrayList<>();
            List<Integer> newNodes = new ArrayList<>();
            boolean reached = centre != MeshTopology.NONE;
            for (int side = 0; reached && side < count; side++) {
                int from = middle(loop, turns.get(side), turns.get((side + 1) % count));
                List<Integer> path = from == MeshTopology.NONE ? List.<Integer>of()
                        : route(regionId, List.of(loop[from]), Set.of(centre));
                reached = !path.isEmpty();
                if (reached) {
                    newNodes.addAll(nodeVertices.contains(loop[from]) ? List.of() : List.of(loop[from]));
                    // Marked at once, so the next spoke keeps off this one.
                    cut(path);
                    spokes.add(path);
                }
            }
            starred |= reached;
            // A star a spoke could not finish is taken out again, and its disc not tried twice.
            if (!reached) {
                unstarred.add(corners);
                cutCount -= spokes.size();
                nodeVertices.remove(centre);
                nodeVertices.removeAll(newNodes);
            }
            for (int spoke = 0; !reached && spoke < spokes.size(); spoke++) {
                for (int step = 1; step < spokes.get(spoke).size(); step++) {
                    ringsByEdge.remove(copy.edgeBetween(spokes.get(spoke).get(step - 1), spokes.get(spoke).get(step)));
                }
            }
        }
        return starred;
    }

    /**
     * Picks four corners on every disc's boundary: the nodes where it turns from one wall onto
     * another, then new nodes spread round it where those are fewer than four.
     *
     * @throws IllegalStateException when the cuts left a region that is not a disc
     * @return this, with {@link #loopByDisc} and {@link #cornersByDisc} filled
     */
    public RingPatchNetwork corner() {
        HalfEdgeMesh copy = topology.copy;
        boolean refined = true;
        while (refined) {
            refined = false;
            loopByDisc = new ArrayList<>();
            List<List<int[]>> loopsByRegion = loops(flood());
            for (int disc = 0; !refined && disc < loopsByRegion.size(); disc++) {
                if (loopsByRegion.get(disc).isEmpty()) {
                    continue;
                }
                if (loopsByRegion.get(disc).size() != 1) {
                    int faces = 0;
                    for (int regionId : regionByFace) {
                        faces += regionId == disc ? 1 : 0;
                    }
                    throw new IllegalStateException("the cuts left a region of " + faces + " faces with "
                            + loopsByRegion.get(disc).size() + " boundary loops of " + loopsByRegion.get(disc)
                                    .stream().map(loop -> loop.length + " vertices, " + turns(loop).size() + " turns")
                                    .toList() + ", where every region should be a disc");
                }
                int[] loop = loopsByRegion.get(disc).get(0);
                loopByDisc.add(loop);
                int plain = 0;
                for (int vertex : loop) {
                    plain += nodeVertices.contains(vertex) ? 0 : 1;
                }
                // A boundary too short to hold four more corners has every edge halved.
                refined = plain < EmbeddedPatch.SIDES && turns(loop).size() < EmbeddedPatch.SIDES;
                for (int place = 0; refined && place < loop.length; place++) {
                    int onto = loop[(place + 1) % loop.length];
                    int[] rings = ringsByEdge.remove(copy.edgeBetween(loop[place], onto));
                    int halfway = topology.splitEdgeAtMidpoint(copy.edgeBetween(loop[place], onto));
                    ringsByEdge.put(copy.edgeBetween(loop[place], halfway), rings);
                    ringsByEdge.put(copy.edgeBetween(halfway, onto), rings);
                }
            }
        }
        for (int[] loop : loopByDisc) {
            int count = loop.length;
            double[] along = new double[count + 1];
            for (int place = 0; place < count; place++) {
                along[place + 1] = along[place] + copy.edgeLength(copy.edgeBetween(loop[place],
                        loop[(place + 1) % count]));
            }
            List<Integer> turns = turns(loop);
            double round = along[count];
            int[] corners = new int[EmbeddedPatch.SIDES];
            if (turns.size() >= EmbeddedPatch.SIDES) {
                // The four turns whose shortest side is longest.
                int tried = Math.min(turns.size(), CANDIDATES_TRIED);
                double best = -1;
                for (int pick = 0; pick < 1 << tried; pick++) {
                    if (Integer.bitCount(pick) != EmbeddedPatch.SIDES) {
                        continue;
                    }
                    int[] picked = new int[EmbeddedPatch.SIDES];
                    for (int index = 0, next = 0; index < tried; index++) {
                        if ((pick >> index & 1) == 1) {
                            picked[next++] = turns.get(index * turns.size() / tried);
                        }
                    }
                    double shortest = round - along[picked[EmbeddedPatch.SIDES - 1]] + along[picked[0]];
                    for (int side = 1; side < EmbeddedPatch.SIDES; side++) {
                        shortest = Math.min(shortest, along[picked[side]] - along[picked[side - 1]]);
                    }
                    if (shortest > best) {
                        best = shortest;
                        corners = picked;
                    }
                }
            } else {
                List<Integer> chosen = new ArrayList<>(turns);
                while (chosen.size() < EmbeddedPatch.SIDES) {
                    int furthest = 0;
                    double bestScore = -1;
                    for (int place = 0; place < count; place++) {
                        double nearest = chosen.isEmpty() ? 1 : round;
                        for (int corner : chosen) {
                            double apart = Math.abs(along[place] - along[corner]);
                            nearest = Math.min(nearest, Math.min(apart, round - apart));
                        }
                        // A corner another disc already stood on the wall is as good as a plain
                        // vertex; a node where a wall arrives from outside is a last resort.
                        double score = nearest * (nodeVertices.contains(loop[place]) && wallDegree(loop[place]) > 2
                                ? NODE_RELUCTANCE : 1);
                        if (score > bestScore) {
                            bestScore = score;
                            furthest = place;
                        }
                    }
                    chosen.add(furthest);
                    addedCorners++;
                }
                corners = chosen.stream().mapToInt(Integer::intValue).sorted().toArray();
            }
            for (int corner : corners) {
                nodeVertices.add(loop[corner]);
            }
            cornersByDisc.add(corners);
        }
        return this;
    }

    /**
     * Lays the T-mesh: a node on every node vertex, an arc along every stretch of wall or cut
     * between two nodes, and a four-sided patch for every disc.
     *
     * @return this, with {@link #network} built and every arc one unit long
     */
    public RingPatchNetwork lay() {
        HalfEdgeMesh copy = topology.copy;
        network = new ArcNetwork(topology);
        Map<Integer, Integer> nodeByVertex = new HashMap<>();
        for (int vertex : nodeVertices) {
            nodeByVertex.put(vertex, network.addNode(ArcNetwork.NONE, vertex, false, false));
        }
        Map<Integer, Integer> arcByEdge = new HashMap<>();
        for (int disc = 0; disc < loopByDisc.size(); disc++) {
            int[] loop = loopByDisc.get(disc);
            int[] corners = cornersByDisc.get(disc);
            List<List<Integer>> sides = new ArrayList<>();
            for (int side = 0; side < EmbeddedPatch.SIDES; side++) {
                List<Integer> arcs = new ArrayList<>();
                sides.add(arcs);
                int place = corners[side];
                while (arcs.isEmpty() || place != corners[(side + 1) % EmbeddedPatch.SIDES]) {
                    // One arc: the boundary from this node to the next.
                    List<Integer> path = new ArrayList<>(List.of(loop[place]));
                    List<Integer> edges = new ArrayList<>();
                    int[] rings = new int[0];
                    do {
                        place = (place + 1) % loop.length;
                        edges.add(copy.edgeBetween(path.get(path.size() - 1), loop[place]));
                        rings = IntStream.concat(Arrays.stream(rings), Arrays.stream(ringsByEdge.get(edges.get(
                                edges.size() - 1)))).filter(ring -> ring >= 0).distinct().toArray();
                        path.add(loop[place]);
                    } while (!nodeVertices.contains(loop[place]));
                    Integer arc = arcByEdge.get(edges.get(0));
                    if (arc == null) {
                        arc = network.addArc(rings.length == 0 ? ArcNetwork.NONE : ringsByWall.size(),
                                nodeByVertex.get(path.get(0)), nodeByVertex.get(path.get(path.size() - 1)), 1, false,
                                path);
                        ringsByWall.addAll(rings.length == 0 ? List.of() : List.of(rings));
                        for (int edgeId : edges) {
                            arcByEdge.put(edgeId, arc);
                        }
                    }
                    arcs.add(arc);
                }
            }
            network.addPatch(ArcNetwork.NONE, sides, nodeByVertex.get(loop[corners[0]]));
        }
        return this;
    }

    /**
     * Gives every arc the smallest whole length, at least one, that leaves the opposite sides
     * of every patch equally long, which the conforming needs.
     *
     * @throws IllegalStateException when no such lengths exist
     * @return this, the lengths written into the arcs
     */
    public RingPatchNetwork size() {
        double[] weights = new double[network.arcs.size()];
        Arrays.fill(weights, 1);
        IntegerProgram program = new IntegerProgram(weights);
        for (EmbeddedPatch patch : network.patches) {
            for (int side = 0; side < 2; side++) {
                program.equalityLeftSides.add(patch.sideArcIds.get(side).stream().mapToInt(Integer::intValue)
                        .sorted().toArray());
                program.equalityRightSides.add(patch.sideArcIds.get(side + 2).stream().mapToInt(Integer::intValue)
                        .sorted().toArray());
            }
        }
        for (EmbeddedArc arc : network.arcs) {
            program.coverRows.add(new int[] { arc.arcId });
        }
        if (!program.solve().feasible) {
            throw new IllegalStateException("no whole arc lengths leave the opposite sides of all "
                    + network.patches.size() + " patches equal");
        }
        for (EmbeddedArc arc : network.arcs) {
            arc.quantizedLength = program.values[arc.arcId];
        }
        return this;
    }

    /**
     * Runs the layout's conforming: every node standing inside a patch's side is extended across
     * the patch, so each side is left one arc.
     *
     * @return this, its network conforming
     */
    public RingPatchNetwork conform() {
        network.labelPatchCovers();
        NetworkContraction contraction = new NetworkContraction(network);
        contraction.extendTJunction.extendDegreeTwo = true;
        contraction.conform();
        extensionCount = contraction.extendTJunction.extensionCount;
        return this;
    }

    /**
     * Which arcs of the network are stretches of a ring, which a cut or an extension is not.
     *
     * @return a flag per arc id
     */
    public boolean[] ringArcs() {
        boolean[] rings = new boolean[network.arcs.size()];
        for (EmbeddedArc arc : network.arcs) {
            rings[arc.arcId] = arc.alive && arc.sourceArcId != ArcNetwork.NONE;
        }
        return rings;
    }

    /**
     * One line saying what was built.
     *
     * @return the counts of discs, cuts, corners, nodes, patches and extensions
     */
    public String report() {
        int patches = 0;
        for (EmbeddedPatch patch : network == null ? List.<EmbeddedPatch>of() : network.patches) {
            patches += patch.alive ? 1 : 0;
        }
        return String.format(Locale.ROOT, "ring network: %d discs, %d cuts, %d corners added, %d wall edges "
                + "left out; %d nodes, %d patches, %d extensions", loopByDisc.size(), cutCount, addedCorners,
                ringsByDroppedEdge.size(), nodeVertices.size(), patches, extensionCount);
    }

    /**
     * The region of every face of the copy: the faces reached without crossing a wall edge.
     *
     * @return region by face id, also kept for the cuts to read
     */
    private int[] flood() {
        HalfEdgeMesh copy = topology.copy;
        regionByFace = new int[copy.faceIdBound()];
        Arrays.fill(regionByFace, MeshTopology.NONE);
        int[] stack = new int[copy.faceCount()];
        regionCount = 0;
        for (int active = 0; active < copy.faceCount(); active++) {
            if (regionByFace[copy.faceIdAt(active)] != MeshTopology.NONE) {
                continue;
            }
            int top = 0;
            stack[top++] = copy.faceIdAt(active);
            regionByFace[copy.faceIdAt(active)] = regionCount;
            while (top > 0) {
                int halfEdge = copy.faceHalfEdge(stack[--top]);
                for (int corner = 0; corner < HalfEdgeMesh.TRIANGLE_CORNERS; corner++) {
                    int across = copy.halfEdgeFace(copy.halfEdgeTwin(halfEdge));
                    if (across != MeshTopology.NONE && regionByFace[across] == MeshTopology.NONE
                            && !ringsByEdge.containsKey(copy.halfEdgeEdge(halfEdge))) {
                        regionByFace[across] = regionCount;
                        stack[top++] = across;
                    }
                    halfEdge = copy.halfEdgeNext(halfEdge);
                }
            }
            regionCount++;
        }
        return regionByFace;
    }

    /**
     * The boundary loops of every region, each walked along wall edges with the region on the
     * left.
     *
     * @param region region by face id
     * @return the loops of each region, as the copy vertices round them
     */
    private List<List<int[]>> loops(int[] region) {
        HalfEdgeMesh copy = topology.copy;
        List<List<int[]>> loopsByRegion = new ArrayList<>();
        for (int regionId = 0; regionId < regionCount; regionId++) {
            loopsByRegion.add(new ArrayList<>());
        }
        BitSet walked = new BitSet();
        for (int edgeId : ringsByEdge.keySet()) {
            for (int flank = 0; flank < 2; flank++) {
                int first = flank == 0 ? copy.edgeHalfEdge(edgeId) : copy.halfEdgeTwin(copy.edgeHalfEdge(edgeId));
                if (walked.get(first)) {
                    continue;
                }
                List<Integer> loop = new ArrayList<>();
                int at = first;
                do {
                    walked.set(at);
                    loop.add(copy.halfEdgeVertex(at));
                    // Round the head vertex inside the region to the next wall edge.
                    at = copy.halfEdgeNext(at);
                    while (!ringsByEdge.containsKey(copy.halfEdgeEdge(at))) {
                        at = copy.halfEdgeNext(copy.halfEdgeTwin(at));
                    }
                } while (at != first);
                loopsByRegion.get(region[copy.halfEdgeFace(first)]).add(loop.stream().mapToInt(Integer::intValue)
                        .toArray());
            }
        }
        return loopsByRegion;
    }

    /**
     * The places where a boundary loop turns: its nodes whose edge before and edge after carry
     * no ring or cut in common.
     *
     * @param loop boundary loop, as copy vertices
     * @return the places, ascending
     */
    private List<Integer> turns(int[] loop) {
        HalfEdgeMesh copy = topology.copy;
        List<Integer> turns = new ArrayList<>();
        for (int place = 0; place < loop.length; place++) {
            boolean straight = false;
            for (int before : ringsByEdge.get(copy.edgeBetween(loop[(place + loop.length - 1) % loop.length],
                    loop[place]))) {
                for (int after : ringsByEdge.get(copy.edgeBetween(loop[place], loop[(place + 1) % loop.length]))) {
                    straight |= before == after;
                }
            }
            if (!straight && nodeVertices.contains(loop[place])) {
                turns.add(place);
            }
        }
        return turns;
    }

    /**
     * The place nearest the middle of a stretch of a loop, by length, strictly between its ends.
     *
     * @param loop boundary loop, as copy vertices
     * @param from place the stretch starts at
     * @param onto place it ends at, walking forwards
     * @return the place, or {@link MeshTopology#NONE} when the stretch is one edge
     */
    private int middle(int[] loop, int from, int onto) {
        int steps = (onto - from + loop.length - 1) % loop.length + 1;
        double[] along = new double[steps + 1];
        for (int step = 0; step < steps; step++) {
            along[step + 1] = along[step] + topology.copy.edgeLength(topology.copy.edgeBetween(
                    loop[(from + step) % loop.length], loop[(from + step + 1) % loop.length]));
        }
        int nearest = MeshTopology.NONE;
        for (int step = 1; step < steps; step++) {
            if (nearest == MeshTopology.NONE || Math.abs(along[step] - along[steps] / 2) < Math.abs(
                    along[(nearest - from + loop.length) % loop.length] - along[steps] / 2)) {
                nearest = (from + step) % loop.length;
            }
        }
        return nearest;
    }

    /**
     * The vertex of a disc furthest inside it, counted in edges from its boundary.
     *
     * @param regionId the disc
     * @param loop     its boundary loop, as copy vertices
     * @param edges    how many edges the vertex must have at least
     * @param depth    how many edges from the boundary it must stand at least
     * @return the vertex, or {@link MeshTopology#NONE} when the disc holds none
     */
    private int innermost(int regionId, int[] loop, int edges, int depth) {
        HalfEdgeMesh copy = topology.copy;
        Map<Integer, Integer> depthByVertex = new HashMap<>();
        List<Integer> frontier = new ArrayList<>();
        for (int vertex : loop) {
            depthByVertex.put(vertex, 0);
            frontier.add(vertex);
        }
        int innermost = MeshTopology.NONE;
        for (int head = 0; head < frontier.size(); head++) {
            int at = frontier.get(head);
            if (depthByVertex.get(at) >= depth && copy.vertexEdgeCount(at) >= edges) {
                innermost = at;
            }
            for (int index = 0; index < copy.vertexEdgeCount(at); index++) {
                int edgeId = copy.vertexEdgeAt(at, index);
                int next = copy.edgeOtherVertex(edgeId, at);
                if (!ringsByEdge.containsKey(edgeId) && regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(
                        edgeId))] == regionId && wallDegree(next) == 0
                        && depthByVertex.putIfAbsent(next, depthByVertex.get(at) + 1) == null) {
                    frontier.add(next);
                }
            }
        }
        return innermost;
    }

    /**
     * The shortest way along edges inside one region between two sets of its boundary vertices,
     * touching no wall or cut in between.
     *
     * @param regionId region to stay inside
     * @param sources  vertices the way may start at
     * @param targets  vertices it may end at
     * @return the vertices from the target reached back to its source, empty when none is reached
     */
    private List<Integer> route(int regionId, List<Integer> sources, Set<Integer> targets) {
        HalfEdgeMesh copy = topology.copy;
        if (distance.length < copy.vertexIdBound()) {
            distance = new double[2 * copy.vertexIdBound()];
            cameFrom = new int[2 * copy.vertexIdBound()];
            Arrays.fill(distance, Double.POSITIVE_INFINITY);
        }
        List<Integer> touched = new ArrayList<>(sources);
        PriorityQueue<double[]> queue = new PriorityQueue<>((first, second) -> Double.compare(first[0], second[0]));
        for (int source : sources) {
            distance[source] = 0;
            cameFrom[source] = MeshTopology.NONE;
            queue.add(new double[] { 0, source });
        }
        List<Integer> path = new ArrayList<>();
        while (!queue.isEmpty() && path.isEmpty()) {
            double[] head = queue.poll();
            int at = (int) head[1];
            if (head[0] > distance[at]) {
                continue;
            }
            if (targets.contains(at)) {
                // Read back from the end to the source, which no step leads to.
                path.add(at);
                for (int before = cameFrom[at]; before != MeshTopology.NONE; before = cameFrom[before]) {
                    path.add(before);
                }
                continue;
            }
            for (int index = 0; index < copy.vertexEdgeCount(at); index++) {
                int edgeId = copy.vertexEdgeAt(at, index);
                int next = copy.edgeOtherVertex(edgeId, at);
                if (ringsByEdge.containsKey(edgeId) || regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(
                        edgeId))] != regionId || wallDegree(next) > 0 && !targets.contains(next)) {
                    continue;
                }
                double through = head[0] + copy.edgeLength(edgeId);
                if (through < distance[next]) {
                    distance[next] = through;
                    cameFrom[next] = at;
                    touched.add(next);
                    queue.add(new double[] { through, next });
                }
            }
        }
        for (int vertex : touched) {
            distance[vertex] = Double.POSITIVE_INFINITY;
        }
        return path;
    }

    /**
     * Marks a way across a region as a cut of its own, a node at each end, and leaves room
     * beside it for later cuts.
     *
     * @param path the cut's vertices in order
     */
    private void cut(List<Integer> path) {
        int[] cut = { -++cutCount };
        for (int step = 1; step < path.size(); step++) {
            ringsByEdge.put(topology.copy.edgeBetween(path.get(step - 1), path.get(step)), cut);
        }
        nodeVertices.add(path.get(0));
        nodeVertices.add(path.get(path.size() - 1));
        for (int vertex : path) {
            relieve(vertex);
        }
    }

    /**
     * Halves every edge that joins a wall vertex to another wall vertex without being a wall, so
     * a later cut can pass between the two walls through the new vertex.
     *
     * @param vertex wall vertex whose edges are looked at
     */
    private void relieve(int vertex) {
        HalfEdgeMesh copy = topology.copy;
        List<Integer> across = new ArrayList<>();
        for (int index = 0; index < copy.vertexEdgeCount(vertex); index++) {
            int other = copy.edgeOtherVertex(copy.vertexEdgeAt(vertex, index), vertex);
            if (!ringsByEdge.containsKey(copy.vertexEdgeAt(vertex, index)) && wallDegree(other) > 0) {
                across.add(other);
            }
        }
        for (int other : across) {
            halve(copy.edgeBetween(vertex, other));
        }
    }

    /**
     * Halves an edge that is no wall and keeps the region of every face current.
     *
     * @param edgeId edge inside a region
     */
    private void halve(int edgeId) {
        HalfEdgeMesh copy = topology.copy;
        int regionId = regionByFace[copy.halfEdgeFace(copy.edgeHalfEdge(edgeId))];
        int halfway = topology.splitEdgeAtMidpoint(edgeId);
        if (regionByFace.length < copy.faceIdBound()) {
            regionByFace = Arrays.copyOf(regionByFace, 2 * copy.faceIdBound());
        }
        // The edge was no wall, so every face round the new vertex lies in its region.
        for (int index = 0; index < copy.vertexEdgeCount(halfway); index++) {
            int halfEdge = copy.edgeHalfEdge(copy.vertexEdgeAt(halfway, index));
            regionByFace[copy.halfEdgeFace(halfEdge)] = regionId;
            regionByFace[copy.halfEdgeFace(copy.halfEdgeTwin(halfEdge))] = regionId;
        }
    }

    /**
     * The places along a loop a new seam may stand on: plain wall vertices well away from the
     * region's other feet there, or failing those any vertex that is not such a foot.
     *
     * @param loop boundary loop, as copy vertices
     * @param feet places of the region's seams already standing on the loop
     * @return the places, never empty
     */
    private List<Integer> footPlaces(int[] loop, List<Integer> feet) {
        List<Integer> places = new ArrayList<>();
        for (int tier = 0; places.isEmpty(); tier++) {
            for (int place = 0; place < loop.length; place++) {
                int nearest = loop.length;
                for (int foot : feet) {
                    nearest = Math.min(nearest, Math.min(Math.abs(place - foot), loop.length - Math.abs(place - foot)));
                }
                boolean plain = !nodeVertices.contains(loop[place]) && wallDegree(loop[place]) == 2;
                if (tier == 0 ? plain && nearest >= FOOT_SPREAD * loop.length : nearest > 0 && (plain || tier > 1)) {
                    places.add(place);
                }
            }
        }
        return places;
    }

    /**
     * How many wall edges meet at a vertex of the copy.
     *
     * @param vertex copy vertex
     * @return the number of its edges that are walls or cuts
     */
    private int wallDegree(int vertex) {
        int degree = 0;
        for (int index = 0; index < topology.copy.vertexEdgeCount(vertex); index++) {
            degree += ringsByEdge.containsKey(topology.copy.vertexEdgeAt(vertex, index)) ? 1 : 0;
        }
        return degree;
    }
}
