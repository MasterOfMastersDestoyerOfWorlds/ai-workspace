package ixdar.geometry.mesh.data.rings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeSet;

import org.joml.Vector3f;

import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.numeric.sparse.matrix.NormalMatrix;
import ixdar.numeric.sparse.system.DofSystem;
import ixdar.numeric.sparse.system.NewtonRelaxation;

/**
 * Fits every ring and bisector of a segmentation to the grooves together: each wall is cut into
 * curves at the vertices it shares with other walls, and every curve point slides across its
 * curve to where the groove is deepest while the curve stays smooth.
 */
public final class RingCurveFit {

    // An active contour (Kass, Witkin, Terzopoulos, "Snakes: Active Contour Models", IJCV 1988)
    // with one unknown per curve point, its offset along the surface across the curve.

    public static final String SLOT = "_ring_curve_fit";

    // How far a curve point may slide either side of where it was drawn, in mean edge lengths.
    public static final double DEFAULT_BAND_EDGES = 8.0;

    // Weight of the groove depth under a curve point against the curve's smoothness.
    public static final double DEFAULT_PULL = 1.0;

    // Weight of the curve's smoothness: its offsets' first and second differences.
    public static final double DEFAULT_SMOOTHNESS = 1.0;

    // Widths the groove profiles are blurred by, in mean edge lengths, one relaxation each; the
    // last is the grooves as measured.
    public static final double[] BLUR_EDGES = { 4.0, 2.0, 1.0, 0.0 };

    // Weight holding each point where it was drawn, which also keeps a free loop's system definite.
    public static final double ANCHOR = 0.005;

    // Stiffness the groove term adds to the Hessian's diagonal, standing in for its curvature.
    public static final double DATA_STIFFNESS = 1.0;

    // A groove deeper than this many saturations pulls no harder.
    public static final double DEEPEST_GROOVE = 3.0;

    // Penalty per squared edge length a point slides past the end of its profile.
    public static final double PROFILE_WALL = 4.0;

    // A step across the curve must turn less than this far from straight across, as a cosine.
    public static final float ACROSS_COSINE = 0.3f;

    public static final int LONGEST_PROFILE_SIDE = 64;

    // Edges around a kept point that no curve slides onto.
    public static final int KEPT_REACH_EDGES = 3;

    // A slid point this share of an edge from a vertex stands on the vertex.
    public static final double VERTEX_SNAP = 0.1;

    // A path coming back to a vertex it passed this few steps ago made a spur or a small loop.
    public static final int SMALL_LOOP_STEPS = 16;

    // Curve points either side that a point's tangent is measured between.
    public static final int TANGENT_REACH = 2;

    public static final int NEWTON_ITERATIONS = 200;

    public static final long NEWTON_MILLISECONDS = 30_000;

    /** The regions as the rings were drawn. */
    public final RingRegions regions;

    /** Surface the rings lie on. */
    public final MeshTopology mesh;

    /** Mean edge length of the surface, the unit of every offset. */
    public double meanEdgeLength;

    /** Curves the walls were cut into. */
    public int curveCount;

    /** Curve points that moved to another vertex. */
    public int movedPoints;

    /** Newton iterations the last relaxation ran. */
    public int iterations;

    /** Energy before and after the last relaxation. */
    public final double[] energies = new double[2];

    /** Seconds the last relaxation took. */
    public double seconds;

    /** One offset per curve point, in mean edge lengths, the points at shared vertices frozen. */
    public final DofSystem system;

    /** Vertex each curve point was drawn on, the curves' points one curve after another. */
    public final int[] pointVertexId;

    /** First point of each curve, with one more entry closing the last. */
    public final int[] curveStart;

    /** Ring each curve is a stretch of. */
    public final int[] curveRing;

    /** Whether each curve is a loop with no end, rather than a stretch between two ends. */
    public final boolean[] curveClosed;

    /** Groove strength of the surface the curves are pulled into. */
    public final SurfaceCreases creases;


    private final int[] profileStart;
    private final double[] profileOffset;
    private final double[] profileGroove;
    private final int[] profileVertexId;
    private double[] grooveNow = new double[0];
    private double[] profilePeak = new double[0];
    private int[] profileFrom = new int[0];
    private int[] profileTo = new int[0];
    private long[] upperKeys = new long[0];
    private double pull;
    private double smoothness;
    private final double[] wallsFitted = new double[2];

    /**
     * Cuts every wall into curves and measures, for each curve point, the groove depth along the
     * surface line across the curve through it.
     *
     * @param regions   built regions of the rings to fit
     * @param creases   groove depth of the surface
     * @param bandEdges how far a point may slide either side, in mean edge lengths
     */
    public RingCurveFit(RingRegions regions, SurfaceCreases creases, double bandEdges) {
        this.regions = regions;
        this.creases = creases;
        mesh = regions.mesh;
        for (int edge = 0; edge < mesh.edgeCount(); edge++) {
            meanEdgeLength += mesh.edgeLength(mesh.edgeIdAt(edge)) / Math.max(1, mesh.edgeCount());
        }
        // A vertex two walls share is where curves end; a profile stops at a vertex on any wall
        // and where another wall is nearer than its own, so no two fitted walls cross.
        int[] nearestWall = regions.nearestWallByVertex();
        boolean[] onWall = new boolean[mesh.vertexIdBound()];
        boolean[] shared = new boolean[mesh.vertexIdBound()];
        for (int ring = 0; ring < regions.ringLabels.length; ring++) {
            for (int edgeId : regions.ringIsWall[ring] ? regions.ringEdgeIds[ring] : new int[0]) {
                int halfEdge = mesh.edgeHalfEdge(edgeId);
                for (int vertexId : new int[] { mesh.halfEdgeVertex(halfEdge), mesh.halfEdgeEndVertex(halfEdge) }) {
                    shared[vertexId] |= nearestWall[vertexId] != ring;
                    onWall[vertexId] = true;
                }
            }
        }
        List<Integer> points = new ArrayList<>();
        List<Integer> starts = new ArrayList<>();
        List<Integer> rings = new ArrayList<>();
        List<Boolean> closedCurves = new ArrayList<>();
        boolean[] open = new boolean[mesh.edgeIdBound()];
        for (int ring = 0; ring < regions.ringLabels.length; ring++) {
            int[] edgeIds = regions.ringIsWall[ring] ? regions.ringEdgeIds[ring] : new int[0];
            int[] degree = new int[edgeIds.length == 0 ? 0 : mesh.vertexIdBound()];
            for (int edgeId : edgeIds) {
                open[edgeId] = true;
                int halfEdge = mesh.edgeHalfEdge(edgeId);
                degree[mesh.halfEdgeVertex(halfEdge)]++;
                degree[mesh.halfEdgeEndVertex(halfEdge)]++;
            }
            // Curves between the vertices where the wall forks, ends or meets another, then loops.
            for (int closed = 0; closed < 2; closed++) {
                for (int from : edgeIds) {
                    int halfEdge = mesh.edgeHalfEdge(from);
                    for (int startId : new int[] { mesh.halfEdgeVertex(halfEdge), mesh.halfEdgeEndVertex(halfEdge) }) {
                        boolean breaks = degree[startId] != 2 || shared[startId];
                        for (int index = 0; (breaks || closed == 1) && index < mesh.vertexEdgeCount(startId);
                                index++) {
                            int edgeId = mesh.vertexEdgeAt(startId, index);
                            if (!open[edgeId]) {
                                continue;
                            }
                            starts.add(points.size());
                            rings.add(ring);
                            points.add(startId);
                            int at = startId;
                            while (edgeId != MeshTopology.NONE) {
                                open[edgeId] = false;
                                at = mesh.edgeOtherVertex(edgeId, at);
                                points.add(at);
                                edgeId = MeshTopology.NONE;
                                for (int onward = 0; degree[at] == 2 && !shared[at] && at != startId
                                        && onward < mesh.vertexEdgeCount(at); onward++) {
                                    int candidate = mesh.vertexEdgeAt(at, onward);
                                    edgeId = open[candidate] ? candidate : edgeId;
                                }
                            }
                            closedCurves.add(!breaks && at == startId);
                            if (!breaks && at == startId) {
                                points.remove(points.size() - 1);
                            }
                        }
                    }
                }
            }
        }
        curveCount = starts.size();
        starts.add(points.size());
        pointVertexId = points.stream().mapToInt(Integer::intValue).toArray();
        curveStart = starts.stream().mapToInt(Integer::intValue).toArray();
        curveRing = rings.stream().mapToInt(Integer::intValue).toArray();
        curveClosed = new boolean[curveCount];
        system = new DofSystem(pointVertexId.length);
        // Each point's profile: the vertices met walking straight across the curve either way,
        // up to the band or the next wall, with their offsets and groove depths.
        List<double[]> profile = new ArrayList<>();
        profileStart = new int[pointVertexId.length + 1];
        Vector3f here = new Vector3f();
        Vector3f there = new Vector3f();
        Vector3f normal = new Vector3f();
        Vector3f across = new Vector3f();
        Vector3f heading = new Vector3f();
        Vector3f step = new Vector3f();
        for (int curve = 0; curve < curveCount; curve++) {
            curveClosed[curve] = closedCurves.get(curve);
            int first = curveStart[curve];
            int count = curveStart[curve + 1] - first;
            for (int point = 0; point < count; point++) {
                int vertexId = pointVertexId[first + point];
                boolean end = !curveClosed[curve] && (point == 0 || point == count - 1);
                system.frozen[first + point] = end;
                int before = curveClosed[curve] ? Math.floorMod(point - TANGENT_REACH, count)
                        : Math.max(0, point - TANGENT_REACH);
                int after = curveClosed[curve] ? (point + TANGENT_REACH) % count
                        : Math.min(count - 1, point + TANGENT_REACH);
                mesh.vertexPosition(pointVertexId[first + after], there)
                        .sub(mesh.vertexPosition(pointVertexId[first + before], here));
                mesh.vertexNormal(vertexId, normal).cross(there, across);
                List<double[]> sides = new ArrayList<>();
                sides.add(new double[] { 0, vertexId });
                for (int side = -1; side <= 1 && !end && across.lengthSquared() > 0f; side += 2) {
                    heading.set(across).normalize().mul(side);
                    int at = vertexId;
                    double walked = 0;
                    for (int steps = 0; steps < LONGEST_PROFILE_SIDE; steps++) {
                        int next = MeshTopology.NONE;
                        float straightest = ACROSS_COSINE;
                        mesh.vertexPosition(at, here);
                        for (int index = 0; index < mesh.vertexEdgeCount(at); index++) {
                            int candidate = mesh.edgeOtherVertex(mesh.vertexEdgeAt(at, index), at);
                            mesh.vertexPosition(candidate, step).sub(here);
                            float cosine = step.lengthSquared() > 0f ? step.normalize().dot(heading) : 0f;
                            if (cosine > straightest) {
                                straightest = cosine;
                                next = candidate;
                            }
                        }
                        if (next == MeshTopology.NONE || onWall[next] || nearestWall[next] != curveRing[curve]) {
                            break;
                        }
                        walked += mesh.vertexPosition(next, there).distance(here);
                        if (walked > bandEdges * meanEdgeLength) {
                            break;
                        }
                        double[] entry = { side * walked / meanEdgeLength, next };
                        sides.add(side < 0 ? 0 : sides.size(), entry);
                        at = next;
                        // Back onto the surface; a heading that vanishes finds no next step.
                        heading.sub(step.set(mesh.vertexNormal(at, normal)).mul(heading.dot(normal))).normalize();
                    }
                }
                profile.addAll(sides);
                profileStart[first + point + 1] = profile.size();
            }
        }
        profileOffset = new double[profile.size()];
        profileGroove = new double[profile.size()];
        profileVertexId = new int[profile.size()];
        for (int entry = 0; entry < profile.size(); entry++) {
            profileOffset[entry] = profile.get(entry)[0];
            profileVertexId[entry] = (int) profile.get(entry)[1];
            profileGroove[entry] = Math.min(DEEPEST_GROOVE, Math.max(0.0, creases.valleyCurvature[profileVertexId[entry]])
                    / Math.max(creases.saturation, Double.MIN_NORMAL));
        }
    }

    /**
     * The groove depth under a curve point slid to an offset, or its slope there: linear between
     * the profile's vertices and falling off past its ends.
     *
     * @param point  curve point
     * @param offset offset across the curve, in mean edge lengths
     * @param slope  true for the derivative by the offset rather than the depth
     * @return the depth, at most {@link #DEEPEST_GROOVE}, or its slope
     */
    public double groove(int point, double offset, boolean slope) {
        int first = profileFrom[point];
        int last = profileTo[point];
        double past = offset < profileOffset[first] ? offset - profileOffset[first]
                : offset > profileOffset[last] ? offset - profileOffset[last] : 0.0;
        if (past != 0.0 || first == last) {
            return slope ? -2 * PROFILE_WALL * past
                    : grooveNow[past < 0 ? first : last] - PROFILE_WALL * past * past;
        }
        int upper = first + 1;
        while (profileOffset[upper] < offset) {
            upper++;
        }
        double span = profileOffset[upper] - profileOffset[upper - 1];
        double rise = (grooveNow[upper] - grooveNow[upper - 1]) / span;
        return slope ? rise : grooveNow[upper - 1] + rise * (offset - profileOffset[upper - 1]);
    }

    /**
     * Where a curve point stands after the relaxation: on the mesh edge between two neighbouring
     * vertices of its profile, or on one vertex when it is within {@link #VERTEX_SNAP} of it.
     *
     * @param point curve point
     * @param ends  receives the two vertex ids, equal when the point stands on a vertex
     * @return how far from the first vertex to the second the point stands, in [0, 1)
     */
    public double slidPoint(int point, int[] ends) {
        int upper = Math.min(profileFrom[point] + 1, profileTo[point]);
        while (upper < profileTo[point] && profileOffset[upper] < system.solution[point]) {
            upper++;
        }
        int lower = Math.max(profileFrom[point], upper - 1);
        double span = profileOffset[upper] - profileOffset[lower];
        double fraction = span > 0 ? Math.max(0, Math.min(1, (system.solution[point] - profileOffset[lower]) / span))
                : 0;
        ends[0] = profileVertexId[fraction > 1 - VERTEX_SNAP ? upper : lower];
        ends[1] = profileVertexId[fraction < VERTEX_SNAP ? lower : upper];
        return ends[0] == ends[1] ? 0 : fraction;
    }

    /**
     * The energy at some offsets: the groove depth every point misses, plus the curves' stretch
     * and bend and the hold on where each point was drawn.
     *
     * @param offsets one offset per curve point
     * @return the energy, never negative
     */
    public double energy(double[] offsets) {
        double energy = 0;
        for (int curve = 0; curve < curveCount; curve++) {
            int first = curveStart[curve];
            int count = curveStart[curve + 1] - first;
            for (int point = 0; point < count; point++) {
                int here = first + point;
                energy += pull * (profilePeak[here] - groove(here, offsets[here], false))
                        + ANCHOR * offsets[here] * offsets[here];
                if (!curveClosed[curve] && point == count - 1 || count < 2) {
                    continue;
                }
                int next = first + (point + 1) % count;
                energy += smoothness * (offsets[next] - offsets[here]) * (offsets[next] - offsets[here]);
                if (curveClosed[curve] ? count > 2 : point < count - 2) {
                    double bend = offsets[here] - 2 * offsets[next] + offsets[first + (point + 2) % count];
                    energy += smoothness * bend * bend;
                }
            }
        }
        return energy;
    }

    /**
     * The Newton system at some offsets, on the sparsity {@link #assemble} fixed: the Hessian of
     * the smoothness and hold terms, a constant stiffness for the groove term, and the negative
     * gradient.
     *
     * @param offsets       one offset per curve point
     * @param diagonal      receives the Hessian diagonal
     * @param upperValues   receives the strict-upper values
     * @param rightHandSide receives the negative gradient
     */
    public void assembleInto(double[] offsets, double[] diagonal, double[] upperValues, double[] rightHandSide) {
        for (int curve = 0; curve < curveCount; curve++) {
            int first = curveStart[curve];
            int count = curveStart[curve + 1] - first;
            for (int point = 0; point < count; point++) {
                int here = first + point;
                diagonal[here] += 2 * ANCHOR + pull * DATA_STIFFNESS;
                rightHandSide[here] += pull * groove(here, offsets[here], true) - 2 * ANCHOR * offsets[here];
                if (!curveClosed[curve] && point == count - 1 || count < 2) {
                    continue;
                }
                int next = first + (point + 1) % count;
                double stretch = 2 * smoothness * (offsets[next] - offsets[here]);
                rightHandSide[here] += stretch;
                rightHandSide[next] -= stretch;
                diagonal[here] += 2 * smoothness;
                diagonal[next] += 2 * smoothness;
                long pair = (long) Math.min(here, next) << NormalMatrix.KEY_ROW_SHIFT | Math.max(here, next);
                upperValues[Arrays.binarySearch(upperKeys, pair)] -= 2 * smoothness;
                if (curveClosed[curve] ? count > 2 : point < count - 2) {
                    int last = first + (point + 2) % count;
                    double bend = 2 * smoothness * (offsets[here] - 2 * offsets[next] + offsets[last]);
                    rightHandSide[here] -= bend;
                    rightHandSide[next] += 2 * bend;
                    rightHandSide[last] -= bend;
                    diagonal[here] += 2 * smoothness;
                    diagonal[next] += 8 * smoothness;
                    diagonal[last] += 2 * smoothness;
                    upperValues[Arrays.binarySearch(upperKeys, pair)] -= 4 * smoothness;
                    upperValues[Arrays.binarySearch(upperKeys, (long) Math.min(next, last)
                            << NormalMatrix.KEY_ROW_SHIFT | Math.max(next, last))] -= 4 * smoothness;
                    upperValues[Arrays.binarySearch(upperKeys, (long) Math.min(here, last)
                            << NormalMatrix.KEY_ROW_SHIFT | Math.max(here, last))] += 2 * smoothness;
                }
            }
        }
    }

    /**
     * Fill {@link #system}: the weights, the fixed sparsity of the curves' neighbours, the energy
     * and the Newton relaxation as its solve, every offset starting at zero.
     *
     * @param grooveWeight weight of the groove depth under a point
     * @param curveWeight  weight of the curves' smoothness
     * @param kept         surface points, packed xyz, no curve may slide across: the points of
     *                     the part labels, so every name keeps its region
     */
    public void assemble(double grooveWeight, double curveWeight, List<float[]> kept) {
        pull = grooveWeight;
        smoothness = curveWeight;
        // A point's profile ends where it comes within a few edges of a kept point.
        profileFrom = new int[pointVertexId.length];
        profileTo = new int[pointVertexId.length];
        boolean[] held = new boolean[mesh.vertexIdBound()];
        List<Integer> heldVertices = new ArrayList<>();
        for (float[] xyz : kept) {
            for (int point = 0; point + 2 < xyz.length; point += 3) {
                int faceId = mesh.faceIdAt(regions.nearestActiveFace(xyz[point], xyz[point + 1], xyz[point + 2]));
                for (int corner = 0; corner < mesh.faceVertexCount(faceId); corner++) {
                    heldVertices.add(mesh.faceVertexAt(faceId, corner));
                }
            }
        }
        for (int grown = 0, head = 0; grown <= KEPT_REACH_EDGES; grown++) {
            for (int end = heldVertices.size(); head < end; head++) {
                int vertexId = heldVertices.get(head);
                for (int index = 0; !held[vertexId] && index < mesh.vertexEdgeCount(vertexId); index++) {
                    heldVertices.add(mesh.edgeOtherVertex(mesh.vertexEdgeAt(vertexId, index), vertexId));
                }
                held[vertexId] = true;
            }
        }
        for (int point = 0; point < pointVertexId.length; point++) {
            int drawn = profileStart[point];
            while (profileOffset[drawn] < 0) {
                drawn++;
            }
            profileFrom[point] = drawn;
            while (profileFrom[point] > profileStart[point] && !held[profileVertexId[profileFrom[point] - 1]]) {
                profileFrom[point]--;
            }
            profileTo[point] = drawn;
            while (profileTo[point] < profileStart[point + 1] - 1 && !held[profileVertexId[profileTo[point] + 1]]) {
                profileTo[point]++;
            }
        }
        TreeSet<Long> keys = new TreeSet<>();
        for (int curve = 0; curve < curveCount; curve++) {
            int first = curveStart[curve];
            int count = curveStart[curve + 1] - first;
            for (int point = 0; point < count; point++) {
                for (int reach = 1; reach <= 2; reach++) {
                    int other = curveClosed[curve] ? first + (point + reach) % count : first + point + reach;
                    if (other != first + point && other < first + count) {
                        keys.add((long) Math.min(first + point, other) << NormalMatrix.KEY_ROW_SHIFT
                                | Math.max(first + point, other));
                    }
                }
            }
        }
        upperKeys = keys.stream().mapToLong(Long::longValue).toArray();
        // The deepest groove each point can reach: what it misses is measured against that, so
        // the energy falls to nothing as the curves find their grooves.
        profilePeak = new double[pointVertexId.length];
        for (int point = 0; point < profilePeak.length; point++) {
            for (int entry = profileFrom[point]; entry <= profileTo[point]; entry++) {
                profilePeak[point] = Math.max(profilePeak[point], profileGroove[entry]);
            }
        }
        Arrays.fill(system.solution, 0.0);
        grooveNow = profileGroove;
        system.energy = this::energy;
        // The solve: damped Newton over every curve's offsets at once, the quad layout's strategy,
        // coarse to fine: the grooves blurred wide first, so a curve feels one several edges
        // away, then sharpened under the curves as they stand.
        system.solve = () -> {
            long started = System.nanoTime();
            energies[0] = energy(system.solution);
            iterations = 0;
            for (double blur : BLUR_EDGES) {
                grooveNow = blur > 0 ? new double[profileGroove.length] : profileGroove;
                for (int point = 0; blur > 0 && point < pointVertexId.length; point++) {
                    for (int entry = profileFrom[point]; entry <= profileTo[point]; entry++) {
                        double weights = 0;
                        for (int other = profileFrom[point]; other <= profileTo[point]; other++) {
                            double apart = (profileOffset[other] - profileOffset[entry]) / blur;
                            double weight = Math.exp(-apart * apart / 2);
                            weights += weight;
                            grooveNow[entry] += weight * profileGroove[other];
                        }
                        grooveNow[entry] /= weights;
                    }
                }
                NewtonRelaxation newton = new NewtonRelaxation(system, this::assembleInto, upperKeys, null);
                newton.maxIterations = NEWTON_ITERATIONS;
                newton.timeBudgetMilliseconds = NEWTON_MILLISECONDS;
                newton.logIterations = false;
                newton.run();
                iterations += newton.iterationCount;
                energies[1] = newton.energyAfter;
            }
            seconds = (System.nanoTime() - started) / 1e9;
        };
    }

    /**
     * The fitted walls as one edge mask per ring: each curve through the vertices its points
     * slid to, joined along the cheapest crease paths.
     *
     * @return masks by edge id, parallel to the regions' ring labels; a ring that walled nothing
     *         keeps its mask
     */
    public boolean[][] marks() {
        boolean[][] masks = new boolean[regions.ringLabels.length][];
        for (int ring = 0; ring < masks.length; ring++) {
            masks[ring] = regions.ringIsWall[ring] ? new boolean[mesh.edgeIdBound()]
                    : regions.ringMarksByEdgeId[ring];
        }
        int[] slid = new int[pointVertexId.length];
        movedPoints = 0;
        for (int point = 0; point < slid.length; point++) {
            int nearest = profileFrom[point];
            for (int entry = nearest; entry <= profileTo[point]; entry++) {
                nearest = Math.abs(profileOffset[entry] - system.solution[point])
                        < Math.abs(profileOffset[nearest] - system.solution[point]) ? entry : nearest;
            }
            slid[point] = profileVertexId[nearest];
            movedPoints += slid[point] == pointVertexId[point] ? 0 : 1;
        }
        Arrays.fill(wallsFitted, 0.0);
        for (int curve = 0; curve < curveCount; curve++) {
            int first = curveStart[curve];
            int count = curveStart[curve + 1] - first;
            // The curve's path over the surface, vertex by vertex, and where each vertex sits in it.
            List<Integer> pathVertices = new ArrayList<>(List.of(slid[first]));
            List<Integer> pathEdges = new ArrayList<>();
            Map<Integer, Integer> placeInPath = new HashMap<>(Map.of(slid[first], 0));
            int segments = curveClosed[curve] ? count : count - 1;
            for (int point = 0; point < segments; point++) {
                int from = slid[first + point];
                int goal = slid[first + (point + 1) % count];
                // The shortest edge path between the two vertices, by Dijkstra from the far one;
                // the queue holds a cost's float bits above its vertex, which order as costs do.
                Map<Integer, Integer> edgeInto = new HashMap<>();
                Map<Integer, Float> cost = new HashMap<>(Map.of(goal, 0f));
                PriorityQueue<Long> open = new PriorityQueue<>(List.of((long) goal));
                while (!open.isEmpty() && from != goal) {
                    long entry = open.poll();
                    int at = (int) entry;
                    if (at == from) {
                        break;
                    }
                    if (Float.intBitsToFloat((int) (entry >>> Integer.SIZE)) > cost.get(at)) {
                        continue;
                    }
                    for (int index = 0; index < mesh.vertexEdgeCount(at); index++) {
                        int edgeId = mesh.vertexEdgeAt(at, index);
                        int next = mesh.edgeOtherVertex(edgeId, at);
                        float reached = (float) (cost.get(at) + mesh.edgeLength(edgeId));
                        if (reached < cost.getOrDefault(next, Float.POSITIVE_INFINITY)) {
                            cost.put(next, reached);
                            edgeInto.put(next, edgeId);
                            open.add((long) Float.floatToIntBits(reached) << Integer.SIZE | next);
                        }
                    }
                }
                // A path that comes back to a vertex it passed made a spur or a loop there, which
                // is cut off; a closed curve's last step returns to its first vertex.
                for (int at = from; at != goal && edgeInto.containsKey(at);) {
                    int edgeId = edgeInto.get(at);
                    at = mesh.edgeOtherVertex(edgeId, at);
                    Integer place = placeInPath.get(at);
                    boolean small = place != null && pathVertices.size() - place <= SMALL_LOOP_STEPS
                            && !(curveClosed[curve] && point == segments - 1 && at == goal);
                    while (small && pathVertices.size() > place + 1) {
                        placeInPath.remove(pathVertices.remove(pathVertices.size() - 1));
                        pathEdges.remove(pathEdges.size() - 1);
                    }
                    if (!small) {
                        placeInPath.put(at, pathVertices.size());
                        pathVertices.add(at);
                        pathEdges.add(edgeId);
                    }
                }
            }
            for (int edgeId : pathEdges) {
                masks[curveRing[curve]][edgeId] = true;
            }
        }
        for (int ring = 0; ring < masks.length; ring++) {
            for (int edgeId = 0; regions.ringIsWall[ring] && edgeId < masks[ring].length; edgeId++) {
                if (masks[ring][edgeId]) {
                    int halfEdge = mesh.edgeHalfEdge(edgeId);
                    wallsFitted[0] += mesh.edgeLength(edgeId);
                    wallsFitted[1] += mesh.edgeLength(edgeId) * (creases.valleyCurvature[mesh.halfEdgeVertex(halfEdge)]
                            + creases.valleyCurvature[mesh.halfEdgeEndVertex(halfEdge)])
                            / (2 * Math.max(creases.saturation, Double.MIN_NORMAL));
                }
            }
        }
        return masks;
    }

    /**
     * One line saying what the last relaxation and {@link #marks} did.
     *
     * @return the curve and point counts, the iterations and energies, the walls and the time
     */
    public String report() {
        double[] wallsDrawn = new double[2];
        for (int ring = 0; ring < regions.ringLabels.length; ring++) {
            for (int edgeId : regions.ringIsWall[ring] ? regions.ringEdgeIds[ring] : new int[0]) {
                int halfEdge = mesh.edgeHalfEdge(edgeId);
                wallsDrawn[0] += mesh.edgeLength(edgeId);
                wallsDrawn[1] += mesh.edgeLength(edgeId) * (creases.valleyCurvature[mesh.halfEdgeVertex(halfEdge)]
                        + creases.valleyCurvature[mesh.halfEdgeEndVertex(halfEdge)])
                        / (2 * Math.max(creases.saturation, Double.MIN_NORMAL));
            }
        }
        return String.format(Locale.ROOT, "fitted %d rings as %d curves of %d points: %d points moved, "
                + "%d Newton iterations, energy %.1f -> %.1f; walls %.2f long at mean groove depth %.3f as "
                + "drawn, %.2f long at %.3f fitted; %.1f s", regions.ringLabels.length, curveCount,
                pointVertexId.length, movedPoints, iterations, energies[0], energies[1], wallsDrawn[0],
                wallsDrawn[1] / Math.max(wallsDrawn[0], Double.MIN_NORMAL), wallsFitted[0],
                wallsFitted[1] / Math.max(wallsFitted[0], Double.MIN_NORMAL), seconds);
    }
}
