package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.labels.MeshLabels;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.HalfEdgeMesh;
import ixdar.geometry.mesh.data.rings.RingCurveFit;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.quadlayout.embedding.RingNetworkCarve;
import ixdar.geometry.mesh.quadlayout.embedding.RingPatchNetwork;
import ixdar.geometry.mesh.quadlayout.gridmap.FlattenedFaceUv;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The first stage of fit_rings: turns a surface's rings and bisectors into a quad layout's arc
 * network of four-sided patches, where they were drawn.
 */
@MeshNodeAnnotation(id = RingNetworkNode.NODE_ID, category = NodeCategory.SELECTION)
public class RingNetworkNode implements MeshNode {

    public static final String NODE_ID = "ring_network";

    public static final double DEFAULT_CELL_EDGES = 8.0;

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort CREASES = SplineRingNode.CREASES;
    public static final InputPort LABELS = new InputPort("labels", PortType.STRING, "");
    public static final InputPort CELL = new InputPort("cell", PortType.FLOAT, (float) DEFAULT_CELL_EDGES,
            1f, 1000f);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort TMESH = new OutputPort("tmesh", PortType.ARC_NETWORK);
    public static final OutputPort UV = new OutputPort("uv", PortType.UV_FIELD);
    public static final OutputPort EDGE_LENGTH = new OutputPort("edge_length", PortType.FLOAT);
    public static final OutputPort REPORT = new OutputPort("report", PortType.STRING);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CREASES, LABELS, CELL);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, TMESH, UV, EDGE_LENGTH, REPORT);
    }

    @Override
    public String description() {
        return "Turns a surface's rings and bisectors into the arc network a quad layout relaxes, "
                + "without moving them. The walls are carved into a working copy of the surface. "
                + "A region with several boundary loops is cut into discs by seams from loop to "
                + "loop; a disc whose boundary does not turn four times is cut further, by a "
                + "small loop round its middle or by spokes to it, so that the corners a patch "
                + "must have stand on those cuts and not on a ring. Every disc is then a "
                + "four-sided patch, the arcs take whole lengths, and the layout's conforming "
                + "runs each wall that ends on another across the patch it ends against.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying ring edge marks, after the last spline_ring, "
                        + "spline_cut and add_label statement. Output: the same bundle with the "
                        + "network in the " + RingPatchNetwork.SLOT + " slot for the later stages.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "here when not wired.",
                LABELS.name,
                "Comma-separated edge-mark labels to take as walls. Empty takes every boolean "
                        + "edge-mark label on the bundle, which after the ring nodes is every ring.",
                CELL.name,
                "Size of one grid cell of the patches' charts, in mean edge lengths.",
                TMESH.name,
                "The conforming arc network over the working copy: nodes, arcs and patches.",
                UV.name,
                "The surface itself as the reference the patches' maps are measured against: "
                        + "every triangle laid flat.",
                EDGE_LENGTH.name,
                "The cell size as a length on the surface, what grid_map_assembly takes as "
                        + "target_edge_length.",
                REPORT.name,
                "What the carve and the patching did: nodes, arcs, cuts, corners, patches and "
                        + "extensions.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (bundle == null || !(bundle.mesh() instanceof HalfEdgeMesh mesh) || mesh.faceCount() == 0) {
            ctx.setOutput(GEOMETRY.name, bundle == null ? GeometryBundle.empty() : bundle);
            ctx.setOutput(TMESH.name, null);
            ctx.setOutput(UV.name, null);
            ctx.setOutput(EDGE_LENGTH.name, 0f);
            ctx.setOutput(REPORT.name, "");
            return;
        }
        long started = System.nanoTime();
        SurfaceCreases creases = ctx.getInput(CREASES.name, SurfaceCreases.class);
        // The curve fit is only assembled, never relaxed: it cuts the walls into the curves the
        // carve lays, where they were drawn.
        RingCurveFit curves = new RingCurveFit(
                RingRegions.ofBundle(bundle, ctx.getInput(LABELS.name, String.class)),
                creases == null ? SurfaceCreases.of(mesh) : creases, RingCurveFit.DEFAULT_BAND_EDGES);
        curves.assemble(0, 0, MeshLabels.inBundle(bundle).pointsByLabel);
        RingNetworkCarve carve = new RingNetworkCarve(curves);
        carve.build();
        RingPatchNetwork rings = new RingPatchNetwork(carve);
        do {
            rings.seam();
        } while (rings.handle() | rings.pad() | rings.chord() | rings.star());
        rings.corner().lay().size().conform();
        double cell = ctx.getInputValue(CELL.name) instanceof Number edges ? edges.doubleValue()
                : DEFAULT_CELL_EDGES;
        ctx.setOutput(GEOMETRY.name, bundle.withSlot(RingPatchNetwork.SLOT, rings));
        ctx.setOutput(TMESH.name, rings.network);
        ctx.setOutput(UV.name, new FlattenedFaceUv(mesh));
        ctx.setOutput(EDGE_LENGTH.name, (float) (cell * curves.meanEdgeLength));
        ctx.setOutput(REPORT.name, String.format(Locale.ROOT, "%s; %s; %.1f s", carve.report(), rings.report(),
                (System.nanoTime() - started) / 1e9));
    }
}
