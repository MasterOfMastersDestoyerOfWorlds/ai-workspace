package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.labels.MeshLabels;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.RingRegions;
import ixdar.geometry.mesh.data.rings.RingSettle;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * The assembly stage of settle_rings: pins each ring region's middle and builds the DOF system
 * whose relaxation gives every free face beside a wall to a region, grooves insulating.
 */
@MeshNodeAnnotation(id = RingMembershipNode.NODE_ID, category = NodeCategory.SELECTION)
public class RingMembershipNode implements MeshNode {

    public static final String NODE_ID = "ring_membership";

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE,
            null);
    public static final InputPort CREASES = SplineRingNode.CREASES;
    public static final InputPort LABELS = new InputPort("labels", PortType.STRING, "");
    public static final InputPort BAND = new InputPort("band", PortType.FLOAT,
            (float) RingSettle.DEFAULT_BAND_EDGES, 0f, 1000f);
    public static final InputPort INSULATION = new InputPort("insulation", PortType.FLOAT,
            (float) RingSettle.DEFAULT_INSULATION, 0f, 50f);
    public static final InputPort THIN = new InputPort("thin", PortType.FLOAT,
            (float) RingSettle.DEFAULT_THIN_EDGES, 0f, 1000f);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name,
            PortType.GEOMETRY_BUNDLE);
    public static final OutputPort DOFS = new OutputPort("dofs", PortType.DOF_SYSTEM);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, CREASES, LABELS, BAND, INSULATION, THIN);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, DOFS);
    }

    @Override
    public String description() {
        return "Builds the system that settles a surface's rings and bisectors together. The "
                + "faces deep inside each region, and the face under each label point, are pinned "
                + "to it; the band of faces beside the walls is free. The DOF system is the face "
                + "graph's Laplacian with an edge's conductance cut where it lies in a groove, "
                + "one degree of freedom per face, the pinned faces frozen: relaxing it solves "
                + "each region's membership over the free faces, and each goes to the region "
                + "with the largest (random walker segmentation). A sliver or thin strip pins "
                + "nothing, so its neighbours take it.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying ring edge marks, after the last spline_ring, "
                        + "spline_cut and add_label statement. Output: the same bundle with the "
                        + "regions to settle in the " + RingSettle.SLOT + " slot, which the "
                        + "relaxation settles in place.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "here when not wired.",
                LABELS.name,
                "Comma-separated edge-mark labels to settle. Empty takes every boolean edge-mark "
                        + "label on the bundle, which after the ring nodes is every ring.",
                BAND.name,
                "How far a wall may move: the width of the free band either side of it, in mean "
                        + "edge lengths. A region shallower than twice this pins its deeper half.",
                INSULATION.name,
                "How strongly a groove holds a wall: an edge in a groove just deep enough to "
                        + "saturate the groove strength conducts exp(-insulation) as well as one "
                        + "on flat surface, a deeper one less still. 0 ignores the grooves and "
                        + "only straightens.",
                THIN.name,
                "A region no deeper than this many mean edge lengths, or a sliver, pins nothing "
                        + "and is taken by its neighbours.",
                DOFS.name,
                "The DOF system of the memberships, what a newton_solver node relaxes.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        if (bundle == null) {
            bundle = GeometryBundle.empty();
        }
        MeshTopology mesh = bundle.mesh();
        if (mesh == null || mesh.faceCount() == 0) {
            ctx.setOutput(GEOMETRY.name, bundle);
            ctx.setOutput(DOFS.name, null);
            return;
        }
        SurfaceCreases creases = ctx.getInput(CREASES.name, SurfaceCreases.class);
        RingSettle settle = new RingSettle(
                RingRegions.ofBundle(bundle, ctx.getInput(LABELS.name, String.class)));
        settle.assemble(creases == null ? SurfaceCreases.of(mesh) : creases,
                ctx.getInputValue(BAND.name) instanceof Number band ? band.doubleValue()
                        : RingSettle.DEFAULT_BAND_EDGES,
                ctx.getInputValue(INSULATION.name) instanceof Number insulation ? insulation.doubleValue()
                        : RingSettle.DEFAULT_INSULATION,
                ctx.getInputValue(THIN.name) instanceof Number thin ? thin.doubleValue()
                        : RingSettle.DEFAULT_THIN_EDGES,
                MeshLabels.inBundle(bundle).pointsByLabel);
        ctx.setOutput(GEOMETRY.name, bundle.withSlot(RingSettle.SLOT, settle));
        ctx.setOutput(DOFS.name, settle.system);
    }
}
