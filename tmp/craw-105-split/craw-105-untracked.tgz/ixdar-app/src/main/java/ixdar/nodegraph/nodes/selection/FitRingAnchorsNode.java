package ixdar.nodegraph.nodes.selection;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import ixdar.annotations.meshnode.MeshNodeAnnotation;
import ixdar.annotations.meshnode.NodeCategory;
import ixdar.geometry.mesh.data.bundle.EdgeMarks;
import ixdar.geometry.mesh.data.bundle.GeometryBundle;
import ixdar.geometry.mesh.data.paths.geodesic.SurfaceGeodesics;
import ixdar.geometry.mesh.data.paths.geodesic.SurfaceMetric;
import ixdar.geometry.mesh.data.paths.query.SurfaceCreases;
import ixdar.geometry.mesh.data.paths.spline.SurfaceSpline;
import ixdar.geometry.mesh.data.representation.MeshTopology;
import ixdar.geometry.mesh.data.rings.AnchoredRings;
import ixdar.nodegraph.api.InputPort;
import ixdar.nodegraph.api.MeshNode;
import ixdar.nodegraph.api.NodeContext;
import ixdar.nodegraph.api.OutputPort;
import ixdar.nodegraph.api.PortType;

/**
 * Moves the anchors of every ring and bisector a surface carries so the regions between them are
 * well cut, and traces each again through its moved anchors.
 */
@MeshNodeAnnotation(id = FitRingAnchorsNode.NODE_ID, category = NodeCategory.SELECTION)
public class FitRingAnchorsNode implements MeshNode {

    public static final String NODE_ID = "fit_ring_anchors";

    public static final InputPort GEOMETRY = new InputPort("geometry", PortType.GEOMETRY_BUNDLE, null);
    public static final InputPort METRIC = new InputPort("metric", PortType.SURFACE_METRIC, null);
    public static final InputPort CREASES = new InputPort("creases", PortType.SURFACE_CREASES, null);
    public static final OutputPort GEOMETRY_OUT = new OutputPort(GEOMETRY.name, PortType.GEOMETRY_BUNDLE);
    public static final OutputPort REPORT = new OutputPort("report", PortType.STRING);

    @Override
    public List<InputPort> inputs() {
        return List.of(GEOMETRY, METRIC, CREASES);
    }

    @Override
    public List<OutputPort> outputs() {
        return List.of(GEOMETRY_OUT, REPORT);
    }

    @Override
    public String description() {
        return "Moves the anchors of every spline_ring and spline_cut together. Every vertex pays for "
                + "its distance to the nearest ring, a vertex in a groove far more, and the rings pay "
                + "for their length; each round solves one sparse Cholesky system for every anchor's "
                + "move, walks each anchor that far sideways off its ring, traces the ring again, and "
                + "keeps the move only when the whole surface pays less. A ring goes into the groove "
                + "nearest it that no other ring is nearer, a ring with no groove to take goes to the "
                + "middle of what is nearest it, and a bisector's ends follow along the rings they "
                + "end on.";
    }

    @Override
    public Map<String, String> socketDocs() {
        return Map.of(
                GEOMETRY.name,
                "Input: a surface carrying rings and bisectors, after the last spline_ring and "
                        + "spline_cut statement. Output: the same mesh with each ring's edge marks and "
                        + "traced spline replaced by the fitted ones, under the same labels. A ring "
                        + "read from a drawn line and a stretch of another ring count as rings but "
                        + "stay as they are.",
                METRIC.name,
                "Required: the metric output of the surface_metric statement the rings were traced "
                        + "with, on this very mesh.",
                CREASES.name,
                "The surface's groove strength, from surface_creases on this very mesh; measured "
                        + "when not wired.",
                REPORT.name,
                "How many rings were fitted, how many anchors moved in how many rounds, and what "
                        + "the surface paid as drawn and fitted.");
    }

    @Override
    public void evaluate(NodeContext ctx) {
        GeometryBundle bundle = ctx.getInput(GEOMETRY.name, GeometryBundle.class);
        MeshTopology mesh = bundle == null ? null : bundle.mesh();
        if (mesh == null || mesh.faceCount() == 0) {
            ctx.setOutput(GEOMETRY.name, bundle == null ? GeometryBundle.empty() : bundle);
            ctx.setOutput(REPORT.name, "");
            return;
        }
        SurfaceMetric metric = ctx.getInput(METRIC.name, SurfaceMetric.class);
        if (metric == null || metric.sourceMesh != mesh) {
            throw new IllegalArgumentException(NODE_ID + " needs the metric its rings were traced with; "
                    + "pass metric=surface.metric from the surface_metric statement on this mesh");
        }
        SurfaceCreases creases = ctx.getInput(CREASES.name, SurfaceCreases.class);
        AnchoredRings rings = new AnchoredRings(bundle, SurfaceGeodesics.over(metric),
                creases != null && creases.sourceMesh == mesh ? creases : SurfaceCreases.of(mesh));
        double drawn = rings.fit.energy();
        rings.fit.relax(rings);
        GeometryBundle out = bundle;
        for (int ring = 0; ring < rings.labels.length; ring++) {
            out = EdgeMarks.with(SurfaceSpline.with(out, rings.labels[ring], rings.splines[ring]),
                    rings.labels[ring], rings.splines[ring].marks.markedByEdgeId);
        }
        ctx.setOutput(GEOMETRY.name, out);
        ctx.setOutput(REPORT.name, String.format(Locale.ROOT, "%d rings fitted, %d anchor moves in %d rounds; "
                + "the surface paid %.4f as drawn and %.4f fitted", rings.labels.length, rings.fit.movedAnchors,
                rings.fit.rounds, drawn, rings.fit.energy()));
    }
}
